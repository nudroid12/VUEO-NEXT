# VUEO Project Context

> Canonical handoff document for humans and AI coding agents.
> Read this file before changing VUEO.
>
> Checkpoint date: 2026-09-05
> Repository: VUEO-NEXT
GitHub: https://github.com/nudroid12/VUEO-NEXT

## 1. What VUEO is

VUEO is a Kotlin/Jetpack Compose Android media application maintained as one monorepo with:

- Android Mobile application
- Android TV application
- Shared Core used by both applications

The project goal is feature parity between Mobile and TV while keeping platform presentation different where necessary.

Mobile is the mature product reference for behaviour and visual language. TV should reuse shared domain/runtime logic and adapt presentation for a 10-foot, D-pad-first experience.

## 2. Repository modules

```text
VUEO-NEXT/
├── mobile/         Android Mobile app
├── tv/             Android TV app
└── shared/core/    Shared domain, runtime, storage and integration logic
```

Gradle modules:

```text
:mobile
:tv
:shared:core
```

Locked application IDs:

| Product | Application ID |
| --- | --- |
| VUEO Mobile | `com.vueo.mobile` |
| VUEO TV | `com.vueo.tv` |

Do not casually change these package/application IDs.

## 3. Architecture rule

The dependency direction is:

```text
                 shared/core
                 /         \
             mobile         tv
```

Rules:

1. `mobile` may depend on `shared:core`.
2. `tv` may depend on `shared:core`.
3. `shared:core` must never depend on `mobile` or `tv`.
4. Reusable business logic belongs in Shared Core.
5. Mobile and TV keep platform-specific UI, navigation and input handling in their own modules.
6. Do not create a TV-only copy of logic that already exists in Shared Core.
7. Do not create a new Shared Core implementation without checking whether the mature Mobile implementation has already been migrated or exposed through a compatibility alias.

## 4. Mobile compatibility files are often aliases

Several files under `mobile/src/main/java/com/vueo/mobile/core/...` intentionally preserve Mobile compatibility facades while delegating to Shared Core.

Examples include:

- `core/extensions/UnifiedMediaEngine.kt`
- `core/extensions/CatalogDiscoveryCache.kt`
- `core/stremio/StremioAddonProvider.kt`
- `core/storage/ProfileStore.kt`
- `core/storage/SettingsStore.kt`
- `core/enrichment/TmdbEnhancementClient.kt`
- `core/dna/UserDnaEngine.kt`

Many of these are `typealias` or compatibility facades. Inspect the file before assuming it is duplicate production logic.

`mobile/core/storage/VueoBackupManager.kt` is intentionally an empty migration marker after Shared Core migration. Do not restore the old Mobile backup implementation there.

## 5. Shared Core source of truth

The following areas currently live in `shared/core` and are intended to be consumed by both Mobile and TV.

### Discovery and catalog

- `UnifiedMediaEngine`
- `MediaExtension`
- `StremioAddonExtension`
- `CatalogDiscoveryCache`
- extension/media contracts and models
- Stremio manifest/catalog/search/meta integration

TV discovery adapters should remain thin. TV must not reintroduce hardcoded Cinemeta HTTP/catalog parsing when Shared Core already handles enabled addons and catalog discovery.

### Source system

- source contracts/models
- source discovery cache
- source policy
- source ranking
- source selector
- player source policy

Source ranking and recovery are mature areas. Avoid changing them while doing visual/UI work unless a real source bug requires it.

### Provider/plugin runtime

- plugin repository manager/client
- plugin runtime and runtime cache
- provider code store
- plugin health store
- compatibility bridges
- TMDB resolver used by providers

The official UI/product name for addon/provider management is **Content Manager**.

Do not rename it to "Content & Discovery", "Extensions", or another generic label.

### Enrichment

- TMDB enhancement
- MDBList ratings
- Rich Details
- metadata enhancement engine
- Content Warning repository

### User data and settings

- profiles
- library/media library
- playback progress/playback state
- SettingsStore
- user data core
- backup/restore/reset

### Personalisation

- User DNA engine
- User DNA preferences

### Player support

- skip segment repository
- shared player/source policy

## 6. Shared Core cleanup checkpoint

The latest Shared Core cleanup prepared in this source tree is **18A Shared Core Final Cleanup**.

It centralises the last major duplicated areas:

### Content Warning

- Shared source of truth: `shared/core/.../enrichment/ContentWarningRepository.kt`
- Mobile warning fetch/parser duplication was removed.
- TV already consumes the Shared repository.
- Content Warning setting is migrated to Shared `SettingsStore`.
- TV warning presentation intentionally follows Mobile behaviour 1:1.

### Backup / Restore / Reset

- Shared source of truth: `shared/core/.../storage/VueoBackupManager.kt`
- Mobile and TV use the Shared manager.
- Shared backup schema is intended to support user-data interchange between Mobile and TV where the data type is common.
- Shared reset clears the relevant shared/mobile/TV user-data preferences and caches.

At this checkpoint, 18A has passed static sanity checks in the handoff environment. A full GitHub Actions build should still be treated as the canonical build confirmation if it has not yet been run.

## 6A. Mobile checkpoint after patches 26 to 28F

Mobile is now in a stabilisation phase. Avoid adding new Mobile features unless a real product requirement is identified. The current source includes:

- three dark application themes: Charcoal, Midnight and Deep Teal
- a neutral translucent profile hero in Settings
- neutral My List, Watched and DNA stats without a special DNA accent
- grouped compact Settings and polished Settings subpages
- Content Manager terminology that avoids third-party platform branding in user-facing copy
- per-catalog enable/disable state persisted independently from the parent addon
- provider diagnostics that keep request, failure, error, HTTP, timing, result and raw evidence while hiding debug noise by default
- a startup destination gate that resolves Who's Watching before Home is allowed to render
- navigation-bar safe spacing on Mobile profile management screens

Architecture cleanup started in 28F. The Content Manager UI family was extracted from the oversized `VueoApp.kt` into:

- `mobile/src/main/java/com/vueo/mobile/ui/VueoContentManager.kt`

This extraction is presentation-only. Content Manager data models, stores, provider runtime and Shared Core contracts were not rewritten. Continue reducing `VueoApp.kt` only in small, behaviour-preserving slices. Do not move startup/profile/player logic during unrelated cleanup.

## 7. Mobile is the visual/behaviour reference where explicitly locked

### Player

Current direction after 17A:

**Mobile Player UI is canonical.**

The previous custom TV Player layout is superseded. TV should use the Mobile Player composition and visual hierarchy, adapted for TV scale, D-pad and focus.

Current TV adaptation includes the Mobile-style structure:

- top title/actions
- Next
- Lock
- More
- Back
- central rewind 10s / Play-Pause / forward 10s
- lower seekbar and time
- `Subs`, `Audio`, `Sources`, `Episodes` pills
- Mobile-style modal/workspace presentation for related player controls

Do not restore the old TV-only layout with title top-left, Restart/Next top-right and the older bottom button row. That design was superseded by 17A.

Player behaviour from the earlier TV behaviour work remains important underneath the Mobile UI adaptation, including:

- D-pad-safe focus flow
- quick seek
- progress persistence
- resume/start over
- auto-next and cancellation
- source recovery
- playback problem handling
- source switching while retaining playback position when possible
- audio/subtitle preference reapplication
- playback speed
- Fit/Fill/Zoom
- sleep timer
- subtitle styling/sync
- provider filter

TV must remain fully usable without a pointer.

TV PiP is intentionally not part of the product direction.

### Content Warning presentation

After 17C, TV follows Mobile warning behaviour/visuals 1:1 as closely as practical:

- IMDb lookup with TMDB fallback
- show once when playback is actually playing
- lime vertical line
- label and severity without a large background card
- progressive item animation
- roughly 5-second hold
- Mobile-style position and timing

Keep repository/data logic shared even when presentation is platform-specific.

### Settings

Current direction after 42A:

**Mobile Settings hierarchy and grouping are canonical.**

The legacy TV root split of Profiles / Content / Playback / Appearance / System is superseded. The TV root now adapts the Mobile Settings groups into three D-pad categories:

- VUEO
- PLAYBACK
- APP

The selected category opens a grouped Mobile-style row card on the right. The active profile remains the first VUEO row so profile switching is not lost. Rows use the Mobile icon-box / title / subtitle / status language, scaled for 10-foot viewing with neutral white TV focus.

Subpages remain one-column TV screens and continue to follow the Mobile Settings hierarchy. Shared Core remains the source of truth for settings behavior and persistence.

Settings still opens through the TV Settings route and profile management remains available through the profile action.

Do not create a second TV-only settings information architecture or duplicate Shared Core preference logic.

## 8. TV interaction rules

TV is a 10-foot interface.

Locked interaction principles:

- 100% D-pad operable
- no cursor required
- focus must always be obvious
- white + scale is the primary focus language
- accent colour must not replace focus clarity
- no focus traps
- Back should unwind the nearest overlay/panel before leaving the parent screen
- restore focus when returning from Detail, Player, Search, Library or Settings where practical
- avoid unexpected horizontal wrapping at the end of a row
- preserve scroll/focus state during normal navigation

Typography must be readable from a sofa. Avoid shrinking text just to fit more items on one screen.

## 9. TV top navigation

Current TV top navigation direction:

```text
Search icon | Library icon | Home | Movie | Series | Anime | Clock | Profile icon
```

- Search and Library are icons.
- Home, Movie, Series and Anime are text tabs.
- Clock is display-only and should not become a focus target.
- Profile opens Settings/profile UI.
- Settings is not a standalone top-nav tab.

## 10. Home behaviour

The Home behaviour work established these expectations:

- restore focus and scroll state
- D-pad Up/Down should try to preserve the same column
- horizontal rows should not wrap unexpectedly
- Hero supports Play/Resume and More Info
- Hero can rotate only when idle and should stop while the user is interacting
- Continue Watching uses real playback progress
- Home should not force a full network refresh every time the user returns from Detail or Player
- loading/error states should not destroy the entire Home experience when only one row fails
- root Back uses an exit confirmation rather than accidental immediate exit

Discovery content must come through Shared Core/Content Manager state rather than reintroduced hardcoded catalog endpoints.

## 11. Discovery, Browse and Search

The corrective architecture established:

- Shared `UnifiedMediaEngine` is the source of truth.
- Stremio addon discovery lives in Shared Core.
- enabled/disabled addon state matters.
- catalog ordering matters.
- TV adapters map Shared results to TV presentation.

Feature parity work also added/targets:

- Movie / Series / Anime browsing
- Actor Search
- Anime filter
- Genre filter
- Popular / Trending / Newest sorting
- relevance-aware search ordering

Do not reintroduce a TV-specific direct HTTP discovery engine.

## 12. Detail screen

TV Detail parity direction includes:

- metadata loaded through Shared Core
- no hardcoded Cinemeta detail endpoint
- TMDB Recommendations
- TMDB Similar Titles
- More Like This
- local VUEO similarity fallback
- rich cast with images/character names
- network/production branding when available
- related-title back-stack behaviour

Keep enrichment logic in Shared Core and the 10-foot presentation in TV.

## 13. Content Manager

Official product name: **Content Manager**.

User-facing UI should use VUEO-neutral terms such as addons, repositories, providers and catalogs. Internal protocol/runtime class names may remain technical where required by the implementation.

It manages:

- addons
- provider plugins
- repositories
- provider health and diagnostics
- catalog ordering
- per-catalog visibility

Current Mobile behaviour includes:

- refresh/remove addon
- refresh/remove repository
- provider health summary
- compact expandable provider diagnostics
- sanitized raw diagnostic evidence
- persistent per-catalog enable/disable state
- catalog order preserved while a catalog is hidden

Content Manager state should feed Shared Core discovery and playback behaviour. Avoid separate hidden state stores that drift between screens.

## 14. Profiles, Library and Appearance

TV parity includes:

### Profiles

- Add profile
- Edit profile
- Delete profile
- avatar selection
- Kids Profile toggle
- Manage Profiles entry
- profile PIN/security support

### Library

- My List
- watched/history/progress state
- Grid/List view
- remember selected Library view

### Appearance

Accent options include the current Mobile/TV parity set such as:

- White
- Lime
- Ocean
- Violet
- Amber
- Coral

Accent applies to product accents/progress/status. White + scale focus remains the focus language on TV.

## 14A. Current important Mobile files

High-value Mobile UI entry points now include:

- `mobile/src/main/java/com/vueo/mobile/ui/VueoApp.kt`
- `mobile/src/main/java/com/vueo/mobile/ui/VueoContentManager.kt`
- `mobile/src/main/java/com/vueo/mobile/ui/VueoSettings.kt`
- `mobile/src/main/java/com/vueo/mobile/ui/VueoProfiles.kt`
- `mobile/src/main/java/com/vueo/mobile/ui/VueoDesign.kt`

`VueoApp.kt` is still large. Extract only coherent screen families, keep navigation contracts stable, and validate regression-sensitive flows after each extraction.

## 15. Current important TV files

Key TV entry points include:

- `tv/src/main/java/com/vueo/tv/VueoTvApp.kt`
- `tv/src/main/java/com/vueo/tv/data/TvUnifiedDiscovery.kt`
- `tv/src/main/java/com/vueo/tv/detail/TvDetailScreen.kt`
- `tv/src/main/java/com/vueo/tv/search/TvSearchScreen.kt`
- `tv/src/main/java/com/vueo/tv/content/TvContentManagerScreen.kt`
- `tv/src/main/java/com/vueo/tv/player/TvPlayerScreen.kt`
- `tv/src/main/java/com/vueo/tv/player/TvSourceEngine.kt`
- `tv/src/main/java/com/vueo/tv/player/TvSourcePickerScreen.kt`
- `tv/src/main/java/com/vueo/tv/library/TvLibraryScreen.kt`
- `tv/src/main/java/com/vueo/tv/profile/TvFunctionalSettings.kt`
- `tv/src/main/java/com/vueo/tv/profile/TvProfileDnaPanel.kt`
- `tv/src/main/java/com/vueo/tv/profile/TvProfilePickerScreen.kt`
- `tv/src/main/java/com/vueo/tv/profile/TvUserHubScreen.kt`
- `tv/src/main/java/com/vueo/tv/ui/focus/TvFocus.kt`
- `tv/src/main/java/com/vueo/tv/ui/theme/TvAppearance.kt`

Inspect the current implementation before editing. This document describes design intent and architecture, but source code is the authority for exact APIs and signatures.

## 16. Current important Shared Core files

Key Shared Core areas include:

```text
shared/core/src/main/java/com/vueo/shared/core/
├── dna/
├── enrichment/
├── extensions/
├── media/
├── player/
├── plugin/
├── source/
├── storage/
└── stremio/
```

High-value files:

- `extensions/UnifiedMediaEngine.kt`
- `extensions/StremioAddonExtension.kt`
- `extensions/CatalogDiscoveryCache.kt`
- `enrichment/ContentWarningRepository.kt`
- `enrichment/MetadataEnhancementEngine.kt`
- `enrichment/TmdbEnhancementClient.kt`
- `plugin/PluginRuntime.kt`
- `plugin/PluginStore.kt`
- `plugin/ProviderCodeStore.kt`
- `source/SourceRanker.kt`
- `source/SourceSelector.kt`
- `storage/ProfileStore.kt`
- `storage/LibraryStore.kt`
- `storage/PlaybackStore.kt`
- `storage/SettingsStore.kt`
- `storage/VueoBackupManager.kt`

## 17. Current milestone history

Use this only as a handoff guide. The current source is more important than old patch names.

Recent milestones:

- 14A: TV Player UI redesign, later superseded visually by 17A
- 14B: complete TV Player behaviour foundation, behaviour retained where compatible
- 15A: Home complete behaviour
- 15B: Settings visual polish, later superseded visually by 17B
- 16A: Unified Discovery, then corrective Shared Core architecture
- 16B: Detail parity through Shared Core
- 16C: Player feature parity
- 16D: Content Manager + Search parity
- 16E: Profile, Library and Appearance parity
- 17A: Mobile Player UI adapted to TV, canonical current Player visual direction
- 17B: Mobile Settings UI adapted to TV, canonical current Settings visual direction
- 17C: Content Warning presentation matched to Mobile 1:1
- 18A: Shared Core cleanup for Content Warning and Backup/Restore/Reset
- 26A-27B: Mobile Settings hierarchy, themes, profile surface and Settings subpage polish
- 28A: Mobile Content Manager presentation rebuild
- 28B: Mobile Who's Watching startup destination gate restored
- 28C-28E: Provider diagnostics upgraded, then compacted to debug-first evidence
- 28D: Mobile profile safe-area fix and persistent per-catalog enable/disable state
- 28F: Mobile housekeeping and first safe extraction from `VueoApp.kt` into `VueoContentManager.kt`
- 28G: Mobile regression lock; `Ask on startup` now always means the profile picker is the launch destination when enabled, and Mobile v1 contracts are recorded in `MOBILE_REGRESSION_LOCK.md`

Do not revert to a superseded visual milestone just because an older patch or conversation mentions it.

## 18. Build and validation

Canonical local command:

```bash
./gradlew :mobile:assembleDebug :tv:assembleDebug
```

GitHub Actions is the authoritative full build when local/network constraints prevent Gradle dependency resolution.

A previous handoff environment could not resolve `services.gradle.org`, so static Kotlin syntax checks and ZIP integrity checks were used there. Do not interpret inability to reach Gradle servers as a source-code failure.

When changing Shared Core, validate both applications because both depend on it.

## 19. Patch workflow rules

The project has often been updated with replacement ZIP patches.

When producing a patch for the maintainer:

1. Include only actual replacement/new source files unless explicitly asked for workflows or raw patches.
2. Preserve repository-relative paths.
3. Prefer one ZIP for a coherent phase.
4. Do not include generated build outputs.
5. Avoid unnecessary workflow modifications.
6. Full GitHub Actions build result is the final compile signal.

### Important repository-root ZIP pitfall

A previous patch contained only a top-level `tv/` directory. The patch workflow mistook `tv/` for the repository root because it contained its own `build.gradle.kts`.

For replacement ZIPs that could trigger this ambiguity, include the repository root `build.gradle.kts` as a root marker so extraction/apply logic resolves the real repo root correctly.

Do not overwrite the root build file with `tv/build.gradle.kts`.

## 20. Distribution/update assumption

The TV app is currently distributed as an APK outside the Play Store workflow, including direct sharing such as Telegram. Do not design release/update logic around mandatory Play Store publication unless the maintainer explicitly changes this direction.

## 21. Rules for future AI agents

Before modifying anything:

1. Read this entire file.
2. Inspect `settings.gradle.kts`, module build files and the exact current source files involved.
3. Search Shared Core before implementing reusable logic in Mobile or TV.
4. Search Mobile before inventing a new TV behaviour when the maintainer asks for Mobile parity.
5. Treat Mobile Player and Mobile Settings as the current visual reference for their TV equivalents.
6. Preserve TV D-pad/focus requirements.
7. Do not rewrite stable Source Engine/ranking logic during unrelated UI work.
8. Do not rename Content Manager.
9. Do not reintroduce hardcoded Cinemeta discovery/detail paths where Shared Core is already responsible.
10. Do not assume compatibility files in Mobile are duplicate logic. Many are aliases.
11. Keep changes scoped. Avoid large architecture rewrites unless the task genuinely requires them.
12. If source and this document disagree, inspect recent code/history and update this document with the confirmed current truth.

## 22. Handoff checklist after every substantial phase

Future agents should update this file when a substantial architecture or product direction changes.

At minimum record:

- what became canonical
- what was superseded
- Shared Core migrations
- new known limitations
- build status
- next recommended phase

This file exists specifically so the project can be continued safely from another ChatGPT account, another coding model, or another development environment without relying on prior chat history.
## Mobile v1 lock after 28G

Mobile v1 is now feature-locked while the TV rebuild proceeds. Use `MOBILE_REGRESSION_LOCK.md` as the regression baseline. Mobile changes should be limited to confirmed bugs, Shared Core compatibility, or an explicit new product decision.

`Ask on startup` is literal: when enabled, Who's Watching is the startup destination regardless of the number of profiles. A locked active profile also forces the picker.

## 23. TV clean rebuild baseline — 29A-R2

TV presentation/runtime after profile selection is now a clean rebuild. The old TV Home/Search/Library/Settings/Details/Source/Player implementations and TV-only repositories/stores are not part of the new runtime. Old Kotlin paths that cannot be physically deleted by the repository ZIP overlay are overwritten with inert tombstone comments.

The only intentionally preserved TV experience is the profile family: Who's Watching, Manage Profiles, Add/Edit Profile and its existing PIN/editor behaviour.

The new TV runtime adapts proven Mobile behaviour through Shared Core rather than depending on `:mobile` or legacy TV stores:

- startup/profile gate -> `ProfileStore`
- Home discovery -> `UnifiedMediaEngine` + catalog preferences matching Mobile `AddonStore` semantics
- My List / Continue Watching / History -> `LibraryStore`
- playback position -> `PlaybackStore`
- settings -> `SettingsStore`
- addon/provider discovery and source cleanup/ranking -> Shared Core runtime

TV owns its own 10-foot Compose UI, D-pad focus, navigation and motion. Read `TV_REBUILD_LOCK.md` before TV work.



## TV 29B — Premium Cinematic Home

- Built on the green 29A-R + build-fix baseline.
- Home only: larger hero breathing area, first rail at ~62% viewport, fully contextual nav labels, layered cinematic scrims, 244dp landscape cards, external captions, shallow neutral focus depth.
- Preserves 180ms card-driven hero settle and all clean-rebuild runtime/data contracts.
- Profile flow, Search, Library, Settings, Details, Source and Player behaviour are intentionally unchanged by 29B.

### TV 29B.1 — Navigation + Settings Activation
- Fixed top-nav two-step activation: one focused control = one focus target = one OK action.
- Home row title-to-card spacing increased without moving the whole first rail lower.
- Activated a new TV-native Settings screen backed by Shared Core profile/playback/subtitle/source preferences.
- Navigation contract: focus moves with D-pad; OK commits; Down from nav restores the last setting/content target where supported.

## TV 29B.2 — Complete Settings (2026-09-06)
TV Settings now follows the canonical Mobile hierarchy with TV-native D-pad interaction. The temporary flat 29B.1 panel is superseded. Runtime consumers are wired for Personalization, enhancements, playback, subtitles, sources, appearance, backup/restore/data maintenance and updates. Do not reintroduce preference rows that are not consumed by TV behavior.

### TV 29C — Mobile Search Parity
- TV Search now ports the Mobile Search hierarchy and behavior instead of using the earlier minimal title-only landscape grid.
- Added Discover, Title/Actor search, Type/Sort/Genre filters, Mobile relevance/dedupe behavior and poster-first results.
- Search session is hoisted to `VueoTvApp` so Detail return restores query, filters, scroll and exact result focus where available.
- All new Search behavior consumes existing Shared Core APIs; Mobile and Shared Core source remain untouched.


### TV 29C.1 — Search TV Calibration
- Real-TV validation showed the first 29C Search pass was oversized and too close to a mobile layout enlarged for TV.
- Post-profile page chrome no longer carries a persistent VUEO wordmark; startup/profile branding remains intact.
- Search composition now follows the approved compact cinematic mockup while retaining VUEO's contextual top navigation (no new sidebar).
- Search field is ~76% content width, filters and Title/Actor share one row, and result density is locked to 8 visible 2:3 posters per row.
- Focus scale is reduced to ~1.035 with restrained shadow; no Search logic, Shared Core source, return-state behavior, or Home hero logic changes.

### TV 29C.2 — Centered Floating Navigation
- Replaces the left-aligned text strip with one centered floating navigation capsule shared by Home, Search, Library and Settings.
- Destinations remain Home / Search / Library / Settings; Profile remains a separate top-right anchor.
- Current destination uses a soft filled pill. Focus uses neutral white, ~1.025 scale and short 95–120ms motion.
- No route is committed by focus movement; OK/Enter still activates exactly once.
- Home/Search retain the contextual collapse/reveal behavior so content and hero remain visually dominant.
- This is presentation-only; routing, screen behavior, Search logic, Home hero logic, Mobile and Shared Core are unchanged.

### TV 29C.2a — startup update prompt
The clean rebuild had retained `TvUpdateManager` but discarded its automatic-check result at app startup. 29C.2a restores the visible update-available prompt using the existing TV manifest/download/verification/install flow. Prompt is modal and D-pad-contained with Later / Update. Exact legacy popup UI source is not present in the available clean-rebuild repository; `VueoTvUpdateManager.kt` is a tombstone.

### TV 29C.3 navigation shell

TV primary navigation now uses a premium collapsible left sidebar instead of the centered floating top capsule. Collapsed width is 66dp; focused/expanded width is 202dp. The global order is Home, Search, Library, Settings, with Profile at the bottom. LEFT from a logical first content column enters the current sidebar destination; RIGHT restores the last content focus; UP/DOWN explores; OK commits. Search preserves cursor-left while query text exists. The sidebar overlays content and normal app pages remain free of the VUEO wordmark.

### TV 29C.4 — VUEO sidebar rebuild
The current TV presentation/interaction baseline is VUEO-owned. Architecture remains Shared Core + Mobile-proven behavior, with TV-specific composition, focus and remote interaction.

The 29C.3 permanent 66dp/202dp sidebar rail visual is superseded. The current sidebar uses the VUEO floating pattern: a collapsed current-route pill, then an inset rounded ~262dp overlay panel when navigation owns focus. Profile sits at the top; Home / Search / Library / Settings are vertically centered; items use circular icon wells and rounded-full selected/focus surfaces. Search hides the collapsed pill to protect its header. The Home/Search/Library/Settings content left padding introduced only to clear the 29C.3 rail is removed so content regains the pre-rail canvas width. D-pad behavior remains VUEO's locked contract: LEFT enters current nav destination, RIGHT restores exact content focus where possible, UP/DOWN explores, focus does not route, one OK commits.

For future TV UI work, preserve the current sidebar composition, component proportions and motion/focus tokens unless an explicit product decision replaces them. VUEO behavior and branding remain authoritative.

### TV 29D — Library rebuilt from Mobile behavior

Library was re-audited against the supplied VUEO Mobile source before rebuilding. Canonical Mobile Library currently reads `LibraryStore.watchlist()` and exposes **My List / Cloud** plus a persisted **Grid/List** presentation toggle (`vueo_library_ui`, `grid_view`). It does not present Continue Watching or History as Library sections. TV 29D now follows that contract while keeping the established VUEO TV composition/D-pad behavior.

TV Library uses one vertical responsive content canvas, My List/Cloud controls, persisted Grid/List mode, responsive poster density based on a target poster width, and last-item/scroll focus restoration. Shared Core history/progress data is untouched and remains available to Home, Detail, Player and other behavior. The earlier fixed 8-up Search density is no longer a global TV poster-density rule; Search can be redesigned separately.

## TV 29E — Detail functional rebuild

Detail follows the project-wide rule: Mobile VUEO is canonical for feature/data behaviour, while TV owns its VUEO composition/D-pad presentation. The Detail screen is rebuilt around a sticky cinematic backdrop and hero action area, followed by season tabs/episode cards and supporting content. Existing Shared Core/TvRuntime contracts remain authoritative for metadata, My List, playback/history, ratings, DNA and recommendations. No external TV runtime code is imported.

29E is deliberately a functional baseline. Final cross-screen typography, density, spacing, focus motion and sidebar calibration will happen after Detail → Source → Player are functionally rebuilt.

## 29F Source Selection functional baseline

Source Selection now follows the same architecture rule as Library/Detail: **Mobile/Shared Core own behavior; VUEO TV owns presentation/focus**. The TV source screen consumes `UnifiedMediaEngine`, `PluginSourceEngine`, `SourceCleaner`, `PlayerSourcePolicy`, `SettingsStore` and the shared `SourceDiscoveryCache` through `TvRuntime`; it does not depend on the Mobile module.

TV source discovery now surfaces cached/progressive snapshots while preserving the existing final `TvSourceBundle` contract. The screen keeps provider filters, VUEO recommendation, Engine Details, direct-play gating and the source technical-details preference aligned with Mobile. The VUEO layout is cinematic identity/engine context on the left and a rounded provider/filter + stream workspace on the right. Returning from Player restores the last selected provider/source where the source still exists. Player remains the next functional rebuild; whole-TV visual polish is deferred.

## TV 29G Player D-pad native functional rebuild

TV Player is now rebuilt around a TV-native remote interaction model rather than the previous full-screen touch-like focus target. Controls are bottom anchored; the top area is informational only and intentionally has no Back or Lock buttons. Hidden-state Left/Right remains a 10 second quick seek, while visible-state Left/Right is deterministic control navigation and OK/Enter activates the focused control. Remote Back closes a player panel first, then hides controls, then saves/exits.

The bottom row now exposes Play/Pause, 10 second rewind/forward, Next, Subtitles, Audio, Sources, Episodes and More. Subtitles, Audio, Sources, Episodes and More use D-pad side panels with horizontal focus trapping and focus restoration to the opening control. Source changes preserve position, existing auto-recovery remains intact, episodes use the existing navigation callback, and More persists playback speed/video fit through `SettingsStore`. Skip segments and auto-next remain contextual actions and are focusable.

29G does not rewrite the ExoPlayer, Shared Core storage, source discovery/ranking, skip repository or playback-history contracts. Full Gradle compilation is not confirmed in the current execution environment because Gradle 9.3.1 is not cached and `services.gradle.org` cannot be resolved. Real-TV calibration is still required before final cross-screen polish.

### TV 30A — Premium Home density
Home presentation is now calibrated around the current 29C.4 floating sidebar. The hero reading zone occupies roughly the upper half of the viewport; Continue Watching remains medium landscape while My List/catalog rails use medium 2:3 posters (~128dp) for about 5–6 visible titles on a common TV viewport. Focus motion is restrained (~1.028), rail density is tighter, and backdrop scrims are lighter. No Home data, route or sidebar interaction contract changed.

## TV 30C Home source-referenced rebuild

- Home/sidebar were rewritten around the current VUEO TV composition and D-pad grammar.
- VUEO keeps its own data/routes; only layout and focus principles were adapted.
- Collapsed TV navigation is now a stable icon-only rail; no floating route pill.
- Home rows begin at ~49% viewport height, hero copy is ~42% width, CW is landscape and catalogs remain portrait.
- Per-row focus memory and deterministic UP/DOWN row transfer are part of the Home contract.

## TV 42A - Settings Mobile Category Rebuild (2026-09-08)

The TV Settings root now uses the current Mobile Settings groups as its category model. `VUEO` contains Profile, Personalization, Content Manager and Enhancements. `PLAYBACK` contains Playback, Subtitles and Sources. `APP` contains Appearance, Data & Storage, Updates and About VUEO. Root rows use Mobile-style icon wells, grouped separators and the same compact status summaries where the TV runtime exposes the same preference. Existing Settings subpages, runtime wiring, Shared Core behavior and global TV sidebar navigation are unchanged.
