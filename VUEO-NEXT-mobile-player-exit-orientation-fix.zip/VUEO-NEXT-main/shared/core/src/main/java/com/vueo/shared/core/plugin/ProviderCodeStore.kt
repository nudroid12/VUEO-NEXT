package com.vueo.shared.core.plugin

import android.content.Context
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.security.MessageDigest

data class ProviderCodeSyncResult(
    val repository: PluginRepositoryDescriptor,
    val readyProviders: Int,
    val failedProviders: Int,
    val errors: List<String>,
)

class ProviderCodeStore(context: Context) {
    private val appContext = context.applicationContext
    private val root = File(
        appContext.filesDir,
        CACHE_DIRECTORY,
    )

    init {
        migrateLegacyCacheIfNeeded(
            filesDir = appContext.filesDir,
            target = root,
        )
        root.mkdirs()
    }

    fun read(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
    ): String? {
        val file = fileFor(repository, provider)

        if (!file.isFile) {
            return null
        }

        return runCatching {
            file.readText(Charsets.UTF_8)
        }.getOrNull()
    }

    fun write(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
        source: String,
    ) {
        require(source.isNotBlank()) {
            "Provider script is empty."
        }

        val file = fileFor(repository, provider)
        file.parentFile?.mkdirs()

        val temp = File(
            file.parentFile,
            file.name + ".tmp",
        )

        temp.writeText(source, Charsets.UTF_8)

        if (!temp.renameTo(file)) {
            file.writeText(
                temp.readText(Charsets.UTF_8),
                Charsets.UTF_8,
            )
            temp.delete()
        }
    }

    fun isReady(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
    ): Boolean =
        read(repository, provider)
            ?.isNotBlank() == true

    fun has(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
    ): Boolean =
        fileFor(repository, provider).isFile

    fun readyCount(
        repository: PluginRepositoryDescriptor,
    ): Int =
        repository.providers.count {
            isReady(repository, it)
        }

    fun removeRepository(manifestUrl: String) {
        runCatching {
            File(root, hash(manifestUrl))
                .deleteRecursively()
        }
    }

    private fun fileFor(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
    ): File {
        val repoDir = File(
            root,
            hash(repository.manifestUrl),
        )

        val key = listOf(
            provider.id,
            provider.version,
            provider.filename,
        ).joinToString("|")

        return File(
            repoDir,
            "${hash(key)}.js",
        )
    }

    private fun hash(value: String): String =
        MessageDigest
            .getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") {
                "%02x".format(it)
            }

    companion object {
        private const val CACHE_DIRECTORY = "vueo_plugin_scrapers"
        private const val LEGACY_CACHE_DIRECTORY = "nuvio_plugin_scrapers"

        internal fun clearStoredCode(context: Context) {
            val filesDir = context.applicationContext.filesDir
            listOf(
                CACHE_DIRECTORY,
                LEGACY_CACHE_DIRECTORY,
            ).forEach { directory ->
                runCatching {
                    File(filesDir, directory).deleteRecursively()
                }
            }
        }

        private fun migrateLegacyCacheIfNeeded(
            filesDir: File,
            target: File,
        ) {
            if (target.exists()) return

            val legacy = File(
                filesDir,
                LEGACY_CACHE_DIRECTORY,
            )
            if (!legacy.isDirectory) return

            if (legacy.renameTo(target)) return

            runCatching {
                target.mkdirs()
                legacy.copyRecursively(
                    target = target,
                    overwrite = false,
                )
                legacy.deleteRecursively()
            }
        }
    }
}

class ProviderCodeSyncManager(
    context: Context,
) {
    private val store = ProviderCodeStore(
        context.applicationContext
    )

    private val concurrency = Semaphore(4)

    suspend fun syncRepository(
        repository: PluginRepositoryDescriptor,
        force: Boolean,
    ): ProviderCodeSyncResult =
        syncProviders(
            repository = repository,
            providers = repository.providers,
            force = force,
        )

    suspend fun syncProviders(
        repository: PluginRepositoryDescriptor,
        providers: List<PluginProviderDescriptor>,
        force: Boolean,
    ): ProviderCodeSyncResult = coroutineScope {
        val errors = mutableListOf<String>()
        val uniqueProviders = providers.distinctBy { it.id }

        val outcomes = uniqueProviders.map { provider ->
            async {
                concurrency.withPermit {
                    if (
                        !force &&
                        store.isReady(repository, provider)
                    ) {
                        return@withPermit true
                    }

                    runCatching {
                        val url =
                            PluginRepositoryClient
                                .providerScriptUrl(
                                    repository,
                                    provider,
                                )

                        val source =
                            PluginHttp.getText(url)

                        store.write(
                            repository,
                            provider,
                            source,
                        )

                        true
                    }.getOrElse { error ->
                        synchronized(errors) {
                            errors +=
                                "${provider.name}: " +
                                (
                                    error.message
                                        ?: error::class.java.simpleName
                                )
                        }
                        false
                    }
                }
            }
        }.awaitAll()

        PluginRuntimeCache.clear()

        ProviderCodeSyncResult(
            repository = repository,
            readyProviders = outcomes.count { it },
            failedProviders = outcomes.count { !it },
            errors = errors.take(8),
        )
    }

    suspend fun syncEnabled(
        repositories: List<PluginRepositoryDescriptor>,
        pluginStore: PluginStore,
    ) = coroutineScope {
        repositories
            .filter(pluginStore::isRepositoryEnabled)
            .map { repository ->
                async {
                    val providers =
                        repository.providers
                            .filter { provider ->
                                pluginStore.isProviderEnabled(
                                    repository,
                                    provider,
                                )
                            }

                    syncProviders(
                        repository = repository,
                        providers = providers,
                        force = false,
                    )
                }
            }
            .awaitAll()
        Unit
    }

    suspend fun syncMissing(
        repositories: List<PluginRepositoryDescriptor>,
    ) {
        repositories.forEach { repository ->
            syncRepository(
                repository = repository,
                force = false,
            )
        }
    }
}
