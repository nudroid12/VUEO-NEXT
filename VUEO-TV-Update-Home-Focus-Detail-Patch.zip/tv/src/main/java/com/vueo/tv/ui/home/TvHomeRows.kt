package com.vueo.tv.home

import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.LocalPinnableContainer
import com.vueo.tv.ui.tvPrefetchImage
import androidx.compose.ui.unit.Density
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.gestures.BringIntoViewSpec
import androidx.compose.foundation.gestures.LocalBringIntoViewSpec
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.layout.LazyLayoutCacheWindow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.getValue
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRestorer
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.vueo.shared.core.diagnostics.PerformanceDiagnostics
import com.vueo.tv.ui.TvDesign
import com.vueo.tv.ui.TvNetworkImage
import com.vueo.tv.ui.tvPosterActivation
import com.vueo.tv.ui.tvSidebarIsPillMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest

// Lazy diagnostic messages: no string construction while diagnostics is OFF.
private inline fun traceHome(build: () -> String) {
    if (PerformanceDiagnostics.isCollecting()) {
        PerformanceDiagnostics.captureRuntimeEvent(build())
    }
}

// Nuvio Smooth Focus Scroll uses 180 as spring stiffness, not duration.
private val HomeHorizontalFocusSpring = spring<Float>(dampingRatio = 0.95f, stiffness = 180f)

private val ContinueWatchingWidth = 210.dp
private val ContinueWatchingHeight = 119.dp
private val PosterWidth = 114.dp
private val ContinueShape = RoundedCornerShape(12.dp)
private val PosterShape = RoundedCornerShape(12.dp)
private val VerticalRowCacheExtent = 520.dp
private val RowTitleSpacing = 14.dp
private val RowTitleLineHeight = 22.sp

private val TvHomeRowKind.cardWidth: Dp
    get() = if (this == TvHomeRowKind.POSTERS) PosterWidth else ContinueWatchingWidth
private val TvHomeRowKind.cardHeight: Dp
    get() = if (this == TvHomeRowKind.POSTERS) MODERN_HOME_POSTER_HEIGHT else ContinueWatchingHeight


/** Height of a complete row including its title, gap and focus paint space. */
internal fun TvHomeRowKind.homeRowContentHeight(
    density: Density,
    portraitCards: Boolean = false,
): Dp =
    (if (portraitCards) MODERN_HOME_POSTER_HEIGHT else cardHeight) + RowTitleSpacing + with(density) { RowTitleLineHeight.toDp() }

internal data class HomeRowsLayout(
    val viewportHeight: Dp,
    val bottomPadding: Dp,
    val startPadding: Dp,
    val portraitCards: Boolean,
    val fixedFocus: Boolean,
)

private data class HomeVerticalFocusTarget(
    val rowKey: String,
    val cardIndex: Int,
    val token: Int,
    val fastLanding: Boolean = false,
    val menuReturn: Boolean = false,
    val initialReset: Boolean = false,
    val routeReturn: Boolean = false,
    val restorePosition: TvHomeHorizontalPosition? = null,
    val cardKey: String? = null,
    val restoreFirstCardKey: String? = null,
)

@OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
@Composable
internal fun TvModernHomeRows(
    rows: List<TvHomeRow>,
    rowsLayout: HomeRowsLayout,
    contentFocusRequester: FocusRequester,
    focusResetToken: Int,
    contentReturnToken: Int,
    active: Boolean,
    routeReturnPending: Boolean,
    routeFocusAnchor: HomeRouteFocusAnchor?,
    onCaptureRouteFocusAnchor: (HomeRouteFocusAnchor) -> Unit,
    onRouteFocusRestored: () -> Unit,
    navigationVisible: Boolean,
    navigationOwnsFocus: Boolean,
    onContentFocused: () -> Unit,
    onVerticalMotionChanged: (Boolean) -> Unit,
    onUpFromFirstRow: () -> Unit,
    onLeftAtRowStart: (() -> Unit)?,
    onCatalogViewportChanged: (List<String>) -> Unit,
    onCatalogPageNeeded: (TvHomeRow, Int) -> Boolean,
    onFocused: (TvHomeRow, Int, TvHomeEntry) -> Unit,
    onOpen: (TvHomeEntry) -> Unit,
    onPosterLongClick: (TvHomeEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    // A profile change resets activeRowKey and focusedIndexByRow in the app.
    // Discard horizontal positions alongside that existing focus reset.
    if (TvHomeFocusMemory.activeRowKey == null && TvHomeFocusMemory.focusedIndexByRow.isEmpty()) {
        TvHomeFocusMemory.horizontalPositionByRow.clear()
        TvHomeFocusMemory.focusedKeyByRow.clear()
    }
    val verticalCacheWindow = remember {
        LazyLayoutCacheWindow(ahead = VerticalRowCacheExtent, behind = VerticalRowCacheExtent)
    }
    val verticalState = rememberLazyListState(cacheWindow = verticalCacheWindow)
    // A row's horizontal position and its focused card are independent.
    // Keep LazyListState instances above the LazyColumn items so their positions
    // survive row disposal/recomposition during vertical navigation.
    val rowListStates = remember { mutableMapOf<String, LazyListState>() }
    var verticalFocusToken by remember { mutableIntStateOf(0) }
    var verticalFocusTarget by remember { mutableStateOf<HomeVerticalFocusTarget?>(null) }
    var fastVerticalScrolling by remember { mutableStateOf(false) }
    val currentMotionCallback by rememberUpdatedState(onVerticalMotionChanged)
    val currentRows by rememberUpdatedState(rows)
    val routeReturnPendingState = rememberUpdatedState(routeReturnPending)
    val currentNavigationVisible by rememberUpdatedState(navigationVisible)
    var appliedFocusResetToken by remember { mutableIntStateOf(0) }
    var appliedContentReturnToken by remember { mutableIntStateOf(0) }
    val rowFocusRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val initialActiveRowKey = TvHomeFocusMemory.activeRowKey
        ?.takeIf { saved -> rows.any { it.key == saved } }
        ?: rows.firstOrNull()?.key
    var previewReturnRowKey by remember { mutableStateOf<String?>(null) }
    var previewReturnCardIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(active, routeReturnPending, routeFocusAnchor) {
        if (!active || !routeReturnPending || routeFocusAnchor?.restoreReady != true) return@LaunchedEffect
        val anchor = routeFocusAnchor ?: return@LaunchedEffect
        val row = currentRows.firstOrNull { it.key == anchor.rowKey && it.entries.isNotEmpty() }
            ?: currentRows.firstOrNull { it.kind == TvHomeRowKind.POSTERS && it.entries.isNotEmpty() }
            ?: currentRows.firstOrNull { it.entries.isNotEmpty() }
            ?: run {
                onRouteFocusRestored()
                return@LaunchedEffect
            }
        val cardIndex = row.entries.indexOfFirst { it.key == anchor.cardKey }
            .takeIf { it >= 0 } ?: (if (row.key == anchor.rowKey) anchor.cardIndex else 0)
                .coerceIn(0, row.entries.lastIndex)
        val sameRow = row.key == anchor.rowKey
        val savedCardPresent = sameRow && row.entries[cardIndex].key == anchor.cardKey
        val targetRowIndex = currentRows.indexOf(row)
        val rowShift = if (anchor.capturedRowIndex >= 0) targetRowIndex - anchor.capturedRowIndex else 0
        val firstRowIndex = currentRows.indexOfFirst { it.key == anchor.verticalFirstRowKey }
        val verticalIndex = if (sameRow && firstRowIndex in 0..targetRowIndex) firstRowIndex
            else if (sameRow) (anchor.verticalIndex + rowShift).coerceIn(0, targetRowIndex)
            else targetRowIndex
        val verticalOffset = if (sameRow) anchor.verticalOffset else 0
        // This also owns initial focus when Home was recreated after Sources.
        // Do not let the later menu effect replay an initial reset over this return.
        appliedFocusResetToken = focusResetToken
        fastVerticalScrolling = false
        if (verticalState.firstVisibleItemIndex != verticalIndex ||
            verticalState.firstVisibleItemScrollOffset != verticalOffset
        ) {
            verticalState.scrollToItem(verticalIndex, verticalOffset)
        }
        if (verticalState.layoutInfo.visibleItemsInfo.none {
                it.key == row.key && it.offset < verticalState.layoutInfo.viewportEndOffset &&
                    it.offset + it.size > verticalState.layoutInfo.viewportStartOffset
            }
        ) {
            verticalState.scrollToItem(targetRowIndex)
        }
        verticalFocusToken += 1
        verticalFocusTarget = HomeVerticalFocusTarget(
            rowKey = row.key, cardIndex = cardIndex, token = verticalFocusToken,
            routeReturn = true, restorePosition = anchor.horizontal.takeIf { savedCardPresent },
            cardKey = row.entries[cardIndex].key,
            restoreFirstCardKey = anchor.horizontalFirstCardKey.takeIf { savedCardPresent },
        )
        traceHome { "HOME_ROUTE_FOCUS_TARGET row=${row.key} card=$cardIndex preserveViewport=$savedCardPresent" }
    }

    var previousPortraitLayout by remember { mutableStateOf(rowsLayout.portraitCards) }
    LaunchedEffect(rowsLayout.portraitCards) {
        if (previousPortraitLayout == rowsLayout.portraitCards) return@LaunchedEffect
        previousPortraitLayout = rowsLayout.portraitCards
        if (!active || routeReturnPending || navigationOwnsFocus || rows.isEmpty()) return@LaunchedEffect
        val rowIndex = rows.indexOfFirst { it.key == TvHomeFocusMemory.activeRowKey }
            .takeIf { it >= 0 } ?: rows.indexOfFirst { it.key.startsWith("catalog:") }.coerceAtLeast(0)
        val row = rows[rowIndex]
        val cardIndex = row.savedFocusIndex()
        fastVerticalScrolling = false
        verticalState.scrollToItem(rowIndex)
        verticalFocusToken++
        verticalFocusTarget = HomeVerticalFocusTarget(row.key, cardIndex, verticalFocusToken)
    }

    val density = LocalDensity.current
    val defaultBringIntoViewSpec = LocalBringIntoViewSpec.current
    val suspendVerticalAlignment by rememberUpdatedState(routeReturnPending || fastVerticalScrolling)
    val verticalBringIntoViewSpec = remember(density, defaultBringIntoViewSpec, verticalState) {
        val topInset = with(density) { 40.dp.toPx() }
        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        object : BringIntoViewSpec {
            override val scrollAnimationSpec = defaultBringIntoViewSpec.scrollAnimationSpec

            override fun calculateScrollDistance(offset: Float, size: Float, containerSize: Float): Float {
                if (suspendVerticalAlignment || kotlin.math.abs(offset - topInset) < 1f) return 0f
                val distance = offset - topInset
                if (distance < 0f && !verticalState.canScrollBackward) return 0f
                return distance
            }
        }
    }

    // Read-only, rate-limited observation of actual LazyColumn movement.
    LaunchedEffect(verticalState) {
        if (!PerformanceDiagnostics.isCollecting()) return@LaunchedEffect
        var lastLoggedAt = 0L
        var previousIndex = -1
        var previousOffset = -1
        var previousMoving = false
        snapshotFlow {
            Triple(verticalState.firstVisibleItemIndex,
                verticalState.firstVisibleItemScrollOffset, verticalState.isScrollInProgress)
        }.collect { (index, offset, moving) ->
            val now = android.os.SystemClock.uptimeMillis()
            val changed = index != previousIndex || offset != previousOffset || moving != previousMoving
            val boundary = moving != previousMoving || index != previousIndex
            if (changed && (boundary || now - lastLoggedAt >= 220L)) {
                traceHome {
                    "HOME_SCROLL_STATE axis=vertical index=$index offset=$offset moving=$moving " +
                        "navigation=${currentNavigationVisible}"
                }
                lastLoggedAt = now
            }
            previousIndex = index
            previousOffset = offset
            previousMoving = moving
        }
    }

    // Freeze the hero while the row list is moving. Nuvio keeps its last
    // committed hero scene through rapid vertical navigation and updates after
    // the selected row settles, rather than switching artwork every repeat.
    LaunchedEffect(verticalState) {
        snapshotFlow { verticalState.isScrollInProgress || fastVerticalScrolling }
            .distinctUntilChanged()
            .collect { currentMotionCallback(it) }
    }

    val currentViewportCallback by rememberUpdatedState(onCatalogViewportChanged)
    LaunchedEffect(active, verticalState) {
        if (!active) return@LaunchedEffect
        snapshotFlow {
            val layout = verticalState.layoutInfo
            val visible = layout.visibleItemsInfo.filter {
                it.offset < layout.viewportEndOffset && it.offset + it.size > layout.viewportStartOffset
            }
            val first = visible.firstOrNull()?.index ?: 0
            val last = visible.lastOrNull()?.index ?: first
            currentRows.subList(first.coerceAtMost(currentRows.size), (last + 3).coerceAtMost(currentRows.size))
                .map { it.key }
        }.collect { currentViewportCallback(it) }
    }
    DisposableEffect(active) {
        onDispose { if (active) currentViewportCallback(emptyList()) }
    }

    val context = LocalContext.current.applicationContext
    LaunchedEffect(active, rowsLayout.portraitCards, verticalState, density) {
        if (!active) return@LaunchedEffect
        val portrait = rowsLayout.portraitCards
        snapshotFlow {
            if (fastVerticalScrolling || verticalState.isScrollInProgress || routeReturnPendingState.value) {
                emptyList()
            } else {
                val layout = verticalState.layoutInfo
                val last = layout.visibleItemsInfo.lastOrNull { it.offset < layout.viewportEndOffset }?.index
                if (last == null) emptyList() else currentRows.drop(last + 1).take(2)
            }
        }.collectLatest { upcomingRows ->
            if (upcomingRows.isEmpty()) return@collectLatest
            delay(150L)
            for (row in upcomingRows) {
                val media = row.entries.firstOrNull()?.media ?: continue
                val landscape = !portrait && row.kind == TvHomeRowKind.CONTINUE_WATCHING
                val url = if (landscape) media.background ?: media.poster else media.poster ?: media.background
                val size = with(density) {
                    IntSize(
                        (if (portrait) PosterWidth else row.kind.cardWidth).roundToPx(),
                        (if (portrait) MODERN_HOME_POSTER_HEIGHT else row.kind.cardHeight).roundToPx(),
                    )
                }
                tvPrefetchImage(context, url, size)
            }
        }
    }

    fun resolveVerticalLanding(direction: Int): String? {
        val layout = verticalState.layoutInfo
        val rowsByKey = currentRows.associateBy { it.key }
        val visible = layout.visibleItemsInfo.filter {
            (it.key as? String)?.let(rowsByKey::get)?.entries?.isNotEmpty() == true
        }
        val lastKey = currentRows.lastOrNull { it.entries.isNotEmpty() }?.key
        val lastRowAtBottom = visible.lastOrNull()?.takeIf {
            it.key == lastKey && it.offset + it.size <= layout.viewportEndOffset
        }
        val upwardTopRow = if (direction < 0) visible.firstOrNull()?.takeIf {
            it.offset > -it.size / 2
        } else null
        val target = lastRowAtBottom ?: upwardTopRow ?: visible.firstOrNull { it.offset >= 0 }
            ?: visible.firstOrNull()
        val row = (target?.key as? String)?.let(rowsByKey::get)
            ?: TvHomeFocusMemory.activeRowKey?.let(rowsByKey::get) ?: return null
        if (row.entries.isEmpty()) return null
        val index = row.savedFocusIndex()
        val key = row.entries[index].key
        verticalFocusToken++
        verticalFocusTarget = HomeVerticalFocusTarget(
            row.key, index, verticalFocusToken, fastLanding = true, cardKey = key,
        )
        return key
    }

    // Initial Home focus is separate from horizontal LazyRow position.
    // If Source navigation disposed Home, its new composition must recover the
    // saved row/card rather than resetting to row 1 when returning from Details.
    val hasFocusableRows = rows.any { it.entries.isNotEmpty() }
    LaunchedEffect(focusResetToken, hasFocusableRows, navigationVisible, routeReturnPending) {
        if (focusResetToken <= 0 || appliedFocusResetToken == focusResetToken ||
            !hasFocusableRows || navigationVisible || routeReturnPending
        ) return@LaunchedEffect
        val savedRowKey = TvHomeFocusMemory.activeRowKey
        val targetRowIndex = rows.indexOfFirst { it.key == savedRowKey && it.entries.isNotEmpty() }
            .takeIf { it >= 0 } ?: rows.indexOfFirst { it.entries.isNotEmpty() }
                .takeIf { it >= 0 } ?: return@LaunchedEffect
        appliedFocusResetToken = focusResetToken
        val targetRow = rows[targetRowIndex]
        val targetCardIndex = (TvHomeFocusMemory.focusedIndexByRow[targetRow.key] ?: 0)
            .coerceIn(0, targetRow.entries.lastIndex)
        TvHomeFocusMemory.activeRowKey = targetRow.key
        TvHomeFocusMemory.focusedIndexByRow[targetRow.key] = targetCardIndex
        verticalFocusTarget = null
        fastVerticalScrolling = false
        traceHome {
            "HOME_SCROLL_COMMAND axis=vertical cause=initial_focus_restore target=${targetRow.key} " +
                "card=$targetCardIndex from=${verticalState.firstVisibleItemIndex}:${verticalState.firstVisibleItemScrollOffset}"
        }
        verticalState.scrollToItem(targetRowIndex, 0)
        if (!currentNavigationVisible) {
            verticalFocusToken += 1
            verticalFocusTarget = HomeVerticalFocusTarget(
                targetRow.key, targetCardIndex, verticalFocusToken, initialReset = true,
            )
            PerformanceDiagnostics.captureRuntimeEvent(
                "HOME_FOCUS_TARGET row=${targetRow.key} card=$targetCardIndex saved=${savedRowKey != null}",
            )
        }
    }

    val newRailExists = rows.any { it.key == NEW_EPISODES_ROW_KEY && it.entries.isNotEmpty() }
    LaunchedEffect(newRailExists, active, routeReturnPending, navigationOwnsFocus, navigationVisible) {
        if (newRailExists || !active || routeReturnPending || navigationOwnsFocus || navigationVisible ||
            TvHomeFocusMemory.activeRowKey != NEW_EPISODES_ROW_KEY) return@LaunchedEffect
        val available = currentRows
        val targetIndex = available.indexOfFirst { it.entries.isNotEmpty() }
        if (targetIndex < 0) {
            onUpFromFirstRow()
            return@LaunchedEffect
        }
        val row = available[targetIndex]
        fastVerticalScrolling = false
        TvHomeFocusMemory.activeRowKey = row.key
        verticalState.scrollToItem(targetIndex)
        if (!currentNavigationVisible) {
            verticalFocusToken += 1
            verticalFocusTarget = HomeVerticalFocusTarget(row.key, 0, verticalFocusToken)
        }
    }

    // Opening navigation revokes pending row commands without scrolling to a preview.
    // Keys exclude rows, so progressive catalog batches cannot restart this effect.
    LaunchedEffect(navigationVisible) {
        if (navigationVisible) {
            traceHome {
                "HOME_NAV_OPEN autoScrollCW=false activeRow=${TvHomeFocusMemory.activeRowKey} " +
                    "vertical=${verticalState.firstVisibleItemIndex}:${verticalState.firstVisibleItemScrollOffset}"
            }
            verticalFocusTarget = null
            fastVerticalScrolling = false
            previewReturnRowKey = TvHomeFocusMemory.activeRowKey
            previewReturnCardIndex = previewReturnRowKey?.let {
                TvHomeFocusMemory.focusedIndexByRow[it]
            } ?: 0
            // Isolation test: opening the sidebar must not auto-scroll the catalog
            // to Continue Watching. Keep CW, viewport motion, and focus memory intact.
        }
    }

    // Scroll first while the menu still owns focus. Then address the exact saved
    // card, even when the original deep row is no longer composed.
    val preserveTopbarViewport = tvSidebarIsPillMode()
    LaunchedEffect(contentReturnToken, navigationVisible, preserveTopbarViewport) {
        if (contentReturnToken <= 0 || appliedContentReturnToken == contentReturnToken ||
            !navigationVisible
        ) return@LaunchedEffect
        appliedContentReturnToken = contentReturnToken
        val availableRows = currentRows
        val row = availableRows.firstOrNull { it.key == previewReturnRowKey && it.entries.isNotEmpty() }
            ?: availableRows.firstOrNull { it.key == TvHomeFocusMemory.activeRowKey && it.entries.isNotEmpty() }
            ?: availableRows.firstOrNull { it.entries.isNotEmpty() }
            ?: return@LaunchedEffect
        if (row.entries.isEmpty()) return@LaunchedEffect
        val cardIndex = (if (row.key == previewReturnRowKey) previewReturnCardIndex else
            TvHomeFocusMemory.focusedIndexByRow[row.key] ?: 0).coerceIn(0, row.entries.lastIndex)
        verticalFocusTarget = null
        fastVerticalScrolling = false
        traceHome {
            "HOME_SCROLL_COMMAND axis=vertical cause=nav_return target=${row.key} card=$cardIndex " +
                "from=${verticalState.firstVisibleItemIndex}:${verticalState.firstVisibleItemScrollOffset}"
        }
        try {
            val layout = verticalState.layoutInfo
            val rowFullyVisible = layout.visibleItemsInfo.any {
                it.key == row.key && it.offset >= layout.viewportStartOffset &&
                    it.offset + it.size <= layout.viewportEndOffset
            }
            // The Topbar overlays a stable viewport. A visible row can receive
            // its saved focus without scrolling back to its leading edge.
            if (!preserveTopbarViewport || !rowFullyVisible) {
                verticalState.scrollToItem(availableRows.indexOfFirst { it.key == row.key }, 0)
            }
            traceHome {
                "HOME_SCROLL_FINISH axis=vertical cause=nav_return target=${row.key} " +
                    "at=${verticalState.firstVisibleItemIndex}:${verticalState.firstVisibleItemScrollOffset}"
            }
        } catch (cancelled: CancellationException) {
            traceHome { "HOME_SCROLL_FINISH axis=vertical cause=nav_return outcome=cancelled target=${row.key}" }
            throw cancelled
        }
        if (!currentNavigationVisible) return@LaunchedEffect
        verticalFocusToken += 1
        verticalFocusTarget = HomeVerticalFocusTarget(row.key, cardIndex, verticalFocusToken, menuReturn = true)
    }

    val focusRestorer = remember {
        {
            rowFocusRequesters[TvHomeFocusMemory.activeRowKey ?: initialActiveRowKey]
                ?: rowFocusRequesters[initialActiveRowKey]
                ?: FocusRequester.Default
        }
    }

    CompositionLocalProvider(LocalBringIntoViewSpec provides verticalBringIntoViewSpec) {
        LazyColumn(
            state = verticalState,
            modifier = modifier
                .fillMaxWidth()
                .height(rowsLayout.viewportHeight)
                .onPreviewKeyEvent { event ->
                    if (!active || navigationVisible || routeReturnPending ||
                        fastVerticalScrolling || event.type != KeyEventType.KeyDown ||
                        event.nativeKeyEvent.repeatCount != 0
                    ) return@onPreviewKeyEvent false
                    val activeRow = TvHomeFocusMemory.activeRowKey
                    if (event.key == Key.DirectionUp &&
                        activeRow == currentRows.firstOrNull { it.entries.isNotEmpty() }?.key
                    ) {
                        onUpFromFirstRow()
                        true
                    } else {
                        event.key == Key.DirectionDown &&
                            activeRow == currentRows.lastOrNull { it.entries.isNotEmpty() }?.key
                    }
                }
                .then(
                    if (active && !navigationVisible && !routeReturnPending) Modifier.dpadVerticalFastScroll(
                        scrollableState = verticalState,
                        onFastScrollingChanged = { scrolling ->
                            fastVerticalScrolling = scrolling
                            if (scrolling) verticalFocusTarget = null
                        },
                        shouldHaltForward = {
                            val layout = verticalState.layoutInfo
                            val last = currentRows.lastOrNull()
                            last != null && layout.visibleItemsInfo.any {
                                it.key == last.key && it.offset + it.size <= layout.viewportEndOffset
                            }
                        },
                        resolveVerticalLanding = ::resolveVerticalLanding,
                    ) else Modifier,
                )
                .focusRequester(contentFocusRequester)
                .focusRestorer { focusRestorer() }
                .onFocusChanged { state ->
                    if (state.hasFocus && !currentNavigationVisible) onContentFocused()
                },
            contentPadding = PaddingValues(bottom = rowsLayout.bottomPadding),
            verticalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            itemsIndexed(
                items = rows,
                key = { _, row -> row.key },
                contentType = { _, row -> row.kind },
            ) { rowIndex, row ->
                if (row.entries.isEmpty()) {
                    Column(
                        Modifier.padding(start = rowsLayout.startPadding),
                        verticalArrangement = Arrangement.spacedBy(RowTitleSpacing),
                    ) {
                        Text(row.title, color = TvDesign.White, fontSize = 16.sp, lineHeight = RowTitleLineHeight)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            repeat(5) {
                                Box(Modifier.width(PosterWidth).height(MODERN_HOME_POSTER_HEIGHT)
                                    .background(TvDesign.SurfaceRaised, PosterShape))
                            }
                        }
                    }
                    return@itemsIndexed
                }
                val rowVisible by remember(verticalState, row.key) {
                    derivedStateOf {
                        verticalState.layoutInfo.visibleItemsInfo.any {
                            it.key == row.key && it.offset < verticalState.layoutInfo.viewportEndOffset &&
                                it.offset + it.size > verticalState.layoutInfo.viewportStartOffset
                        }
                    }
                }
                val rowState = remember(row.key) {
                    rowListStates.getOrPut(row.key) {
                        val position = TvHomeFocusMemory.horizontalPositionByRow[row.key]
                        LazyListState(
                            firstVisibleItemIndex = (position?.firstVisibleItemIndex ?: 0)
                                .coerceIn(0, row.entries.lastIndex.coerceAtLeast(0)),
                            firstVisibleItemScrollOffset = position?.firstVisibleItemScrollOffset
                                ?.coerceAtLeast(0) ?: 0,
                        )
                    }
                }
                TvModernHomeRow(
                    rowVisible = rowVisible,
                    rowsLayout = rowsLayout,
                    row = row,
                    rowState = rowState,
                    rowFocusRequester = rowFocusRequesters.getOrPut(row.key) { FocusRequester() },
                    // Do not invalidate the focused card during panel enter.
                    // Once the nav item actually owns focus, allow only an
                    // explicit menu-return target back into the catalog.
                    active = active,
                    routeReturnPending = routeReturnPending,
                    contentFocusEnabled = !navigationOwnsFocus ||
                        (verticalFocusTarget?.menuReturn == true && verticalFocusTarget?.rowKey == row.key),
                    verticalFocusTarget = verticalFocusTarget?.takeIf { it.rowKey == row.key },
                    onFocusTargetConsumed = { token, focused ->
                        val target = verticalFocusTarget
                        if (target?.token == token) {
                            traceHome {
                                "HOME_FOCUS_RESULT row=${target.rowKey} card=${target.cardIndex} " +
                                    "token=$token success=$focused menuReturn=${target.menuReturn} initial=${target.initialReset}"
                            }
                            if (target.initialReset) {
                                PerformanceDiagnostics.captureRuntimeEvent(
                                    "HOME_FOCUS_RESTORED row=${target.rowKey} card=${target.cardIndex} success=$focused",
                                )
                            }
                            if (target.routeReturn) {
                                onRouteFocusRestored()
                                traceHome { "HOME_ROUTE_FOCUS_RESULT success=$focused row=${target.rowKey} card=${target.cardIndex}" }
                            }
                            if (target.menuReturn && focused) onContentFocused()
                            if (target.fastLanding) fastVerticalScrolling = false
                            verticalFocusTarget = null
                        }
                    },
                    onContentFocused = onContentFocused,
                    onLeftAtRowStart = onLeftAtRowStart,
                    onCatalogPageNeeded = onCatalogPageNeeded,
                    onFocused = { focusedRow, index, entry ->
                        onFocused(focusedRow, index, entry)
                    },
                    onOpen = { entry ->
                        val cardIndex = row.entries.indexOfFirst { it.key == entry.key }.coerceAtLeast(0)
                        onCaptureRouteFocusAnchor(HomeRouteFocusAnchor(
                            row.key, entry.key, cardIndex,
                            TvHomeHorizontalPosition(rowState.firstVisibleItemIndex, rowState.firstVisibleItemScrollOffset),
                            verticalState.firstVisibleItemIndex, verticalState.firstVisibleItemScrollOffset,
                            horizontalFirstCardKey = row.entries.getOrNull(rowState.firstVisibleItemIndex)?.key,
                            capturedRowIndex = rowIndex,
                            verticalFirstRowKey = currentRows.getOrNull(verticalState.firstVisibleItemIndex)?.key,
                        ))
                        onOpen(entry)
                    },
                    onPosterLongClick = { entry ->
                        if (row.isDynamicEpisodeRail()) {
                            onCaptureRouteFocusAnchor(HomeRouteFocusAnchor(
                                row.key, entry.key, row.entries.indexOfFirst { it.key == entry.key }.coerceAtLeast(0),
                                TvHomeHorizontalPosition(rowState.firstVisibleItemIndex, rowState.firstVisibleItemScrollOffset),
                                verticalState.firstVisibleItemIndex, verticalState.firstVisibleItemScrollOffset,
                                horizontalFirstCardKey = row.entries.getOrNull(rowState.firstVisibleItemIndex)?.key,
                                capturedRowIndex = rowIndex,
                                verticalFirstRowKey = currentRows.getOrNull(verticalState.firstVisibleItemIndex)?.key,
                            ))
                        }
                        onPosterLongClick(entry)
                    },
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
@Composable
private fun TvModernHomeRow(
    row: TvHomeRow,
    rowVisible: Boolean,
    rowsLayout: HomeRowsLayout,
    rowState: LazyListState,
    rowFocusRequester: FocusRequester,
    contentFocusEnabled: Boolean,
    active: Boolean,
    routeReturnPending: Boolean,
    verticalFocusTarget: HomeVerticalFocusTarget?,
    onFocusTargetConsumed: (Int, Boolean) -> Unit,
    onContentFocused: () -> Unit,
    onLeftAtRowStart: (() -> Unit)?,
    onCatalogPageNeeded: (TvHomeRow, Int) -> Boolean,
    onFocused: (TvHomeRow, Int, TvHomeEntry) -> Unit,
    onOpen: (TvHomeEntry) -> Unit,
    onPosterLongClick: (TvHomeEntry) -> Unit,
) {
    var rowHasFocus by remember(row.key) { mutableStateOf(false) }
    val pinnableRow = LocalPinnableContainer.current
    // Retain the originating row while it still owns D-pad focus, even once
    // vertical scrolling moves it outside the lazy column's cache window.
    DisposableEffect(pinnableRow, rowHasFocus, active) {
        val pin = if (rowHasFocus && active) pinnableRow?.pin() else null
        onDispose { pin?.release() }
    }
    val savedIndex = row.savedFocusIndex()
    var focusedIndex by remember(row.key) { mutableIntStateOf(savedIndex) }
    // Persist the actual viewport index + pixel offset, NOT the focused card.
    DisposableEffect(row.key, rowState) {
        onDispose {
            TvHomeFocusMemory.horizontalPositionByRow[row.key] = TvHomeHorizontalPosition(
                rowState.firstVisibleItemIndex, rowState.firstVisibleItemScrollOffset,
            )
        }
    }
    val itemFocusRequesters = remember(row.key) { mutableMapOf<Int, FocusRequester>() }
    val cwFocusRequesters = remember(row.key) { mutableMapOf<String, FocusRequester>() }
    var focusedCardKey by remember(row.key) { mutableStateOf<String?>(null) }
    var fallbackFocusKey by remember(row.key) { mutableStateOf<String?>(null) }
    val currentRow by rememberUpdatedState(row)
    val currentContentFocusEnabled by rememberUpdatedState(contentFocusEnabled)
    val currentActive by rememberUpdatedState(active)
    val currentRouteReturnPending by rememberUpdatedState(routeReturnPending)
    val suppressRouteBringIntoView by rememberUpdatedState(!active || routeReturnPending)

    val density = LocalDensity.current
    val rowHorizontalPadding = rowsLayout.startPadding
    val cardHeight = if (rowsLayout.portraitCards) MODERN_HOME_POSTER_HEIGHT else row.kind.cardHeight

    val isContinueWatching = row.kind == TvHomeRowKind.CONTINUE_WATCHING
    val horizontalBringIntoViewSpec = remember {
        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        object : BringIntoViewSpec {
            override val scrollAnimationSpec: AnimationSpec<Float> = HomeHorizontalFocusSpring

            override fun calculateScrollDistance(
                offset: Float,
                size: Float,
                containerSize: Float,
            ): Float = if (suppressRouteBringIntoView) 0f else offset
        }
    }

    val context = LocalContext.current.applicationContext
    LaunchedEffect(rowVisible, active, rowState, row.entries, rowsLayout.portraitCards, density) {
        if (!rowVisible || !active) return@LaunchedEffect
        val portrait = rowsLayout.portraitCards
        val size = with(density) {
            IntSize(
                (if (portrait) PosterWidth else row.kind.cardWidth).roundToPx(),
                (if (portrait) MODERN_HOME_POSTER_HEIGHT else row.kind.cardHeight).roundToPx(),
            )
        }
        snapshotFlow {
            if (rowState.isScrollInProgress) null else rowState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
        }.collectLatest { lastVisible ->
            if (lastVisible == null) return@collectLatest
            delay(150L)
            for (index in (lastVisible + 1)..(lastVisible + 2)) {
                val entry = row.entries.getOrNull(index) ?: continue
                val media = entry.media
                val landscape = !portrait && row.kind == TvHomeRowKind.CONTINUE_WATCHING
                val url = if (landscape) media.background ?: media.poster else media.poster ?: media.background
                tvPrefetchImage(context, url, size)
            }
        }
    }

    val currentPageRequest by rememberUpdatedState(onCatalogPageNeeded)
    LaunchedEffect(rowVisible, active, rowState, row.entries.size) {
        if (!rowVisible || !active) return@LaunchedEffect
        snapshotFlow {
            val layout = rowState.layoutInfo
            layout.visibleItemsInfo.lastOrNull { it.offset < layout.viewportEndOffset }?.index
        }.collect { index ->
            if (index != null && index >= currentRow.entries.size - 4) {
                currentPageRequest(currentRow, index)
            }
        }
    }

    // Read-only horizontal trace. It runs only for rows on screen during recording.
    LaunchedEffect(row.key, rowVisible, rowState) {
        if (!rowVisible || !PerformanceDiagnostics.isCollecting()) return@LaunchedEffect
        var lastLoggedAt = 0L
        var oldIndex = -1
        var oldOffset = -1
        var oldMoving = false
        snapshotFlow {
            Triple(rowState.firstVisibleItemIndex,
                rowState.firstVisibleItemScrollOffset, rowState.isScrollInProgress)
        }.collect { (index, offset, moving) ->
            val now = android.os.SystemClock.uptimeMillis()
            val changed = index != oldIndex || offset != oldOffset || moving != oldMoving
            val boundary = oldIndex != index || oldMoving != moving
            if (changed && (boundary || now - lastLoggedAt >= 220L)) {
                traceHome {
                    "HOME_SCROLL_STATE axis=horizontal row=${row.key} index=$index offset=$offset " +
                        "moving=$moving focusedCard=$focusedIndex"
                }
                lastLoggedAt = now
            }
            oldIndex = index
            oldOffset = offset
            oldMoving = moving
        }
    }

    // A returning card follows its identity when a row changes during restoration.
    val returnKeys = if(verticalFocusTarget?.routeReturn == true)
        row.entries.map { it.key } else null
    LaunchedEffect(verticalFocusTarget?.token, contentFocusEnabled, active, returnKeys) {
        val target = verticalFocusTarget ?: return@LaunchedEffect
        if (!active || !contentFocusEnabled || target.rowKey != row.key || row.entries.isEmpty()) return@LaunchedEffect
        fun resolveTargetIndex(): Int? {
            val entries = if(target.cardKey != null) currentRow.entries else row.entries
            if(entries.isEmpty()) return null
            return target.cardKey?.let { key -> entries.indexOfFirst { it.key == key }.takeIf { it >= 0 } }
                ?: target.cardIndex.coerceIn(0, entries.lastIndex)
        }

        // Nuvio uses pendingRowFocus -> scrollToItem(index) before focus.
        // Snap only when necessary: if the row is already at Card 3, an
        // Up/Down return changes focus but does not animate horizontal scroll.
        // Do NOT change the policy for ordinary Left/Right navigation.
        for (attempt in 0 until 4) {
            if (rowState.layoutInfo.visibleItemsInfo.isNotEmpty()) break
            withFrameNanos { }
        }
        if (!currentContentFocusEnabled) return@LaunchedEffect
        val targetIndex = resolveTargetIndex() ?: return@LaunchedEffect
        val visibleTarget = rowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == targetIndex }

        val entries = if(target.cardKey != null) currentRow.entries else row.entries
        val restoreIndex = target.restoreFirstCardKey?.let { key ->
            entries.indexOfFirst { it.key == key }.takeIf { it >= 0 }
        } ?: target.restorePosition?.firstVisibleItemIndex
            ?.coerceIn(0, entries.lastIndex) ?: targetIndex
        val savedStartMissing = target.restoreFirstCardKey != null &&
            entries.none { it.key == target.restoreFirstCardKey }
        val viewportIndex = if (savedStartMissing) targetIndex else restoreIndex
        val restoreOffset = if (savedStartMissing) 0 else target.restorePosition?.firstVisibleItemScrollOffset ?: 0
        val alreadyAnchored = rowState.firstVisibleItemIndex == viewportIndex &&
            rowState.firstVisibleItemScrollOffset == restoreOffset
        if (!alreadyAnchored && (target.routeReturn || visibleTarget == null)) {
            traceHome {
                "HOME_SCROLL_COMMAND axis=horizontal cause=nuvio_pending_row_focus row=${row.key} " +
                    "targetCard=$targetIndex from=${rowState.firstVisibleItemIndex}:${rowState.firstVisibleItemScrollOffset}"
            }
            if (target.routeReturn) {
                rowState.scrollToItem(viewportIndex, restoreOffset)
            } else {
                val layout = rowState.layoutInfo
                val lastVisible = layout.visibleItemsInfo.lastOrNull()
                val offset = if (lastVisible != null && targetIndex > lastVisible.index) {
                    (layout.viewportEndOffset - layout.viewportStartOffset - lastVisible.size)
                        .coerceAtLeast(0)
                } else 0
                rowState.scrollToItem(targetIndex, -offset)
            }
            withFrameNanos { }
        }

        repeat(if (target.routeReturn) 12 else 6) {
            if (!currentActive || !currentContentFocusEnabled) return@LaunchedEffect
            val liveIndex = resolveTargetIndex() ?: return@LaunchedEffect
            val liveKey = if(target.cardKey != null) currentRow.entries.getOrNull(liveIndex)?.key else null
            val layout = rowState.layoutInfo
            if (liveKey != null && layout.visibleItemsInfo.none {
                    it.key == liveKey && it.offset >= layout.viewportStartOffset &&
                        it.offset + it.size <= layout.viewportEndOffset
                }
            ) {
                // A reorder can separate the focused title from the captured first visible title.
                // Keep the return target visible instead of focusing another item at its old index.
                rowState.scrollToItem(liveIndex)
                withFrameNanos { }
                return@repeat
            }
            val requester = if (liveKey != null && row.isDynamicEpisodeRail())
                cwFocusRequesters[liveKey] else itemFocusRequesters[liveIndex]
            val focused = requester?.let { runCatching { it.requestFocus() }.getOrDefault(false) } == true
            if (focused) {
                traceHome {
                    "HOME_FOCUS_RESULT row=${row.key} card=$liveIndex key=$liveKey " +
                        "horizontal=${rowState.firstVisibleItemIndex}:${rowState.firstVisibleItemScrollOffset}"
                }
                if (target.routeReturn) {
                    // Let focus-triggered bring-into-view settle while still suppressed.
                    repeat(2) { withFrameNanos { } }
                }
                if(liveKey != null && (currentRow.entries.getOrNull(resolveTargetIndex() ?: -1)?.key != liveKey || focusedCardKey != liveKey)) {
                    withFrameNanos { }
                    return@repeat
                }
                onFocusTargetConsumed(target.token, true)
                return@LaunchedEffect
            }
            withFrameNanos { }
        }
        // The saved card may have disappeared or failed to attach. Keep
        // navigation usable by accepting a measured, visible card instead.
        val fallbackLayout = rowState.layoutInfo
        val visibleCards = fallbackLayout.visibleItemsInfo.filter {
            it.offset < fallbackLayout.viewportEndOffset &&
                it.offset + it.size > fallbackLayout.viewportStartOffset
        }
        for (item in visibleCards) {
            val key = currentRow.entries.getOrNull(item.index)?.key ?: continue
            val requester = if (row.isDynamicEpisodeRail()) cwFocusRequesters[key]
                else itemFocusRequesters[item.index]
            fallbackFocusKey = key
            val accepted = requester?.let { runCatching { it.requestFocus() }.getOrDefault(false) } == true
            fallbackFocusKey = null
            if (accepted && focusedCardKey == key) {
                onFocusTargetConsumed(target.token, true)
                return@LaunchedEffect
            }
        }
        onFocusTargetConsumed(target.token, false)
    }

    Column(
        verticalArrangement = Arrangement.spacedBy(RowTitleSpacing),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = rowHorizontalPadding, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = row.title,
                color = TvDesign.White.copy(alpha = .94f),
                fontSize = 18.sp,
                lineHeight = RowTitleLineHeight,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).alignByBaseline(),
            )
            row.providerName?.let { providerName ->
                Text(
                    text = providerName,
                    color = TvDesign.White.copy(alpha = .50f),
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 180.dp).alignByBaseline(),
                )
            }
        }

        CompositionLocalProvider(LocalBringIntoViewSpec provides horizontalBringIntoViewSpec) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = rowHorizontalPadding)
                    .clipToBounds()
                    .drawWithContent {
                        drawContent()
                        if (!rowsLayout.fixedFocus || !rowHasFocus) return@drawWithContent
                        val layout = rowState.layoutInfo
                        val focusedItem = layout.visibleItemsInfo.firstOrNull { it.key == focusedCardKey }
                            ?: return@drawWithContent
                        val anchor = 0f
                        // At the end of the row, use the focused card's projected
                        // position after the remaining scroll distance is consumed.
                        val last = layout.visibleItemsInfo.lastOrNull()
                        val left = when {
                            suppressRouteBringIntoView -> focusedItem.offset.toFloat()
                            last?.index == layout.totalItemsCount - 1 -> {
                                val remaining = (
                                    last.offset + last.size - layout.viewportEndOffset + layout.afterContentPadding
                                ).coerceAtLeast(0)
                                maxOf(anchor, focusedItem.offset.toFloat() - remaining)
                            }
                            else -> anchor
                        }
                        val border = 2.dp.toPx()
                        drawRoundRect(
                            color = Color.White,
                            topLeft = Offset(left + border / 2f, anchor + border / 2f),
                            size = Size(focusedItem.size - border, cardHeight.toPx() - border),
                            cornerRadius = CornerRadius(11.dp.toPx()),
                            style = Stroke(border),
                        )
                    },
            ) {
                LazyRow(
                    state = rowState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .onPreviewKeyEvent { event ->
                            if (event.type == KeyEventType.KeyDown && event.key == Key.DirectionRight &&
                                focusedIndex == row.entries.lastIndex
                            ) {
                                return@onPreviewKeyEvent onCatalogPageNeeded(row, focusedIndex)
                            }
                            false
                        }
                        .focusRequester(rowFocusRequester)
                        .focusRestorer {
                            // Match Nuvio: restore the last focused card in this
                            // row, not an arbitrary first visible item.
                            val saved = row.savedFocusIndex(focusedIndex)
                            itemFocusRequesters[saved]
                                ?: itemFocusRequesters[0]
                                ?: FocusRequester.Default
                        }
                        .onFocusChanged { rowHasFocus = it.hasFocus }
                        .focusGroup(),
                    contentPadding = PaddingValues(
                        end = if (isContinueWatching) rowHorizontalPadding else 32.dp,
                    ),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    itemsIndexed(
                        items = row.entries,
                        key = { _, entry -> entry.key },
                    ) { index, entry ->
                        val itemRequester = if(row.isDynamicEpisodeRail()) {
                            cwFocusRequesters.getOrPut(entry.key) { FocusRequester() }.also { requester ->
                                itemFocusRequesters.entries.removeAll { it.value === requester && it.key != index }
                                itemFocusRequesters[index] = requester
                            }
                        } else itemFocusRequesters.getOrPut(index) { FocusRequester() }
                        val openPosterActions = { onPosterLongClick(entry) }
                        val cardVisible by remember(rowState, index) {
                            derivedStateOf {
                                rowState.layoutInfo.visibleItemsInfo.any {
                                    it.index == index && it.offset < rowState.layoutInfo.viewportEndOffset &&
                                        it.offset + it.size > rowState.layoutInfo.viewportStartOffset
                                }
                            }
                        }
                        val imageActivated = remember(entry.key) { booleanArrayOf(false) }
                        if (rowVisible && cardVisible) {
                            imageActivated[0] = true
                        }
                        TvModernHomeCard(
                            loadImage = imageActivated[0],
                            portraitCards = rowsLayout.portraitCards,
                            entry = entry,
                            kind = row.kind,
                            requester = itemRequester,
                            contentFocusEnabled = contentFocusEnabled,
                            fixedFocus = rowsLayout.fixedFocus,
                            onLeftAtStart = onLeftAtRowStart.takeIf { index == 0 },
                            onFocusAcquired = { focusedCardKey = entry.key },
                            onFocused = {
                                val returningToThisCard = verticalFocusTarget?.let {
                                    it.routeReturn && (if(it.cardKey != null) it.cardKey == entry.key else it.cardIndex == index)
                                } == true
                                if (currentActive && currentContentFocusEnabled &&
                                    (!currentRouteReturnPending || returningToThisCard || fallbackFocusKey == entry.key)
                                ) {
                                    traceHome {
                                        "HOME_FOCUS_CARD row=${row.key} fromCard=$focusedIndex toCard=$index " +
                                            "horizontal=${rowState.firstVisibleItemIndex}:${rowState.firstVisibleItemScrollOffset} " +
                                            "horizontalMoving=${rowState.isScrollInProgress}"
                                    }
                                    focusedIndex = index
                                    TvHomeFocusMemory.activeRowKey = row.key
                                    TvHomeFocusMemory.focusedIndexByRow[row.key] = index
                                    TvHomeFocusMemory.focusedKeyByRow[row.key] = entry.key
                                    onContentFocused()
                                    onFocused(row, index, entry)
                                }
                            },
                            onOpen = { onOpen(entry) },
                            onHold = openPosterActions,
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TvModernHomeCard(
    entry: TvHomeEntry,
    loadImage: Boolean,
    portraitCards: Boolean,
    kind: TvHomeRowKind,
    requester: FocusRequester,
    contentFocusEnabled: Boolean,
    fixedFocus: Boolean,
    onLeftAtStart: (() -> Unit)?,
    onFocusAcquired: () -> Unit,
    onFocused: () -> Unit,
    onOpen: () -> Unit,
    onHold: () -> Unit,
) {
    var focused by remember(entry.key) { mutableStateOf(false) }
    val isContinueWatching = kind == TvHomeRowKind.CONTINUE_WATCHING

    val width = if (portraitCards) PosterWidth else kind.cardWidth
    val height = if (portraitCards) MODERN_HOME_POSTER_HEIGHT else kind.cardHeight
    val shape = if (!portraitCards && (kind == TvHomeRowKind.CONTINUE_WATCHING || kind == TvHomeRowKind.COLLECTIONS)) ContinueShape else PosterShape

    // Like Nuvio's Continue Watching item, publish the focus change through
    // a composition effect once the native focus target has accepted it.
    val latestOnFocused by rememberUpdatedState(onFocused)
    if (isContinueWatching) {
        LaunchedEffect(focused) {
            if (focused) latestOnFocused()
        }
    }

    Box(
        modifier = Modifier
            .width(width)
            .height(height)
            .zIndex(if (focused) 1f else 0f)
            .focusRequester(requester)
            .focusProperties { canFocus = contentFocusEnabled }
            .onPreviewKeyEvent { event ->
                if (
                    onLeftAtStart != null &&
                    event.key == Key.DirectionLeft
                ) {
                    if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) onLeftAtStart()
                    true
                } else {
                    false
                }
            }
            .onFocusChanged { state ->
                val becameFocused = state.isFocused
                if (becameFocused && !focused) {
                    onFocusAcquired()
                    if (!isContinueWatching) onFocused()
                }
                focused = becameFocused
            }
            .clip(shape)
            .background(TvDesign.Surface)
            .border(
                width = if (focused && !fixedFocus) 2.dp else 0.dp,
                color = if (focused) TvDesign.Accent.copy(alpha = .96f) else Color.Transparent,
                shape = shape,
            )
            .tvPosterActivation(
                onClick = onOpen,
                onLongClick = onHold,
            )
            .clickable(onClick = onOpen),
    ) {
        when (kind) {
            TvHomeRowKind.CONTINUE_WATCHING -> ContinueWatchingCardContent(entry, loadImage || focused, focused, portrait = portraitCards)
            TvHomeRowKind.COLLECTIONS -> {
                TvNetworkImage(url = entry.media.poster, contentDescription = entry.media.name,
                    modifier = Modifier.fillMaxSize(), loadEnabled = loadImage || focused)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .3f)))
                Text(text = listOfNotNull((entry as? TvHomeEntry.Folder)?.folder?.coverEmoji, entry.media.name).joinToString(" "),
                    color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, modifier = Modifier.align(Alignment.Center).padding(12.dp))
            }
            TvHomeRowKind.POSTERS -> PosterCardContent(entry, loadImage || focused, focused)
        }
    }
}

@Composable
private fun PosterCardContent(entry: TvHomeEntry, loadImage: Boolean, focused: Boolean) {
    Box(Modifier.fillMaxSize()) {
        TvNetworkImage(
            url = entry.media.poster ?: entry.media.background,
            contentDescription = entry.media.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            fallback = TvDesign.SurfaceRaised,
            loadEnabled = loadImage,
            highPriority = focused,
        )
        (entry as? TvHomeEntry.Media)?.newEpisodeLabel?.let { label ->
            TvHomeCardBadge(
                text = label,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp),
            )
        }
    }
}

@Composable
private fun TvHomeCardBadge(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = TvDesign.White,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
            .background(TvDesign.Black.copy(alpha = .64f), RoundedCornerShape(50))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

@Composable
private fun ContinueWatchingCardContent(entry: TvHomeEntry, loadImage: Boolean, focused: Boolean, portrait: Boolean) {
    val resume = entry as? TvHomeEntry.Resume
    val progress = resume?.playback?.progressFraction ?: 0f

    Box(Modifier.fillMaxSize()) {
        TvNetworkImage(
            url = if (portrait) entry.media.poster ?: entry.media.background
            else entry.media.background ?: entry.media.poster,
            contentDescription = entry.media.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            fallback = TvDesign.SurfaceRaised,
            loadEnabled = loadImage,
            highPriority = focused,
        )

        if (!portrait) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Transparent,
                            .45f to Color.Transparent,
                            .78f to TvDesign.Black.copy(alpha = .72f),
                            1f to TvDesign.Black.copy(alpha = .94f),
                        )
                    )
            )

            Row(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    entry.episodeText()?.let { TvHomeCardBadge(it) }
                }
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                    entry.remainingText()?.let { TvHomeCardBadge(it) }
                }
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(start = 11.dp, end = 11.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            if (!portrait) {
                Text(
                    text = entry.media.name,
                    color = TvDesign.White,
                    fontSize = 13.sp,
                    lineHeight = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(8.dp))
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(TvDesign.White.copy(alpha = .20f), RoundedCornerShape(2.dp)),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress.coerceIn(0f, 1f))
                        .height(3.dp)
                        .background(TvDesign.Accent, RoundedCornerShape(2.dp)),
                )
            }
        }
    }
}
