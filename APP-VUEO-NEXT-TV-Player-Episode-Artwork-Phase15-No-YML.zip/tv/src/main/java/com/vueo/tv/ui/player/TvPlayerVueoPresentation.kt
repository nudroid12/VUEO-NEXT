package com.vueo.tv.player

import com.vueo.tv.ui.motion.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.List
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vueo.shared.core.enrichment.ContentWarning
import com.vueo.shared.core.media.EpisodeItem
import com.vueo.shared.core.media.MediaItem
import com.vueo.shared.core.media.StreamSource
import com.vueo.shared.core.player.PlayerSkipKind
import com.vueo.shared.core.player.PlayerSkipSegment
import com.vueo.tv.ui.TvDesign
import com.vueo.tv.ui.motion.TvMotion
import kotlinx.coroutines.delay

@Composable
internal fun VueoPlayerPresentation(
    media: MediaItem,
    episode: EpisodeItem?,
    activeSource: StreamSource,
    controlsVisible: Boolean,
    hiddenSeekProgressVisible: Boolean,
    activePanel: TvPlayerPanel,
    playing: Boolean,
    playbackRequested: Boolean,
    isBuffering: Boolean,
    playbackFeedbackToken: Int,
    playbackFeedbackPaused: Boolean,
    translatingSubtitles: Boolean,
    statusIndicatorsEnabled: Boolean,
    positionMs: Long,
    durationMs: Long,
    seekMotionDirect: Boolean,
    seekHoldActive: Boolean,
    nextEpisode: EpisodeItem?,
    activeSkip: PlayerSkipSegment?,
    nextCountdown: Int,
    contentWarnings: List<ContentWarning>,
    warningVisible: Boolean,
    onWarningComplete: () -> Unit,
    playbackError: String?,
    panelOptions: List<TvPlayerOption>,
    episodes: List<EpisodeItem>,
    watchedEpisodeKeys: Set<Pair<Int, Int>>,
    episodeProgress: Map<Pair<Int, Int>, TvEpisodeProgress>,
    hasSubtitles: Boolean,
    hasAudio: Boolean,
    hasSources: Boolean,
    sourcesSearching: Boolean,
    pluginsStopped: Boolean,
    onRefreshSources: () -> Unit,
    sourcesStopped: Boolean,
    onStopSources: () -> Unit,
    hasEpisodes: Boolean,
    restartRequester: FocusRequester,
    progressRequester: FocusRequester,
    nextRequester: FocusRequester,
    subtitlesRequester: FocusRequester,
    audioRequester: FocusRequester,
    sourcesRequester: FocusRequester,
    episodesRequester: FocusRequester,
    moreRequester: FocusRequester,
    skipRequester: FocusRequester,
    nextContextRequester: FocusRequester,
    errorRequester: FocusRequester,
    onInteraction: () -> Unit,
    onChromeInteraction: () -> Unit,
    onPromptFocused: (TvPlayerPromptTarget) -> Unit,
    onPromptNavigateUp: () -> Unit,
    onPromptNavigateDown: () -> Unit,
    onPlayPause: () -> Unit,
    onRetryPlayback: () -> Unit,
    onRestart: () -> Unit,
    onSeekImmediateBy: (Long) -> Unit,
    onSeekBy: (Long) -> Unit,
    onSeekCommit: () -> Unit,
    onNext: () -> Unit,
    onOpenPanel: (TvPlayerPanel) -> Unit,
    onDismissPanel: () -> Unit,
    onSkip: (PlayerSkipSegment) -> Unit,
    onPlayEpisode: (EpisodeItem) -> Unit,
    onPanelSelected: (TvPlayerOption) -> Unit,
) {
    val retainedPanelOptions = remember { mutableStateOf<List<TvPlayerOption>>(emptyList()) }
    LaunchedEffect(panelOptions) {
        if (panelOptions.isNotEmpty()) retainedPanelOptions.value = panelOptions
    }
    val displayedPanelOptions = panelOptions.ifEmpty { retainedPanelOptions.value }
    val progressUpRequester = when {
        playbackError != null -> errorRequester
        activeSkip != null -> skipRequester
        nextCountdown > 0 && nextEpisode != null -> nextContextRequester
        else -> restartRequester
    }

    val density = LocalDensity.current
    var bottomControlsHeight by remember { mutableStateOf(72.dp) }
    Box(Modifier.fillMaxSize()) {
        val showPrompts = activePanel == TvPlayerPanel.NONE && playbackError == null && !hiddenSeekProgressVisible
        // The progress rail is the first item in the measured bottom controls.
        // Hidden feedback has a 3dp rail above its existing 22dp bottom inset.
        val promptBottomPadding = if (controlsVisible) bottomControlsHeight + 12.dp else 22.dp + 3.dp + 12.dp
        val skipOnRight = activeSkip?.kind == PlayerSkipKind.ENDING
        val showChrome = controlsVisible && activePanel == TvPlayerPanel.NONE
        // A standalone Skip prompt must not dim the video. Full chrome, panels,
        // errors and the larger Next Episode countdown still own the cinematic scrim.
        val showScrim = showChrome ||
            activePanel != TvPlayerPanel.NONE ||
            playbackError != null ||
            (showPrompts && nextCountdown > 0 && activeSkip == null)
        AnimatedVisibility(
            visible = showScrim,
            enter = tvPlayerWorkspaceFadeIn(),
            exit = tvPlayerWorkspaceFadeOut(),
        ) {
            VueoPlayerCinematicScrim(strong = activePanel != TvPlayerPanel.NONE || playbackError != null)
        }

        VueoPlayerControls(
            visible = showChrome,
            hiddenSeekProgressVisible = hiddenSeekProgressVisible && !showChrome,
            onBottomControlsHeightChanged = { heightPx ->
                bottomControlsHeight = with(density) { heightPx.toDp() }
            },
            media = media,
            episode = episode,
            activeSource = activeSource,
            contentWarningVisible = warningVisible,
            reserveTranslationSpace = translatingSubtitles,
            playbackRequested = playbackRequested,
            positionMs = positionMs,
            durationMs = durationMs,
            seekMotionDirect = seekMotionDirect,
            seekHoldActive = seekHoldActive,
            nextEpisode = nextEpisode,
            hasSubtitles = hasSubtitles,
            hasAudio = hasAudio,
            hasSources = hasSources,
            hasEpisodes = hasEpisodes,
            restartRequester = restartRequester,
            progressRequester = progressRequester,
            progressUpRequester = progressUpRequester,
            nextRequester = nextRequester,
            subtitlesRequester = subtitlesRequester,
            audioRequester = audioRequester,
            sourcesRequester = sourcesRequester,
            episodesRequester = episodesRequester,
            moreRequester = moreRequester,
            onInteraction = onChromeInteraction,
            onPlayPause = onPlayPause,
            onRestart = onRestart,
            onSeekImmediateBy = onSeekImmediateBy,
            onSeekBy = onSeekBy,
            onSeekCommit = onSeekCommit,
            onNext = onNext,
            onOpenPanel = onOpenPanel,
        )

        if (warningVisible && contentWarnings.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 32.dp, top = 32.dp),
            ) {
                VueoContentWarningsOverlay(
                    warnings = contentWarnings,
                    onAnimationComplete = onWarningComplete,
                )
            }
        }

        if (showPrompts && (activeSkip != null || nextCountdown > 0)) {
            Row(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .padding(start = 32.dp, end = 32.dp, bottom = promptBottomPadding),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom,
            ) {
                if (activeSkip != null && !skipOnRight) {
                    VueoPlayerPromptButton(
                        text = vueoSkipLabel(activeSkip), requester = skipRequester,
                        upRequester = if (nextCountdown > 0 && nextEpisode != null) nextContextRequester else FocusRequester.Cancel,
                        downRequester = if (showChrome) progressRequester else FocusRequester.Cancel,
                        onNavigateUp = if (nextCountdown <= 0 || nextEpisode == null) onPromptNavigateUp else null,
                        onNavigateDown = if (!showChrome) onPromptNavigateDown else null,
                        onInteraction = onInteraction,
                        onFocused = { onPromptFocused(TvPlayerPromptTarget.SKIP) },
                        onClick = { onSkip(activeSkip) },
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (nextCountdown > 0 && nextEpisode != null) {
                        VueoPlayerNextEpisodeCard(
                            episode = nextEpisode,
                            fallbackImage = media.background,
                            countdown = nextCountdown,
                            requester = nextContextRequester,
                            upRequester = FocusRequester.Cancel,
                            downRequester = if (activeSkip != null) skipRequester else if (showChrome) progressRequester else FocusRequester.Cancel,
                            onInteraction = onInteraction,
                            onFocused = { onPromptFocused(TvPlayerPromptTarget.NEXT) },
                            onClick = onNext,
                        )
                    }
                    if (activeSkip != null && skipOnRight) {
                        VueoPlayerPromptButton(
                            text = vueoSkipLabel(activeSkip), requester = skipRequester,
                            upRequester = if (nextCountdown > 0 && nextEpisode != null) nextContextRequester else FocusRequester.Cancel,
                            downRequester = if (showChrome) progressRequester else FocusRequester.Cancel,
                            onNavigateUp = if (nextCountdown <= 0 || nextEpisode == null) onPromptNavigateUp else null,
                            onNavigateDown = if (!showChrome) onPromptNavigateDown else null,
                            onInteraction = onInteraction,
                            onFocused = { onPromptFocused(TvPlayerPromptTarget.SKIP) },
                            onClick = { onSkip(activeSkip) },
                        )
                    }
                }
            }
        }

        playbackError?.let { message ->
            Column(
                modifier = Modifier.align(Alignment.Center)
                    .background(Color.Black.copy(alpha = .86f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                    .padding(horizontal = 22.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(text = message, color = Color(0xFFFFB0B0), fontSize = 13.sp, lineHeight = 18.sp)
                VueoPlayerPromptButton(
                    text = "Retry", requester = errorRequester,
                    upRequester = FocusRequester.Cancel,
                    downRequester = progressRequester,
                    onInteraction = onInteraction, onClick = onRetryPlayback,
                )
            }
        }

        AnimatedVisibility(
            visible = activePanel == TvPlayerPanel.SOURCES,
            enter = tvPlayerWorkspaceFadeIn(),
            exit = tvPlayerWorkspaceFadeOut(),
        ) {
            VueoPlayerSourcesPanel(
                panelModifier = Modifier.animateEnterExit(
                    enter = tvPlayerSidePanelEnter(),
                    exit = tvPlayerSidePanelExit(),
                ),
                title = episode?.let { "S${it.season}E${it.episode} • ${it.title}" } ?: media.name,
                options = displayedPanelOptions,
                searching = sourcesSearching,
                pluginsStopped = pluginsStopped,
                onRefresh = onRefreshSources,
                sourcesStopped = sourcesStopped,
                onStop = onStopSources,
                onInteraction = onInteraction,
                onDismiss = onDismissPanel,
                onSelected = onPanelSelected,
            )
        }
        VueoPlayerStatusIndicators(
            buffering = isBuffering,
            feedbackToken = playbackFeedbackToken,
            paused = playbackFeedbackPaused,
            translating = translatingSubtitles,
            enabled = statusIndicatorsEnabled && playbackError == null && activePanel == TvPlayerPanel.NONE,
            showPlaybackFeedback = !controlsVisible,
            // 30dp margin + 42dp actions + 8dp gaps, including the gap before Restart.
            translationEndPadding = if (showChrome) {
                30.dp + (42.dp + 8.dp) * (if (nextEpisode != null) 3 else 2)
            } else 30.dp,
        )
        AnimatedVisibility(
            visible = activePanel == TvPlayerPanel.EPISODES,
            enter = tvPlayerWorkspaceFadeIn(),
            exit = tvPlayerWorkspaceFadeOut(),
        ) {
            VueoPlayerEpisodesPanel(
                panelModifier = Modifier.animateEnterExit(
                    enter = tvPlayerSidePanelEnter(),
                    exit = tvPlayerSidePanelExit(),
                ),
                mediaTitle = media.name,
                media = media,
                episodes = episodes,
                currentEpisode = episode,
                watchedEpisodeKeys = watchedEpisodeKeys,
                episodeProgress = episodeProgress,
                onInteraction = onInteraction,
                onDismiss = onDismissPanel,
                onSelected = onPlayEpisode,
            )
        }
    }
}

@Composable
private fun VueoContentWarningsOverlay(
    warnings: List<ContentWarning>,
    onAnimationComplete: () -> Unit,
) {
    val count = warnings.size
    if (count == 0) return

    val totalLineHeight = (count * 16) + ((count - 1) * 3)
    val containerAlpha = remember { Animatable(0f) }
    val lineHeightFraction = remember { Animatable(0f) }
    val itemAlphas = remember(count) { List(count) { Animatable(0f) } }

    LaunchedEffect(warnings) {
        containerAlpha.snapTo(0f)
        lineHeightFraction.snapTo(0f)
        itemAlphas.forEach { it.snapTo(0f) }

        containerAlpha.animateTo(1f, tween(300, easing = TvMotion.EaseOut))
        lineHeightFraction.animateTo(
            1f,
            tween(400, easing = TvMotion.EaseOut),
        )

        itemAlphas.forEach { alpha ->
            delay(80L)
            alpha.animateTo(1f, tween(200, easing = TvMotion.EaseOut))
        }

        delay(5_000L)

        itemAlphas.asReversed().forEach { alpha ->
            delay(60L)
            alpha.animateTo(0f, tween(150, easing = TvMotion.EaseInOut))
        }

        delay(100L)
        lineHeightFraction.animateTo(
            0f,
            tween(300, easing = TvMotion.EaseInOut),
        )
        delay(200L)
        containerAlpha.animateTo(0f, tween(200, easing = TvMotion.EaseInOut))
        onAnimationComplete()
    }

    if (containerAlpha.value <= 0f) return

    Row(
        modifier = Modifier.alpha(containerAlpha.value),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .height((totalLineHeight * lineHeightFraction.value).dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0xFFB9FF3A)),
        )
        Column(
            modifier = Modifier.padding(start = 9.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            warnings.forEachIndexed { index, warning ->
                Row(
                    modifier = Modifier.alpha(itemAlphas.getOrNull(index)?.value ?: 0f),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = warning.label,
                        color = Color.White.copy(alpha = .92f),
                        fontSize = 12.sp,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = " • ${warning.severity}",
                        color = Color.White.copy(alpha = .56f),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun VueoPlayerCinematicScrim(strong: Boolean) {
    val strength by animateFloatAsState(
        targetValue = if (strong) 1f else 0f,
        animationSpec = tween(TV_WORKSPACE_ENTER_MS, easing = TvMotion.EaseOut),
        label = "workspaceScrimStrength",
    )
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(150.dp)
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .66f + .12f * strength), Color.Transparent))))
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(200.dp)
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .80f + .12f * strength)))))
    }
}

@Composable
private fun VueoPlayerControls(
    visible: Boolean,
    hiddenSeekProgressVisible: Boolean,
    onBottomControlsHeightChanged: (Int) -> Unit,
    media: MediaItem,
    episode: EpisodeItem?,
    activeSource: StreamSource,
    contentWarningVisible: Boolean,
    reserveTranslationSpace: Boolean,
    playbackRequested: Boolean,
    positionMs: Long,
    durationMs: Long,
    seekMotionDirect: Boolean,
    seekHoldActive: Boolean,
    nextEpisode: EpisodeItem?,
    hasSubtitles: Boolean,
    hasAudio: Boolean,
    hasSources: Boolean,
    hasEpisodes: Boolean,
    restartRequester: FocusRequester,
    progressRequester: FocusRequester,
    progressUpRequester: FocusRequester,
    nextRequester: FocusRequester,
    subtitlesRequester: FocusRequester,
    audioRequester: FocusRequester,
    sourcesRequester: FocusRequester,
    episodesRequester: FocusRequester,
    moreRequester: FocusRequester,
    onInteraction: () -> Unit,
    onPlayPause: () -> Unit,
    onRestart: () -> Unit,
    onSeekImmediateBy: (Long) -> Unit,
    onSeekBy: (Long) -> Unit,
    onSeekCommit: () -> Unit,
    onNext: () -> Unit,
    onOpenPanel: (TvPlayerPanel) -> Unit,
) {
    val timeTextStyle = LocalTextStyle.current.copy(fontSize = 12.sp, fontWeight = FontWeight.Medium)
    val timeMeasurer = rememberTextMeasurer()
    val timeDensity = LocalDensity.current
    // Reserve both time labels once per duration/style, not on each playback
    // tick. Crossing a minute/hour boundary must not resize the seek rail.
    val timeTemplate = remember(durationMs) {
        if (durationMs <= 0L) "88:88:88"
        else vueoPlayerTime(durationMs).map { if (it.isDigit()) '8' else it }.joinToString("")
    }
    val timeLabelWidth = remember(timeTemplate, timeTextStyle, timeMeasurer, timeDensity) {
        val widthPx = ('0'..'9').maxOf { digit ->
            timeMeasurer.measure("-${timeTemplate.replace('8', digit)}", style = timeTextStyle).size.width
        }.coerceAtLeast(timeMeasurer.measure("--:--", style = timeTextStyle).size.width)
        with(timeDensity) { widthPx.toDp() } + 2.dp
    }

    val episodeLine = episode?.let {
        "S${it.season} E${it.episode} • ${it.title.ifBlank { "Episode ${it.episode}" }}"
    }

    val bottomActions = buildList {
        if (hasSubtitles) add(VueoPlayerChromeAction(Icons.Rounded.Subtitles, "Subs", subtitlesRequester, TvPlayerPanel.SUBTITLES))
        if (hasAudio) add(VueoPlayerChromeAction(Icons.Rounded.VolumeUp, "Audio", audioRequester, TvPlayerPanel.AUDIO))
        if (hasSources) add(VueoPlayerChromeAction(Icons.Rounded.SwapHoriz, "Sources", sourcesRequester, TvPlayerPanel.SOURCES))
        if (hasEpisodes) add(VueoPlayerChromeAction(Icons.Rounded.List, "Episodes", episodesRequester, TvPlayerPanel.EPISODES))
    }
    val bottomDefaultRequester = bottomActions.firstOrNull()?.requester ?: FocusRequester.Cancel

    // Keep chrome travel short and independent of measured panel height.
    // A longer deceleration and gentler exit avoid the previous abrupt hide.
    val chromeTravelPx = with(LocalDensity.current) { 28.dp.roundToPx() }
    val chromeEnterEasing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
    val chromeExitEasing = CubicBezierEasing(0.4f, 0f, 1f, 1f)

    CompositionLocalProvider(LocalPlayerChromeInteractive provides visible) {
        Box(Modifier.fillMaxSize()) {
            AnimatedVisibility(
                visible = visible,
                modifier = Modifier.align(Alignment.TopCenter),
                enter = tvTunedEnter(TvMotionGroup.CONTROLS, slideInVertically(
                    animationSpec = tween(240, easing = chromeEnterEasing),
                    initialOffsetY = { -chromeTravelPx },
                ) + fadeIn(tween(240, easing = chromeEnterEasing)), direction = -1),
                exit = tvTunedExit(TvMotionGroup.CONTROLS, slideOutVertically(
                    animationSpec = tween(180, easing = chromeExitEasing),
                    targetOffsetY = { -chromeTravelPx },
                ) + fadeOut(tween(180, easing = chromeExitEasing)), direction = -1),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 30.dp, end = 30.dp, top = 28.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (contentWarningVisible) {
                        Spacer(Modifier.weight(1f))
                    } else {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = if (reserveTranslationSpace) 164.dp else 24.dp),
                            verticalArrangement = Arrangement.spacedBy(1.dp),
                        ) {
                            Text(
                                text = media.name,
                                color = Color.White,
                                fontSize = 20.sp,
                                lineHeight = 23.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            episodeLine?.let { line ->
                                Text(
                                    text = line,
                                    color = Color.White.copy(alpha = .72f),
                                    fontSize = 14.sp,
                                    lineHeight = 17.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        VueoPlayerTopAction(
                            icon = Icons.Rounded.Replay,
                            label = "Restart",
                            requester = restartRequester,
                            downRequester = progressRequester,
                            leftRequester = FocusRequester.Cancel,
                            rightRequester = if (nextEpisode != null) nextRequester else moreRequester,
                            onInteraction = onInteraction,
                            onClick = onRestart,
                        )
                        if (nextEpisode != null) {
                            VueoPlayerTopAction(
                                icon = Icons.Rounded.SkipNext,
                                label = "Next episode",
                                requester = nextRequester,
                                downRequester = progressRequester,
                                leftRequester = restartRequester,
                                rightRequester = moreRequester,
                                onInteraction = onInteraction,
                                onClick = onNext,
                            )
                        }
                        VueoPlayerTopAction(
                            icon = Icons.Rounded.MoreHoriz,
                            label = "More",
                            requester = moreRequester,
                            downRequester = progressRequester,
                            leftRequester = if (nextEpisode != null) nextRequester else restartRequester,
                            rightRequester = FocusRequester.Cancel,
                            onInteraction = onInteraction,
                            onClick = { onOpenPanel(TvPlayerPanel.MORE) },
                        )
                    }
                }
            }

            AnimatedVisibility(
                // Hidden long-seek reuses this exact bottom layout so the rail
                // never jumps when full chrome is revealed. Non-rail content
                // keeps its layout space but is visually suppressed.
                visible = visible || hiddenSeekProgressVisible,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = tvTunedEnter(TvMotionGroup.CONTROLS, slideInVertically(
                    animationSpec = tween(240, easing = chromeEnterEasing),
                    initialOffsetY = { chromeTravelPx },
                ) + fadeIn(tween(240, easing = chromeEnterEasing)), direction = 1),
                exit = tvTunedExit(TvMotionGroup.CONTROLS, slideOutVertically(
                    animationSpec = tween(180, easing = chromeExitEasing),
                    targetOffsetY = { chromeTravelPx },
                ) + fadeOut(tween(180, easing = chromeExitEasing)), direction = 1),
            ) {
                Column(
                    Modifier.fillMaxWidth()
                        .onSizeChanged { onBottomControlsHeightChanged(it.height) }
                        .padding(start = 30.dp, end = 30.dp, bottom = 22.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (playbackRequested) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (playbackRequested) "Playing" else "Paused",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp).alpha(if (visible) 1f else 0f),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = vueoPlayerTime(positionMs),
                            modifier = Modifier.width(timeLabelWidth).alpha(if (visible) 1f else 0f),
                            color = Color.White.copy(alpha = .90f),
                            style = timeTextStyle,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.End,
                        )
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f)) {
                            VueoPlayerProgressRail(
                                positionMs = positionMs,
                                durationMs = durationMs,
                                seekMotionDirect = seekMotionDirect,
                                seekHoldActive = seekHoldActive,
                                requester = progressRequester,
                                upRequester = progressUpRequester,
                                downRequester = bottomDefaultRequester,
                                onInteraction = onInteraction,
                                onSeekImmediateBy = onSeekImmediateBy,
                                onSeekBy = onSeekBy,
                                onSeekCommit = onSeekCommit,
                                onTogglePlayback = onPlayPause,
                                emphasized = hiddenSeekProgressVisible && !visible,
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = vueoPlayerRemainingTime(positionMs, durationMs),
                            modifier = Modifier.width(timeLabelWidth).alpha(if (visible) 1f else 0f),
                            color = Color.White.copy(alpha = .90f),
                            style = timeTextStyle,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.Start,
                        )
                    }

                    if (bottomActions.isNotEmpty()) {
                        Spacer(Modifier.height(1.dp))
                        Row(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .alpha(if (visible) 1f else 0f)
                                .clip(RoundedCornerShape(22.dp))
                                .background(Color(0xFF111316).copy(alpha = .88f))
                                .border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(22.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(1.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            bottomActions.forEachIndexed { index, action ->
                                VueoPlayerPillAction(
                                    icon = action.icon,
                                    label = action.label,
                                    requester = action.requester,
                                    upRequester = progressRequester,
                                    leftRequester = bottomActions.getOrNull(index - 1)?.requester ?: FocusRequester.Cancel,
                                    rightRequester = bottomActions.getOrNull(index + 1)?.requester ?: FocusRequester.Cancel,
                                    onInteraction = onInteraction,
                                    onClick = { onOpenPanel(action.panel) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class VueoPlayerChromeAction(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val requester: FocusRequester,
    val panel: TvPlayerPanel,
)

// Keep workspace fades and shallow panel travel in sync, including on close.
internal const val TV_WORKSPACE_ENTER_MS = 240
internal const val TV_WORKSPACE_EXIT_MS = 200

private fun originalPlayerWorkspaceFadeIn(): EnterTransition = fadeIn(
    tween(TV_WORKSPACE_ENTER_MS, easing = TvMotion.EaseOut),
)

private fun originalPlayerWorkspaceFadeOut(): ExitTransition = fadeOut(
    tween(TV_WORKSPACE_EXIT_MS, easing = TvMotion.EaseInOut),
)

private fun originalPlayerSidePanelEnter(): EnterTransition = slideInHorizontally(
    initialOffsetX = { it / 16 },
    animationSpec = tween(TV_WORKSPACE_ENTER_MS, easing = TvMotion.EaseOut),
)

private fun originalPlayerSidePanelExit(): ExitTransition = slideOutHorizontally(
    targetOffsetX = { it / 16 },
    animationSpec = tween(TV_WORKSPACE_EXIT_MS, easing = TvMotion.EaseInOut),
)


internal fun tvPlayerWorkspaceFadeIn(): EnterTransition = tvTunedEnter(TvMotionGroup.WORKSPACE, originalPlayerWorkspaceFadeIn())
internal fun tvPlayerWorkspaceFadeOut(): ExitTransition = tvTunedExit(TvMotionGroup.WORKSPACE, originalPlayerWorkspaceFadeOut())
internal fun tvPlayerSidePanelEnter(): EnterTransition =
    if (TvMotionTuning.reduceMotion || TvMotionTuning.active(TvMotionGroup.WORKSPACE)) EnterTransition.None else originalPlayerSidePanelEnter()
internal fun tvPlayerSidePanelExit(): ExitTransition =
    if (TvMotionTuning.reduceMotion || TvMotionTuning.active(TvMotionGroup.WORKSPACE)) ExitTransition.None else originalPlayerSidePanelExit()
