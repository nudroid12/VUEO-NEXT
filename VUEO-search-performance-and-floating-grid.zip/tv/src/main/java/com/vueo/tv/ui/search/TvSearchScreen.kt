package com.vueo.tv.search
import com.vueo.shared.core.search.SearchResultOrderPolicy
import com.vueo.shared.core.search.SearchMediaFilter
import com.vueo.shared.core.search.SearchOrchestrator
import com.vueo.shared.core.search.DiscoverCatalogPolicy
import com.vueo.shared.core.search.DiscoverSortMode

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vueo.shared.core.media.CatalogRow
import com.vueo.shared.core.media.MediaItem
import com.vueo.tv.core.TvRuntime
import com.vueo.tv.ui.TvDesign
import com.vueo.tv.ui.TvNetworkImage
import com.vueo.tv.ui.TvPosterActionDialog
import com.vueo.tv.ui.tvPosterActivation
import com.vueo.tv.ui.motion.TvMotion
import com.vueo.tv.ui.TvPrimaryDestinations
import com.vueo.tv.ui.TvSidebar
import com.vueo.tv.ui.tvSidebarContentStartPadding
import com.vueo.tv.ui.tvSidebarIsPillMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

private const val SEARCH_COLUMNS = 6

internal enum class TvSearchTypeFilter(val label: String) {
    ALL("All"),
    MOVIES("Movies"),
    SERIES("Series"),
    ANIME("Anime"),
}

internal enum class TvSearchSortMode(val label: String) {
    POPULAR("Popular"),
    TRENDING("Trending"),
    NEWEST("Newest"),
}

internal enum class TvSearchMode(val label: String) {
    TITLE("Title"),
    ACTOR("Actor"),
}

/**
 * Search state is owned by VueoTvApp so returning from Detail restores the
 * Mobile-style search surface instead of starting a fresh session.
 */
internal class TvSearchSession {
    var query by mutableStateOf("")
    var typeFilter by mutableStateOf(TvSearchTypeFilter.ALL)
    var sortMode by mutableStateOf(TvSearchSortMode.POPULAR)
    var genre by mutableStateOf<String?>(null)
    var mode by mutableStateOf(TvSearchMode.TITLE)

    var searchResults by mutableStateOf<List<MediaItem>>(emptyList())
    var discoverRows by mutableStateOf<List<CatalogRow>>(emptyList())
    var actorSourceAvailable by mutableStateOf(true)
    var completedSearchKey by mutableStateOf<String?>(null)
    var discoverContentVersion by mutableStateOf<Int?>(null)

    var focusedMediaKey by mutableStateOf<String?>(null)
    var restoreResultsFocus by mutableStateOf(false)
    var firstVisibleItemIndex by mutableStateOf(0)
    var firstVisibleItemScrollOffset by mutableStateOf(0)
}

@Composable
internal fun TvSearchScreen(
    runtime: TvRuntime,
    contentVersion: Int,
    session: TvSearchSession,
    onNavigate: (String) -> Unit,
    onProfile: () -> Unit,
    onOpenMedia: (MediaItem) -> Unit,
    onBack: () -> Unit,
) {
    var searching by remember { mutableStateOf(false) }
    var discovering by remember { mutableStateOf(session.discoverRows.isEmpty()) }
    var requestId by remember { mutableStateOf(0L) }
    var navExpanded by remember { mutableStateOf(false) }
    var lastContentTarget by remember { mutableStateOf("field") }
    var choiceDialog by remember { mutableStateOf<SearchChoice?>(null) }
    var actionMedia by remember { mutableStateOf<MediaItem?>(null) }
    var dialogReturnFocus by remember { mutableStateOf<(() -> Unit)?>(null) }

    val fieldRequester = remember { FocusRequester() }
    val modeRequester = remember { FocusRequester() }
    val typeRequester = remember { FocusRequester() }
    val sortRequester = remember { FocusRequester() }
    val genreRequester = remember { FocusRequester() }
    val navRequesters = remember { TvPrimaryDestinations.associateWith { FocusRequester() } }
    val profileRequester = remember { FocusRequester() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        delay(120)
        if (!session.restoreResultsFocus) {
            runCatching { fieldRequester.requestFocus() }
        }
    }

    LaunchedEffect(contentVersion) {
        val versionChanged = session.discoverContentVersion != contentVersion
        val cached = runtime.cachedHomeRows()
        if (cached.isNotEmpty()) {
            session.discoverRows = cached
            session.discoverContentVersion = contentVersion
            discovering = false
            return@LaunchedEffect
        }
        if (!versionChanged && session.discoverRows.isNotEmpty()) {
            discovering = false
            return@LaunchedEffect
        }
        if (versionChanged) session.discoverRows = emptyList()
        discovering = true
        session.discoverRows = runCatching { runtime.homeRows(forceRefresh = false) }.getOrElse { runtime.cachedHomeRows() }
        session.discoverContentVersion = contentVersion
        discovering = false
    }

    LaunchedEffect(session.query, contentVersion, session.mode) {
        val normalized = session.query.trim()
        requestId += 1L
        val thisRequest = requestId
        val requestedMode = session.mode
        val searchKey = "$contentVersion|${requestedMode.name}|$normalized"

        if (session.completedSearchKey == searchKey) {
            searching = false
            return@LaunchedEffect
        }

        if (normalized.length < 2) {
            searching = false
            session.actorSourceAvailable = true
            session.searchResults = emptyList()
            session.completedSearchKey = searchKey
            return@LaunchedEffect
        }

        searching = true
        delay(250)
        if (
            thisRequest != requestId ||
            session.query.trim() != normalized ||
            session.mode != requestedMode
        ) return@LaunchedEffect

        if (requestedMode == TvSearchMode.TITLE) {
            session.actorSourceAvailable = true
            val local = SearchOrchestrator.localTitleResults(normalized)
            if (local.isNotEmpty() || session.searchResults.isEmpty()) {
                session.searchResults = local
            }

            val remote = SearchOrchestrator.remoteTitleResults(
                engine = runtime.engine,
                query = normalized,
                localResults = local,
                onPartial = { partial ->
                    if (thisRequest == requestId && session.query.trim() == normalized && session.mode == requestedMode) {
                        session.searchResults = partial
                    }
                },
            )

            if (thisRequest == requestId && session.query.trim() == normalized && session.mode == requestedMode) {
                session.searchResults = remote
                session.completedSearchKey = searchKey
                searching = false
            }
            return@LaunchedEffect
        }

        val tmdbApiKey = runtime.pluginStore.tmdbApiKey()
        val actorAvailability = SearchOrchestrator.actorAvailability(
            engine = runtime.engine,
            tmdbApiKey = tmdbApiKey,
        )
        session.actorSourceAvailable = actorAvailability.available
        session.searchResults = emptyList()

        if (!session.actorSourceAvailable) {
            searching = false
            return@LaunchedEffect
        }

        val actorResults = SearchOrchestrator.actorResults(
            engine = runtime.engine,
            query = normalized,
            tmdbApiKey = tmdbApiKey,
            onPartial = { partial ->
                if (thisRequest == requestId && session.query.trim() == normalized && session.mode == requestedMode) {
                    session.searchResults = partial
                }
            },
        )

        if (thisRequest == requestId && session.query.trim() == normalized && session.mode == requestedMode) {
            session.searchResults = actorResults
            session.completedSearchKey = searchKey
            searching = false
        }
    }

    val normalizedQuery = session.query.trim()
    val searchingMode = normalizedQuery.isNotBlank()

    val animeCatalogKeys = remember(session.discoverRows) {
        session.discoverRows
            .filter { row ->
                listOf(row.id, row.title, row.providerName)
                    .any { it.contains("anime", ignoreCase = true) }
            }
            .flatMap { it.items }
            .map(::mediaKey)
            .toSet()
    }

    val discoverBaseItems = remember(session.discoverRows, session.sortMode) {
        DiscoverCatalogPolicy.baseItems(
            rows = session.discoverRows,
            mode = session.sortMode.toDiscoverSortMode(),
        )
    }

    val sourceItems = if (searchingMode) {
        session.searchResults
    } else {
        discoverBaseItems
    }

    val availableGenres = remember(sourceItems, session.typeFilter, animeCatalogKeys) {
        sourceItems
            .filter {
                SearchResultOrderPolicy.matchesType(
                    item = it,
                    filter = session.typeFilter.toSearchMediaFilter(),
                    animeCatalogKeys = animeCatalogKeys,
                )
            }
            .flatMap { it.genres }
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.equals("anime", ignoreCase = true) }
            .distinctBy { it.lowercase() }
            .sortedBy { it.lowercase() }
    }

    LaunchedEffect(availableGenres, session.genre) {
        if (
            session.genre != null &&
            availableGenres.none { it.equals(session.genre, ignoreCase = true) }
        ) {
            session.genre = null
        }
    }

    val filteredItems = remember(
        sourceItems,
        session.typeFilter,
        session.genre,
        session.sortMode,
        searchingMode,
        session.mode,
        animeCatalogKeys,
    ) {
        val filtered = sourceItems.filter { item ->
            SearchResultOrderPolicy.matchesType(
                item = item,
                filter = session.typeFilter.toSearchMediaFilter(),
                animeCatalogKeys = animeCatalogKeys,
            ) && SearchResultOrderPolicy.matchesGenre(item, session.genre)
        }

        when {
            searchingMode && session.mode == TvSearchMode.ACTOR ->
                searchSortActorItems(filtered, session.sortMode)

            searchingMode ->
                searchSortItems(filtered, session.sortMode, normalizedQuery)

            else ->
                DiscoverCatalogPolicy.orderFiltered(
                    items = filtered,
                    mode = session.sortMode.toDiscoverSortMode(),
                )
        }
    }

    val gridState = rememberLazyGridState(
        initialFirstVisibleItemIndex = session.firstVisibleItemIndex,
        initialFirstVisibleItemScrollOffset = session.firstVisibleItemScrollOffset,
    )
    val resultKeys = remember(filteredItems) { filteredItems.map(::mediaKey) }
    val resultRequesterCache = remember(resultKeys, session.mode) { mutableMapOf<String, FocusRequester>() }
    val resultRequesters = resultKeys.associateWith { key -> resultRequesterCache.getOrPut(key) { FocusRequester() } }

    fun resetGridForFilterChange() {
        session.focusedMediaKey = null
        session.restoreResultsFocus = false
        session.firstVisibleItemIndex = 0
        session.firstVisibleItemScrollOffset = 0
        scope.launch {
            try {
                gridState.scrollToItem(0)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                // Keep the current focus if the grid is being disposed.
            }
        }
    }

    LaunchedEffect(gridState) {
        snapshotFlow {
            gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset
        }
            .distinctUntilChanged()
            .collect { (index, offset) ->
                session.firstVisibleItemIndex = index
                session.firstVisibleItemScrollOffset = offset
            }
    }

    LaunchedEffect(session.restoreResultsFocus, filteredItems) {
        if (!session.restoreResultsFocus) return@LaunchedEffect
        val key = session.focusedMediaKey ?: return@LaunchedEffect
        val index = filteredItems.indexOfFirst { mediaKey(it) == key }
        if (index < 0) return@LaunchedEffect

        runCatching { gridState.scrollToItem(index) }
        delay(90)
        val restored = runCatching {
            resultRequesters.getValue(key).requestFocus()
            true
        }.getOrDefault(false)
        if (restored) session.restoreResultsFocus = false
    }

    fun focusFirstResult(): Boolean {
        val firstKey = resultKeys.firstOrNull() ?: return false
        return runCatching {
            resultRequesters.getValue(firstKey).requestFocus()
            true
        }.getOrDefault(false)
    }

    fun dismissChoiceDialog() {
        val restoreFocus = dialogReturnFocus
        choiceDialog = null
        dialogReturnFocus = null
        scope.launch { delay(40); restoreFocus?.invoke() }
    }

    BackHandler(enabled = choiceDialog != null) { dismissChoiceDialog() }
    BackHandler(enabled = choiceDialog == null) {
        if (navExpanded) {
            onBack()
        } else {
            navExpanded = true
            runCatching { navRequesters.getValue("Search").requestFocus() }
        }
    }

    val contentStartPadding = tvSidebarContentStartPadding(96.dp)
    val floatingPillMode = tvSidebarIsPillMode()
    val searchColumns = if (floatingPillMode) 8 else SEARCH_COLUMNS
    val gridEndPadding = if (floatingPillMode) 28.dp else 52.dp

    Box(Modifier.fillMaxSize().background(TvDesign.Black)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 46.dp),
        ) {
            Column(
                modifier = Modifier.padding(start = contentStartPadding, end = 52.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = "Search",
                    color = TvDesign.White,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                )

                Box(modifier = Modifier.fillMaxWidth(.76f)) {
                    TvMobileSearchField(
                        value = session.query,
                        mode = session.mode,
                        requester = fieldRequester,
                        modeRequester = modeRequester,
                        onFocused = {
                            navExpanded = false
                            lastContentTarget = "field"
                        },
                        onModeFocused = {
                            navExpanded = false
                            lastContentTarget = "mode"
                        },
                        onModeChange = { next ->
                            if (next != session.mode) {
                                session.mode = next
                                session.searchResults = emptyList()
                                session.completedSearchKey = null
                                session.genre = null
                                resetGridForFilterChange()
                            }
                        },
                        onValueChange = { nextQuery ->
                            if (nextQuery != session.query) {
                                session.query = nextQuery
                                session.completedSearchKey = null
                                resetGridForFilterChange()
                            }
                        },
                        onLeftWhenEmpty = {
                            navExpanded = true
                            runCatching { navRequesters.getValue("Search").requestFocus() }
                        },
                        onRight = { runCatching { modeRequester.requestFocus() } },
                        onUp = {},
                        onDown = { runCatching { typeRequester.requestFocus() } },
                    )
                }

                if (searching || discovering) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth(.76f)
                            .height(1.dp),
                        color = TvDesign.White.copy(alpha = .90f),
                        trackColor = TvDesign.White.copy(alpha = .08f),
                    )
                } else {
                    Spacer(Modifier.height(1.dp))
                }

                Text(
                    text = if (searchingMode) "Search Results" else "Discover",
                    color = TvDesign.White.copy(alpha = .94f),
                    fontSize = 23.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 3.dp),
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TvSearchFilterButton(
                        label = session.typeFilter.label,
                        requester = typeRequester,
                        onFocused = {
                            navExpanded = false
                            lastContentTarget = "type"
                        },
                        onClick = {
                            dialogReturnFocus = { runCatching { typeRequester.requestFocus() } }
                            choiceDialog = SearchChoice(
                                title = "Type",
                                options = TvSearchTypeFilter.entries.map { it.label },
                                selected = session.typeFilter.label,
                                onSelected = { label ->
                                    TvSearchTypeFilter.entries
                                        .firstOrNull { it.label == label }
                                        ?.let { next ->
                                            if (next != session.typeFilter) {
                                                session.typeFilter = next
                                                session.genre = null
                                                resetGridForFilterChange()
                                            }
                                        }
                                    dismissChoiceDialog()
                                },
                            )
                        },
                        onLeft = {
                            navExpanded = true
                            runCatching { navRequesters.getValue("Search").requestFocus() }
                        },
                        onRight = { runCatching { sortRequester.requestFocus() } },
                        onUp = { runCatching { fieldRequester.requestFocus() } },
                        onDown = ::focusFirstResult,
                    )
                    TvSearchFilterButton(
                        label = session.sortMode.label,
                        requester = sortRequester,
                        onFocused = {
                            navExpanded = false
                            lastContentTarget = "sort"
                        },
                        onClick = {
                            dialogReturnFocus = { runCatching { sortRequester.requestFocus() } }
                            choiceDialog = SearchChoice(
                                title = "Discover",
                                options = TvSearchSortMode.entries.map { it.label },
                                selected = session.sortMode.label,
                                onSelected = { label ->
                                    TvSearchSortMode.entries
                                        .firstOrNull { it.label == label }
                                        ?.let { next ->
                                            if (next != session.sortMode) {
                                                session.sortMode = next
                                                resetGridForFilterChange()
                                            }
                                        }
                                    dismissChoiceDialog()
                                },
                            )
                        },
                        onLeft = { runCatching { typeRequester.requestFocus() } },
                        onRight = { runCatching { genreRequester.requestFocus() } },
                        onUp = { runCatching { fieldRequester.requestFocus() } },
                        onDown = ::focusFirstResult,
                    )
                    TvSearchFilterButton(
                        label = session.genre ?: "All Genres",
                        requester = genreRequester,
                        onFocused = {
                            navExpanded = false
                            lastContentTarget = "genre"
                        },
                        onClick = {
                            dialogReturnFocus = { runCatching { genreRequester.requestFocus() } }
                            choiceDialog = SearchChoice(
                                title = "Genre",
                                options = listOf("All Genres") + availableGenres,
                                selected = session.genre ?: "All Genres",
                                onSelected = { label ->
                                    val next = label.takeUnless { it == "All Genres" }
                                    if (next != session.genre) {
                                        session.genre = next
                                        resetGridForFilterChange()
                                    }
                                    dismissChoiceDialog()
                                },
                            )
                        },
                        onLeft = { runCatching { sortRequester.requestFocus() } },
                        onRight = { true },
                        onUp = { runCatching { fieldRequester.requestFocus() } },
                        onDown = ::focusFirstResult,
                    )

                    Spacer(Modifier.weight(1f))

                    if (searchingMode && normalizedQuery.length < 2) {
                        Text("Type at least 2 characters", color = TvDesign.Muted, fontSize = 10.sp)
                    } else if (searchingMode && !searching) {
                        Text(
                            text = when {
                                session.mode == TvSearchMode.ACTOR && !session.actorSourceAvailable ->
                                    "Actor search unavailable"
                                filteredItems.isEmpty() -> "No results"
                                else -> "${filteredItems.size} results"
                            },
                            color = TvDesign.Muted,
                            fontSize = 10.sp,
                        )
                    }
                }
            }

            Spacer(Modifier.height(if (searchingMode) 6.dp else 14.dp))

            when {
                !searchingMode && session.discoverRows.isEmpty() && !discovering -> {
                    SearchEmptyState(
                        title = "Nothing to discover yet",
                        body = "Enable a catalog in Content Manager to populate Discover.",
                    )
                }

                !searchingMode && filteredItems.isEmpty() && !discovering -> {
                    SearchEmptyState(
                        title = "No ${session.typeFilter.label} titles",
                        body = if (session.typeFilter == TvSearchTypeFilter.ANIME) {
                            "No enabled catalog currently exposes Anime browsing."
                        } else {
                            "Try another type, sort or genre filter."
                        },
                    )
                }

                searchingMode && normalizedQuery.length >= 2 && filteredItems.isEmpty() && !searching -> {
                    SearchEmptyState(
                        title = if (
                            session.mode == TvSearchMode.ACTOR && !session.actorSourceAvailable
                        ) "Actor search unavailable" else "No matches",
                        body = when {
                            session.mode == TvSearchMode.ACTOR && !session.actorSourceAvailable ->
                                "Enable an actor-capable metadata source or add a TMDB API key."
                            session.mode == TvSearchMode.ACTOR ->
                                "Try another actor name or change the filters."
                            else -> "Try another title or change the filters."
                        },
                    )
                }

                filteredItems.isNotEmpty() -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(searchColumns),
                        state = gridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = contentStartPadding,
                            end = gridEndPadding,
                            top = 2.dp,
                            bottom = 36.dp,
                        ),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        gridItemsIndexed(
                            items = filteredItems,
                            key = { _, item -> mediaKey(item) },
                        ) { index, item ->
                            val key = mediaKey(item)
                            TvSearchPosterTile(
                                item = item,
                                catalogLabel = searchCatalogLabel(runtime, item),
                                requester = resultRequesters.getValue(key),
                                onFocused = {
                                    navExpanded = false
                                    lastContentTarget = "result:$key"
                                    session.focusedMediaKey = key
                                },
                                onClick = {
                                    session.focusedMediaKey = key
                                    session.restoreResultsFocus = true
                                    session.firstVisibleItemIndex = gridState.firstVisibleItemIndex
                                    session.firstVisibleItemScrollOffset = gridState.firstVisibleItemScrollOffset
                                    onOpenMedia(item)
                                },
                                onLongClick = { actionMedia = item },
                                onUpFromFirstRow = if (index < searchColumns) {
                                    { runCatching { typeRequester.requestFocus() } }
                                } else null,
                                onLeftFromFirstColumn = if (index % searchColumns == 0) {
                                    {
                                        navExpanded = true
                                        runCatching { navRequesters.getValue("Search").requestFocus() }
                                    }
                                } else null,
                                blockRight =
                                    index % searchColumns == searchColumns - 1 || index == filteredItems.lastIndex,
                            )
                        }
                    }
                }

                searching -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            color = TvDesign.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(28.dp),
                        )
                    }
                }
            }
        }

        TvSidebar(
            selected = "Search",
            expanded = navExpanded,
            navRequesters = navRequesters,
            profileRequester = profileRequester,
            onFocused = { navExpanded = true },
            onNavigate = onNavigate,
            onProfile = onProfile,
            onReturnToContent = {
                navExpanded = false
                runCatching {
                    when {
                        lastContentTarget == "type" -> typeRequester.requestFocus()
                        lastContentTarget == "sort" -> sortRequester.requestFocus()
                        lastContentTarget == "genre" -> genreRequester.requestFocus()
                        lastContentTarget == "mode" -> modeRequester.requestFocus()
                        lastContentTarget.startsWith("result:") -> {
                            val key = lastContentTarget.removePrefix("result:")
                            resultRequesters[key]?.requestFocus() ?: fieldRequester.requestFocus()
                        }
                        else -> fieldRequester.requestFocus()
                    }
                }.isSuccess
            },
            modifier = Modifier.align(Alignment.CenterStart),
        )

        choiceDialog?.let { dialog ->
            TvSearchChoiceDialog(dialog = dialog)
        }
    }

    actionMedia?.let { media ->
        TvPosterActionDialog(
            media = media,
            libraryStore = runtime.libraryStore,
            onOpenDetails = { onOpenMedia(media) },
            onChanged = {},
            onDismiss = { actionMedia = null },
        )
    }
}

@Composable
private fun TvMobileSearchField(
    value: String,
    mode: TvSearchMode,
    requester: FocusRequester,
    modeRequester: FocusRequester,
    onFocused: () -> Unit,
    onModeFocused: () -> Unit,
    onModeChange: (TvSearchMode) -> Unit,
    onValueChange: (String) -> Unit,
    onLeftWhenEmpty: () -> Unit,
    onRight: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(15.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(shape)
            .background(TvDesign.SurfaceRaised)
            .border(
                width = if (focused) 1.5.dp else 1.dp,
                color = if (focused) TvDesign.White.copy(alpha = .86f)
                else TvDesign.White.copy(alpha = .13f),
                shape = shape,
            )
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = TvDesign.Muted,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(11.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                textStyle = TextStyle(
                    color = TvDesign.White,
                    fontSize = 15.sp,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(requester)
                    .onFocusChanged {
                        focused = it.isFocused
                        if (it.isFocused) onFocused()
                    }
                    .onPreviewKeyEvent { event ->
                        if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                        when (event.nativeKeyEvent.keyCode) {
                            KeyEvent.KEYCODE_DPAD_LEFT -> {
                                if (value.isBlank()) {
                                    onLeftWhenEmpty()
                                    true
                                } else false
                            }
                            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                                onRight()
                                true
                            }
                            KeyEvent.KEYCODE_DPAD_UP -> {
                                onUp()
                                true
                            }
                            KeyEvent.KEYCODE_DPAD_DOWN -> {
                                onDown()
                                true
                            }
                            else -> false
                        }
                    },
                decorationBox = { inner ->
                    if (value.isBlank()) {
                        Text(
                            text = if (mode == TvSearchMode.ACTOR) {
                                "Search actor name..."
                            } else {
                                "Search movies, shows..."
                            },
                            color = TvDesign.Muted,
                            fontSize = 15.sp,
                        )
                    }
                    inner()
                },
            )
        }

        Box(
            modifier = Modifier
                .padding(horizontal = 10.dp)
                .width(1.dp)
                .height(24.dp)
                .background(TvDesign.White.copy(alpha = .14f)),
        )

        TvSearchModeToggle(
            mode = mode,
            requester = modeRequester,
            onFocused = onModeFocused,
            onModeChange = onModeChange,
            onLeft = { runCatching { requester.requestFocus() } },
            onUp = { runCatching { requester.requestFocus() } },
            onDown = onDown,
        )
    }
}

@Composable
private fun TvSearchModeToggle(
    mode: TvSearchMode,
    requester: FocusRequester,
    onFocused: () -> Unit,
    onModeChange: (TvSearchMode) -> Unit,
    onLeft: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)

    Row(
        modifier = Modifier
            .focusRequester(requester)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .onPreviewKeyEvent { event ->
                val code = event.nativeKeyEvent.keyCode
                when {
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_LEFT -> {
                        onLeft()
                        true
                    }
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_RIGHT -> true
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_UP -> {
                        onUp()
                        true
                    }
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_DOWN -> {
                        onDown()
                        true
                    }
                    event.isTvActivationKey() -> {
                        if (event.type == KeyEventType.KeyUp) {
                            onModeChange(
                                if (mode == TvSearchMode.TITLE) TvSearchMode.ACTOR else TvSearchMode.TITLE
                            )
                        }
                        true
                    }
                    else -> false
                }
            }
            .clickable {
                onModeChange(
                    if (mode == TvSearchMode.TITLE) TvSearchMode.ACTOR else TvSearchMode.TITLE
                )
            }
            .background(
                if (focused) TvDesign.White.copy(alpha = .10f) else Color.Transparent,
                shape,
            )
            .border(
                width = if (focused) 1.dp else 0.dp,
                color = if (focused) TvDesign.White.copy(alpha = .70f) else Color.Transparent,
                shape = shape,
            )
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Text(
            text = "Title",
            color = if (mode == TvSearchMode.TITLE) TvDesign.White else TvDesign.Muted,
            fontSize = 11.sp,
            fontWeight = if (mode == TvSearchMode.TITLE) FontWeight.Bold else FontWeight.Medium,
        )
        Box(
            modifier = Modifier
                .width(38.dp)
                .height(20.dp)
                .clip(RoundedCornerShape(50.dp))
                .background(TvDesign.White.copy(alpha = .92f))
                .padding(3.dp),
        ) {
            Box(
                modifier = Modifier
                    .align(if (mode == TvSearchMode.ACTOR) Alignment.CenterEnd else Alignment.CenterStart)
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(TvDesign.Black),
            )
        }
        Text(
            text = "Actor",
            color = if (mode == TvSearchMode.ACTOR) TvDesign.White else TvDesign.Muted,
            fontSize = 11.sp,
            fontWeight = if (mode == TvSearchMode.ACTOR) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

@Composable
private fun TvSearchFilterButton(
    label: String,
    requester: FocusRequester,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    onLeft: (() -> Unit)?,
    onRight: (() -> Unit)?,
    onUp: () -> Unit,
    onDown: () -> Boolean,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)

    Row(
        modifier = Modifier
            .focusRequester(requester)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .onPreviewKeyEvent { event ->
                val code = event.nativeKeyEvent.keyCode
                when {
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_LEFT -> {
                        onLeft?.invoke()
                        true
                    }
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        onRight?.invoke()
                        true
                    }
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_UP -> {
                        onUp()
                        true
                    }
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_DOWN -> {
                        onDown()
                        true
                    }
                    event.isTvActivationKey() -> {
                        if (event.type == KeyEventType.KeyUp) onClick()
                        true
                    }
                    else -> false
                }
            }
            .clickable(onClick = onClick)
            .background(
                if (focused) TvDesign.White.copy(alpha = .12f) else TvDesign.SurfaceRaised,
                shape,
            )
            .border(
                width = 1.dp,
                color = if (focused) TvDesign.White.copy(alpha = .82f)
                else TvDesign.White.copy(alpha = .11f),
                shape = shape,
            )
            .padding(horizontal = 13.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            color = TvDesign.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = "⌄",
            color = TvDesign.Muted,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun TvSearchPosterTile(
    item: MediaItem,
    catalogLabel: String?,
    requester: FocusRequester,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onUpFromFirstRow: (() -> Unit)?,
    onLeftFromFirstColumn: (() -> Unit)?,
    blockRight: Boolean,
) {
    var focused by remember(item.id, item.type) { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.035f else 1f,
        animationSpec = tween(
            durationMillis = if (focused) TvMotion.FOCUS_IN_MS else TvMotion.FOCUS_OUT_MS,
            easing = TvMotion.EaseOut,
        ),
        label = "searchPosterScale",
    )

    Column(
        modifier = Modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                shadowElevation = if (focused) 8.dp.toPx() else 0f
                shape = RoundedCornerShape(10.dp)
                clip = false
            }
            .focusRequester(requester)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .onPreviewKeyEvent { event ->
                val code = event.nativeKeyEvent.keyCode
                when {
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_UP && onUpFromFirstRow != null -> {
                        onUpFromFirstRow()
                        true
                    }
                    event.type == KeyEventType.KeyDown &&
                        code == KeyEvent.KEYCODE_DPAD_LEFT &&
                        onLeftFromFirstColumn != null -> {
                        onLeftFromFirstColumn()
                        true
                    }
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_RIGHT && blockRight -> true
                    else -> false
                }
            }
            .tvPosterActivation(
                onClick = onClick,
                onLongClick = onLongClick,
            )
            .clickable(onClick = onClick),
    ) {
        TvNetworkImage(
            url = item.poster,
            contentDescription = item.name,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(10.dp))
                .border(
                    width = if (focused) 1.dp else 0.dp,
                    color = if (focused) TvDesign.White.copy(alpha = .88f) else Color.Transparent,
                    shape = RoundedCornerShape(10.dp),
                ),
            contentScale = ContentScale.Crop,
        )
        Spacer(Modifier.height(5.dp))
        Text(
            text = item.name,
            color = TvDesign.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = if (catalogLabel.isNullOrBlank()) {
                listOfNotNull(item.releaseInfo, searchTypeLabel(item)).joinToString(" • ")
            } else {
                listOf(searchTypeLabel(item), catalogLabel).joinToString(" • ")
            },
            color = TvDesign.Muted,
            fontSize = 9.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private data class SearchChoice(
    val title: String,
    val options: List<String>,
    val selected: String,
    val onSelected: (String) -> Unit,
)

@Composable
private fun TvSearchChoiceDialog(
    dialog: SearchChoice,
) {
    val selectedIndex = dialog.options.indexOf(dialog.selected).coerceAtLeast(0)
    val requesters = remember(dialog.title, dialog.options) {
        List(dialog.options.size) { FocusRequester() }
    }

    LaunchedEffect(dialog.title, dialog.selected) {
        delay(80)
        requesters.getOrNull(selectedIndex)?.let { runCatching { it.requestFocus() } }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = .72f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .width(430.dp)
                .heightIn(max = 520.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(TvDesign.SurfaceRaised)
                .border(
                    1.dp,
                    TvDesign.White.copy(alpha = .12f),
                    RoundedCornerShape(18.dp),
                )
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = dialog.title,
                color = TvDesign.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
            )
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                lazyItems(
                    items = dialog.options,
                    key = { it },
                ) { option ->
                    val index = dialog.options.indexOf(option)
                    TvSearchChoiceRow(
                        label = option,
                        selected = option == dialog.selected,
                        requester = requesters[index],
                        onClick = { dialog.onSelected(option) },
                    )
                }
            }
        }
    }
}

@Composable
private fun TvSearchChoiceRow(
    label: String,
    selected: Boolean,
    requester: FocusRequester,
    onClick: () -> Unit,
) {
    var focused by remember(label) { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { event ->
                if (event.isTvActivationKey()) {
                    if (event.type == KeyEventType.KeyUp) onClick()
                    true
                } else false
            }
            .clickable(onClick = onClick)
            .background(
                when {
                    focused -> TvDesign.White.copy(alpha = .14f)
                    selected -> TvDesign.White.copy(alpha = .07f)
                    else -> Color.Transparent
                },
                shape,
            )
            .border(
                width = if (focused) 1.dp else 0.dp,
                color = if (focused) TvDesign.White.copy(alpha = .78f) else Color.Transparent,
                shape = shape,
            )
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(CircleShape)
                .border(
                    1.dp,
                    if (selected) TvDesign.White else TvDesign.Muted,
                    CircleShape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(TvDesign.White),
                )
            }
        }
        Spacer(Modifier.width(11.dp))
        Text(
            text = label,
            color = TvDesign.White,
            fontSize = 14.sp,
            fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

@Composable
private fun SearchEmptyState(
    title: String,
    body: String,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 52.dp, vertical = 34.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = title,
            color = TvDesign.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
        )
        Text(
            text = body,
            color = TvDesign.Muted,
            fontSize = 12.sp,
        )
    }
}

private fun TvSearchSortMode.toDiscoverSortMode(): DiscoverSortMode =
    when (this) {
        TvSearchSortMode.POPULAR -> DiscoverSortMode.POPULAR
        TvSearchSortMode.TRENDING -> DiscoverSortMode.TRENDING
        TvSearchSortMode.NEWEST -> DiscoverSortMode.NEWEST
    }

private fun TvSearchTypeFilter.toSearchMediaFilter(): SearchMediaFilter =
    when (this) {
        TvSearchTypeFilter.ALL -> SearchMediaFilter.ALL
        TvSearchTypeFilter.MOVIES -> SearchMediaFilter.MOVIES
        TvSearchTypeFilter.SERIES -> SearchMediaFilter.SERIES
        TvSearchTypeFilter.ANIME -> SearchMediaFilter.ANIME
    }

private fun searchSortActorItems(
    items: List<MediaItem>,
    mode: TvSearchSortMode,
): List<MediaItem> =
    SearchResultOrderPolicy.sortActorItems(items, mode.toDiscoverSortMode())

private fun searchSortItems(
    items: List<MediaItem>,
    mode: TvSearchSortMode,
    query: String? = null,
): List<MediaItem> =
    SearchResultOrderPolicy.sortTitleItems(items, mode.toDiscoverSortMode(), query)

private fun searchCatalogLabel(runtime: TvRuntime, item: MediaItem): String? {
    val direct = item.catalogSources.firstOrNull { it.isNotBlank() }
    val resolved = direct
        ?: runtime.engine.extension(item.sourceExtensionId)?.descriptor?.name
        ?: item.sourceExtensionId?.substringAfterLast('.')?.substringAfterLast(':')
    return resolved?.let(::searchPrettyCatalogName)
}

private fun searchPrettyCatalogName(value: String): String? {
    val cleaned = value
        .trim()
        .replace(Regex("""(?i)\s+(stremio\s+)?addon$"""), "")
        .replace(Regex("""\s+"""), " ")
        .takeIf { it.isNotBlank() }
        ?: return null

    val lower = cleaned.lowercase()
    return when {
        "cinemeta" in lower -> "Cinemeta"
        "mediafusion" in lower || "media fusion" in lower -> "MediaFusion"
        Regex("""\btmdb\b""").containsMatchIn(lower) || "the movie database" in lower -> "TMDB"
        Regex("""\bimdb\b""").containsMatchIn(lower) -> "IMDb"
        Regex("""\btrakt\b""").containsMatchIn(lower) -> "Trakt"
        else -> cleaned.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}

private fun searchTypeLabel(item: MediaItem): String = when (item.type.lowercase()) {
    "movie" -> "Movie"
    "series", "tv" -> "Series"
    "anime" -> "Anime"
    else -> item.type.replaceFirstChar { it.uppercase() }
}

private fun mediaKey(item: MediaItem): String = "${item.type}:${item.id}"

private fun androidx.compose.ui.input.key.KeyEvent.isTvActivationKey(): Boolean =
    nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
        nativeKeyEvent.keyCode == KeyEvent.KEYCODE_ENTER ||
        nativeKeyEvent.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER
