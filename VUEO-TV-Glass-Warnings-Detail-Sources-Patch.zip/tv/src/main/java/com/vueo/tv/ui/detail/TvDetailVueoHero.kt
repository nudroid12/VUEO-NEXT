package com.vueo.tv.detail

import kotlin.math.abs
import kotlinx.coroutines.flow.first
import com.vueo.tv.ui.motion.tvTunedSpec
import com.vueo.tv.ui.motion.TvMotionGroup
import com.vueo.tv.ui.motion.TvMotion
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.draw.alpha
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.key
import androidx.compose.foundation.layout.offset
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vueo.shared.core.enrichment.MediaRating
import com.vueo.shared.core.detail.DetailPeoplePolicy
import com.vueo.shared.core.enrichment.ContentWarningRepository
import com.vueo.shared.core.media.MediaItem
import com.vueo.tv.R
import com.vueo.tv.ui.TvDesign
import com.vueo.tv.ui.TvNetworkImage

private val VueoHeroContentWidth = .50f
private val VueoHeroActionSize = 44.dp

@Composable
internal fun VueoDetailHero(
    state: TvDetailPresentationState,
    heroHeight: Dp,
    playRequester: FocusRequester,
    listRequester: FocusRequester,
    downRequester: FocusRequester?,
    onPlay: () -> Unit,
    onToggleList: () -> Unit,
    onToggleWatched: () -> Unit,
) {
    val context = LocalContext.current
    val profile = com.vueo.shared.core.storage.ProfileStore(context).activeProfileId()
    val store = remember(profile) { com.vueo.shared.core.storage.LibraryStore(context, profileIdOverride = profile) }
    val ratingRequester = remember { FocusRequester() }
    val item = state.item
    var rating by remember(item.id, item.type, profile) { mutableStateOf(store.ratings().firstOrNull {
        it.media.id == item.id && it.media.type == item.type
    }?.value ?: 0) }

    val creditLines = remember(item) { DetailPeoplePolicy.creditLines(item) }
    val seriesNeedsEpisode = item.isDetailSeries() && item.episodes.isNotEmpty()
    val canPlay = !seriesNeedsEpisode || state.selectedEpisode != null
    val releaseDate = (state.vueoExtras.fullReleaseDate ?: item.releaseInfo)
        ?.trim()
        ?.takeIf(String::isNotBlank)
    val secondaryMeta = remember(item, state.vueoExtras.country, state.vueoExtras.language) {
        buildList {
            item.runtimeMinutes?.takeIf { it > 0 }?.let { add(vueoDetailRuntime(it)) }
            state.vueoExtras.country?.trim()?.takeIf(String::isNotBlank)?.let(::add)
            (state.vueoExtras.language ?: item.originalLanguage)
                ?.trim()
                ?.takeIf(String::isNotBlank)
                ?.uppercase()
                ?.let(::add)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(heroHeight)
            .padding(
                start = VueoDetailHorizontalPadding,
                end = VueoDetailHorizontalPadding,
                top = 24.dp,
                bottom = 32.dp,
            ),
        verticalArrangement = Arrangement.Bottom,
    ) {
        VueoHeroTitle(
            title = item.name,
            logoUrl = state.vueoExtras.logo,
            artworkLoading = state.titleArtworkLoading,
        )

        Spacer(Modifier.height(10.dp))

        if (item.genres.isNotEmpty()) {
            VueoMetaTextRow(item.genres.take(4), fontSize = 13)
            Spacer(Modifier.height(6.dp))
        }

        if (state.ratings.isNotEmpty() || state.dnaMatch != null) {
            VueoRatingsRow(state.ratings, state.dnaMatch)
            Spacer(Modifier.height(12.dp))
        } else {
            item.imdbRating?.takeIf { it.isFinite() && it > 0.0 }?.let {
                VueoMetaTextRow(listOf("IMDb ${String.format("%.1f", it)}"), fontSize = 13)
                Spacer(Modifier.height(10.dp))
            }
        }

        val certification = ContentWarningRepository.tvCertification(item)
        val imdbId = ContentWarningRepository.titleImdbId(item)
        val contentWarnings by produceState(emptyList<String>(), imdbId) {
            value = imdbId?.let { ContentWarningRepository.getForTvTitle(it) }.orEmpty()
        }
        if (certification != null || contentWarnings.isNotEmpty()) {
            VueoDetailContentWarning(certification, contentWarnings)
            Spacer(Modifier.height(10.dp))
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            VueoPlayButton(
                label = state.primaryActionLabel,
                enabled = canPlay,
                requester = playRequester,
                rightRequester = listRequester,
                downRequester = downRequester,
                onClick = onPlay,
            )
            VueoCircleAction(
                icon = if (state.watchlisted) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                contentDescription = if (state.watchlisted) "Remove from Watchlist" else "Add to Watchlist",
                selected = state.watchlisted,
                requester = listRequester,
                leftRequester = playRequester,
                rightRequester = ratingRequester,
                downRequester = downRequester,
                onClick = onToggleList,
            )
            key(item.id, item.type, profile) {
                VueoRatingPill(
                    rating = rating,
                    requester = ratingRequester,
                    leftRequester = listRequester,
                    downRequester = downRequester,
                    onRatingChanged = { value ->
                        store.setRating(item, value)
                        rating = value
                    },
                )
            }

        }

        Spacer(Modifier.height(8.dp))

        item.description?.trim()?.takeIf(String::isNotBlank)?.let { synopsis ->
            Text(
                text = synopsis,
                color = TvDesign.White.copy(alpha = .92f),
                fontSize = 14.sp,
                lineHeight = 19.sp,
                fontWeight = FontWeight.Normal,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth(VueoHeroContentWidth),
            )
            Spacer(Modifier.height(11.dp))
        }

        val status = state.vueoExtras.status?.trim()?.takeIf(String::isNotBlank)
        val releaseMeta = listOfNotNull(releaseDate) + secondaryMeta
        if (status != null || releaseMeta.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(VueoHeroContentWidth),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                status?.let { VueoMetaBadge(it) }
                if (releaseMeta.isNotEmpty()) {
                    Text(
                        text = releaseMeta.joinToString(" · "),
                        color = TvDesign.White.copy(alpha = .88f),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (creditLines.isNotEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth(VueoHeroContentWidth),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                creditLines.groupBy { it.names }.forEach { (names, roles) ->
                    Text(
                        text = "${roles.joinToString(" & ") { it.label }}: ${names.joinToString(", ")}",
                        color = TvDesign.White.copy(alpha = .76f),
                        fontSize = 14.sp,
                        lineHeight = 18.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.height(11.dp))
        }
    }
}

@Composable
private fun VueoHeroTitle(
    title: String,
    logoUrl: String?,
    artworkLoading: Boolean,
) {
    // Keep the logo within the leading margin, independent of the Play button's width.
    Box(Modifier.width(300.dp).height(100.dp), contentAlignment = Alignment.CenterStart) {
        if (!logoUrl.isNullOrBlank()) {
            TvNetworkImage(
                url = logoUrl,
                contentDescription = title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                contentScale = ContentScale.Fit,
                alignment = Alignment.CenterStart,
                fallback = Color.Transparent,
                highPriority = true,
            )
        } else if (!artworkLoading) {
            Text(
                text = title.uppercase(),
                color = TvDesign.White,
                fontSize = 32.sp,
                lineHeight = 42.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun VueoPlayButton(
    label: String,
    enabled: Boolean,
    requester: FocusRequester,
    rightRequester: FocusRequester,
    downRequester: FocusRequester?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(30.dp)

    Row(
        modifier = modifier
            .height(52.dp)
            .focusRequester(requester)
            .focusProperties {
                up = FocusRequester.Cancel
                right = rightRequester
                downRequester?.let { down = it }
            }
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(
                when {
                    !enabled -> Color.Black.copy(alpha = .28f)
                    focused -> Color.White
                    else -> Color.Black.copy(alpha = .68f)
                }
            )
            .border(
                width = 1.dp,
                color = if (focused) Color.White else Color.White.copy(alpha = .44f),
                shape = shape,
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 26.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            tint = if (!enabled) Color.White.copy(alpha = .48f) else if (focused) Color.Black else Color.White,
            modifier = Modifier.size(23.dp),
        )
        Text(
            text = label,
            color = if (!enabled) Color.White.copy(alpha = .48f) else if (focused) Color.Black else Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

/**
 * The closed rating button is also the persistent status indicator.
 * Its width grows to the right; the two choices reveal inside the same pill.
 */
@Composable
private fun VueoRatingPill(
    rating: Int,
    requester: FocusRequester,
    leftRequester: FocusRequester,
    downRequester: FocusRequester?,
    onRatingChanged: (Int) -> Unit,
) {
    val likeRequester = remember { FocusRequester() }
    val dislikeRequester = remember { FocusRequester() }
    var expanded by remember { mutableStateOf(false) }
    var groupFocused by remember { mutableStateOf(false) }
    var focusedValue by remember { mutableStateOf(0) }

    val statusWidth = VueoHeroActionSize
    val likeStart = statusWidth + 4.dp
    val dislikeStart = likeStart + VueoHeroActionSize
    val expandedWidth = dislikeStart + VueoHeroActionSize

    val animatedWidth by animateDpAsState(
        targetValue = if (expanded) expandedWidth else statusWidth,
        animationSpec = tvTunedSpec(TvMotionGroup.PANEL, expanded, tween(
            durationMillis = 250,
            easing = TvMotion.EaseInOut,
        )),
        label = "detailRatingPillWidth",
    )
    val pillWidth = animatedWidth.coerceIn(statusWidth, expandedWidth)
    val reveal = ((pillWidth - statusWidth) / (expandedWidth - statusWidth)).coerceIn(0f, 1f)
    val actionsAlpha = ((reveal - .10f) / .90f).coerceIn(0f, 1f)
    val slide = 10.dp * (1f - reveal)
    // Until the options are within the pill's visible bounds, keep the status
    // node focused. This also prevents an early OK from saving a rating.
    val actionsReady = expanded && animatedWidth >= expandedWidth - 1.dp

    val highlightOffset by animateDpAsState(
        targetValue = when {
            !expanded -> 0.dp
            focusedValue == 1 -> likeStart
            focusedValue == -1 -> dislikeStart
            else -> 0.dp
        },
        animationSpec = tvTunedSpec(TvMotionGroup.FOCUS, groupFocused, tween(
            durationMillis = 170,
            easing = TvMotion.EaseInOut,
        )),
        label = "detailRatingFocusSlide",
    )
    val highlightAlpha by animateFloatAsState(
        targetValue = if (groupFocused) 1f else 0f,
        animationSpec = tvTunedSpec(TvMotionGroup.FOCUS, groupFocused, tween(120)),
        label = "detailRatingFocusAlpha",
    )
    val highlightX = highlightOffset.coerceIn(0.dp, dislikeStart)
    val highlightOpacity = if (groupFocused) highlightAlpha.coerceIn(0f, 1f) else 0f

    fun iconTint(slot: Dp): Color {
        // Match the text/icon contrast to the moving white highlight.
        val distance = abs((highlightX - slot).value)
        val coverage = (1f - distance / 34f).coerceIn(0f, 1f) * highlightOpacity
        return lerp(Color.White, Color.Black, coverage)
    }

    fun closeRating() {
        // Restore the always-mounted status focus before disabling the actions.
        runCatching { requester.requestFocus() }
        focusedValue = 0
        expanded = false
    }

    BackHandler(enabled = expanded, onBack = ::closeRating)
    LaunchedEffect(expanded) {
        if (!expanded) return@LaunchedEffect
        snapshotFlow { animatedWidth >= expandedWidth - 1.dp }.first { it }
        val target = if (rating == -1) dislikeRequester else likeRequester
        repeat(4) {
            withFrameNanos { }
            if (!expanded) return@LaunchedEffect
            if (runCatching { target.requestFocus() }.getOrDefault(false)) {
                return@LaunchedEffect
            }
        }
        closeRating()
    }

    Box(
        modifier = Modifier
            .width(pillWidth)
            .height(VueoHeroActionSize)
            .onFocusChanged { state ->
                groupFocused = state.hasFocus
                if (!state.hasFocus) {
                    expanded = false
                    focusedValue = 0
                }
            }
            .focusGroup()
            .clip(CircleShape)
            .background(TvDesign.SurfaceRaised.copy(alpha = .84f))
            .border(
                width = if (groupFocused) 1.5.dp else 1.dp,
                color = TvDesign.Accent.copy(alpha = if (groupFocused) .95f else .36f),
                shape = CircleShape,
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        // A single accent indicator moves between the action slots.
        Box(
            modifier = Modifier
                .offset(x = highlightX + 4.dp)
                .size(VueoHeroActionSize - 8.dp)
                .alpha(highlightOpacity)
                .background(Color.White, CircleShape),
        )

        Box(
            modifier = Modifier
                .size(VueoHeroActionSize)
                .focusRequester(requester)
                .focusProperties {
                    up = FocusRequester.Cancel
                    left = leftRequester
                    right = if (actionsReady) likeRequester else FocusRequester.Cancel
                    downRequester?.let { down = it }
                }
                .onFocusChanged { if (it.isFocused) focusedValue = 0 }
                .clickable {
                    if (!expanded) expanded = true
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = when (rating) {
                    1 -> Icons.Default.ThumbUp
                    -1 -> Icons.Default.ThumbDown
                    else -> Icons.Outlined.ThumbUp
                },
                contentDescription = when (rating) {
                    1 -> "Liked: change rating"
                    -1 -> "Disliked: change rating"
                    else -> "Rate title"
                },
                tint = iconTint(0.dp),
                modifier = Modifier.size(24.dp),
            )
        }

        Box(
            modifier = Modifier
                .offset(x = statusWidth)
                .width(1.dp)
                .height(26.dp)
                .alpha(actionsAlpha)
                .background(TvDesign.White.copy(alpha = .30f)),
        )

        // Keep the two slots mounted through collapse for a continuous slide
        // and fade. Disabled slots cannot receive focus or activate.
        listOf(1, -1).forEach { value ->
            val isLike = value == 1
            val slot = if (isLike) likeStart else dislikeStart
            Box(
                modifier = Modifier
                    .offset(x = slot - slide)
                    .size(VueoHeroActionSize)
                    .alpha(actionsAlpha)
                    .focusRequester(if (isLike) likeRequester else dislikeRequester)
                    .focusProperties {
                        canFocus = actionsReady
                        up = FocusRequester.Cancel
                        left = if (isLike) leftRequester else likeRequester
                        right = if (isLike) dislikeRequester else FocusRequester.Cancel
                        downRequester?.let { down = it }
                    }
                    .onFocusChanged { if (it.isFocused) focusedValue = value }
                    .then(if (actionsReady) Modifier else Modifier.clearAndSetSemantics { })
                    .clickable(enabled = actionsReady) {
                        onRatingChanged(if (rating == value) 0 else value)
                        closeRating()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = when {
                        isLike && rating == value -> Icons.Default.ThumbUp
                        isLike -> Icons.Outlined.ThumbUp
                        rating == value -> Icons.Default.ThumbDown
                        else -> Icons.Outlined.ThumbDown
                    },
                    contentDescription = if (isLike) {
                        if (rating == value) "Clear like" else "Like"
                    } else {
                        if (rating == value) "Clear dislike" else "Dislike"
                    },
                    tint = iconTint(slot - slide),
                    modifier = Modifier.size(24.dp),
                )
            }
        }
    }
}

@Composable
private fun VueoCircleAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    selected: Boolean,
    requester: FocusRequester,
    leftRequester: FocusRequester,
    rightRequester: FocusRequester?,
    downRequester: FocusRequester?,
    onClick: () -> Unit,
) {
    var focused by remember(requester) { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .size(VueoHeroActionSize)
            .focusRequester(requester)
            .focusProperties {
                up = FocusRequester.Cancel
                left = leftRequester
                right = rightRequester ?: FocusRequester.Cancel
                downRequester?.let { down = it }
            }
            .onFocusChanged { focused = it.isFocused }
            .clip(CircleShape)
            .background(
                when {
                    focused -> Color.White
                    selected -> TvDesign.SurfaceRaised
                    else -> TvDesign.SurfaceRaised.copy(alpha = .82f)
                }
            )
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) Color.White else if (selected) TvDesign.Accent else Color.White.copy(alpha = .36f),
                shape = CircleShape,
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (focused) Color.Black else Color.White,
            modifier = Modifier.size(24.dp),
        )
    }
}

@Composable
private fun VueoDnaMatchMark(percent: Int) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_dna_match),
            contentDescription = "DNA Match",
            modifier = Modifier.size(18.dp),
            contentScale = ContentScale.Fit,
        )
        Text(
            text = "DNA",
            color = TvDesign.Muted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
        )
        Text(
            text = "${percent.coerceIn(0, 100)}%",
            color = TvDesign.Accent,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
        )
    }
}

@Composable
private fun VueoRatingsRow(ratings: List<MediaRating>, dnaMatch: Int?) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ratings
            .distinctBy(MediaRating::source)
            .sortedBy { rating ->
                when (rating.source.lowercase()) {
                    "trakt" -> 0
                    "imdb" -> 1
                    "tmdb" -> 2
                    "tomatoes" -> 3
                    "metacritic" -> 4
                    "myanimelist" -> 5
                    else -> 9
                }
            }
            .take(6)
            .forEach { rating ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    VueoRatingMark(rating.source)
                    Text(
                        text = vueoRatingDisplayValue(rating),
                        color = TvDesign.White.copy(alpha = .78f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        dnaMatch?.let { percent ->
            VueoDnaMatchMark(percent)
        }
    }
}

private fun vueoRatingDisplayValue(rating: MediaRating): String {
    if (rating.source.equals("tmdb", ignoreCase = true)) {
        rating.score?.takeIf { it.isFinite() }?.let { score ->
            return String.format("%.1f", score)
        }
    }
    return rating.displayValue().removeSuffix("%")
}

@Composable
private fun VueoRatingMark(source: String) {
    val normalized = source.lowercase()
    val logo = when (normalized) {
        "imdb" -> R.drawable.rating_imdb
        "tmdb" -> R.drawable.rating_tmdb
        "tomatoes" -> R.drawable.rating_rotten_tomatoes
        "metacritic" -> R.drawable.rating_metacritic
        "trakt" -> R.drawable.rating_trakt
        else -> null
    }

    if (logo != null) {
        Image(
            painter = painterResource(logo),
            contentDescription = source,
            modifier = Modifier.size(
                width = if (normalized == "imdb") 34.dp else 20.dp,
                height = 20.dp,
            ),
            contentScale = ContentScale.Fit,
        )
        return
    }

    Box(
        modifier = Modifier
            .height(22.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (normalized == "myanimelist") Color(0xFF2E51A2) else TvDesign.White.copy(alpha = .16f))
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (normalized == "myanimelist") "MAL" else source.take(4).uppercase(),
            color = TvDesign.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
        )
    }
}

@Composable
private fun VueoMetaTextRow(values: List<String>, fontSize: Int) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        values.forEachIndexed { index, value ->
            Text(
                text = value,
                color = TvDesign.White.copy(alpha = .70f),
                fontSize = fontSize.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (index < values.lastIndex) VueoMetaDot()
        }
    }
}

@Composable
private fun VueoMetaBadge(text: String) {
    Box(
        modifier = Modifier
            .border(
                width = 1.dp,
                color = TvDesign.White.copy(alpha = .55f),
                shape = RoundedCornerShape(5.dp),
            )
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = TvDesign.White.copy(alpha = .92f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
        )
    }
}

@Composable
private fun VueoDetailContentWarning(certification: String?, warnings: List<String>) {
    Text(
        text = (listOfNotNull(certification) + warnings).joinToString(" · "),
        color = Color.White,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth(VueoHeroContentWidth),
    )
}

@Composable
private fun VueoMetaDot() {
    Box(
        modifier = Modifier
            .size(3.dp)
            .clip(CircleShape)
            .background(TvDesign.White.copy(alpha = .58f)),
    )
}
