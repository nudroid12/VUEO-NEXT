package com.vueo.shared.core.smartsubs
import android.content.Context
class SmartSubsSettingsStore(context:Context) { fun apiKeyForSync()=""; fun importApiKey(value:String){} }
