package com.vueo.shared.core.home
import com.vueo.shared.core.media.MediaItem
object ForYouPolicy { fun aliases(media:MediaItem) = setOf("${media.type}:${media.id}") }
