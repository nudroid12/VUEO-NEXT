package com.vueo.shared.core.detail

import com.vueo.shared.core.enrichment.RichDetailsClient
import com.vueo.shared.core.enrichment.TmdbEnhancementClient
import com.vueo.shared.core.media.EpisodeItem
import com.vueo.shared.core.media.EpisodeNumberPolicy
import com.vueo.shared.core.media.MediaTypePolicy
import com.vueo.shared.core.media.MediaItem

/**
 * Mobile detail behavior promoted into Shared Core so TV does not re-invent it.
 * Mobile remains the behavioral upstream; TV should only adapt presentation/focus.
 */
object DetailUpstreamPolicy {
    suspend fun prepareForCore(
        item: MediaItem,
        tmdbApiKey: String,
    ): MediaItem {
        if (tmdbApiKey.isBlank() || !item.id.startsWith("tmdb:")) return item
        return TmdbEnhancementClient.prepareForCore(item, tmdbApiKey)
    }

    fun normalizeSeriesEpisodes(media: MediaItem): MediaItem {
        if (!MediaTypePolicy.isSeries(media.type) || media.episodes.isEmpty()) return media

        val normalized = media.episodes.map { episode ->
            val numbers = EpisodeNumberPolicy.normalize(episode.id, episode.season, episode.episode)
            episode.copy(season = numbers.season, episode = numbers.episode)
        }

        return media.copy(
            episodes = normalized.sortedWith(
                compareBy<EpisodeItem> { it.season }.thenBy { it.episode }
            )
        )
    }

    suspend fun enrichTmdb(
        media: MediaItem,
        tmdbApiKey: String,
        metadataEnabled: Boolean,
        artworkEnabled: Boolean,
    ): MediaItem {
        if (tmdbApiKey.isBlank() || (!metadataEnabled && !artworkEnabled)) return normalizeSeriesEpisodes(media)
        return normalizeSeriesEpisodes(TmdbEnhancementClient.enrich(media, tmdbApiKey, metadataEnabled, artworkEnabled))
    }

    suspend fun enrichRichDetails(
        media: MediaItem,
        tmdbApiKey: String,
        enabled: Boolean,
    ): MediaItem {
        if (tmdbApiKey.isBlank() || !enabled) return normalizeSeriesEpisodes(media)
        return normalizeSeriesEpisodes(RichDetailsClient.enrich(media, tmdbApiKey))
    }
}
