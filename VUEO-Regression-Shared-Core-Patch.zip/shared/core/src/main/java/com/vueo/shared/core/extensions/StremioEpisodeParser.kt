package com.vueo.shared.core.extensions

import com.vueo.shared.core.media.EpisodeItem
import com.vueo.shared.core.media.EpisodeNumberPolicy
import com.vueo.shared.core.stremio.StremioUrls
import org.json.JSONArray

internal fun JSONArray?.toEpisodeList(): List<EpisodeItem> {
    if (this == null) return emptyList()

    val parsed = (0 until length()).mapNotNull { index ->
        val item = optJSONObject(index) ?: return@mapNotNull null
        val id = item.optString("id").trim().takeIf(String::isNotBlank)
            ?: return@mapNotNull null
        val numbers = EpisodeNumberPolicy.normalize(id, item.optInt("season", -1), item.optInt("episode", -1))
        val season = numbers.season
        val episode = numbers.episode
        if (season < 0 || episode < 0) return@mapNotNull null

        EpisodeItem(
            id = id,
            title = item.optString("title")
                .trim()
                .takeIf(String::isNotBlank)
                ?: item.optString("name")
                    .trim()
                    .takeIf(String::isNotBlank)
                ?: "Episode $episode",
            season = season,
            episode = episode,
            released = item.optString("released").trim().takeIf(String::isNotBlank),
            overview = item.optString("overview").trim().takeIf(String::isNotBlank)
                ?: item.optString("description").trim().takeIf(String::isNotBlank),
            thumbnail = item.optString("thumbnail")
                .trim()
                .takeIf { StremioUrls.isHttpUrl(it) },
        )
    }

    return parsed.sortedWith(
        compareBy<EpisodeItem> { it.season }
            .thenBy { it.episode },
    )
}

