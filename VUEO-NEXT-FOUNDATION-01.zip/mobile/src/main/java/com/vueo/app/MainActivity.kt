package com.vueo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.vueo.shared.core.VueoClient
import com.vueo.shared.core.VueoCore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VueoMobileFoundation()
        }
    }
}

@Composable
private fun VueoMobileFoundation() {
    val handshake = VueoCore.handshake(VueoClient.MOBILE)

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "VUEO Mobile",
                    style = MaterialTheme.typography.headlineLarge,
                )
                Text(
                    text = handshake.message,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}
