// Structural tombstone: implementation moved to
// mobile/src/main/java/com/vueo/mobile/ui/player/PlayerAudioWorkspace.kt
// Kept inert because replacement ZIP overlays cannot delete tracked paths.
