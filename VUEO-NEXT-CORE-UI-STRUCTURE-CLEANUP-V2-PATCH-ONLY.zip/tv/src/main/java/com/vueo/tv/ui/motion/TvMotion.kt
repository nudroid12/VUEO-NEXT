// Structural tombstone: implementation moved to
// tv/src/main/java/com/vueo/tv/ui/theme/TvMotion.kt
// Kept inert because replacement ZIP overlays cannot delete tracked paths.
