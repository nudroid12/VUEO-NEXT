package com.vueo.shared.core.source

import com.vueo.shared.core.extensions.SourceCleaner
import com.vueo.shared.core.extensions.UnifiedMediaEngine
import com.vueo.shared.core.extensions.AddonRequestActivity
import com.vueo.shared.core.media.EpisodeItem
import com.vueo.shared.core.media.MediaItem
import com.vueo.shared.core.media.MediaTypePolicy
import com.vueo.shared.core.media.StreamSource
import com.vueo.shared.core.media.SubtitleTrack
import com.vueo.shared.core.plugin.PluginDiscoveryResult
import com.vueo.shared.core.plugin.PluginSourceEngine
import com.vueo.shared.core.plugin.PluginStore
import com.vueo.shared.core.plugin.TmdbResolver
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ConcurrentHashMap

/**
 * Shared progressive source-discovery orchestration for Mobile and TV.
 * UI/player lifecycle remains owned by each app; this class owns only the
 * deterministic cache/addon/plugin/subtitle merge and ranking pipeline.
 */
class SourceDiscoveryEngine(
    private val mediaEngine: UnifiedMediaEngine,
    private val pluginEngine: PluginSourceEngine,
    private val pluginStore: PluginStore,
) {
    suspend fun discover(
        request: SourceDiscoveryRequest,
        control: SourceDiscoveryControl? = null,
        onUpdate: (SourceDiscoverySnapshot) -> Unit = {},
    ): SourceDiscoveryBundle = coroutineScope {
        val item = request.item
        val videoId = request.videoId
        val preferredQuality = request.preferredQuality
        val cacheKey = SourceDiscoveryCache.key(
            mediaType = item.type,
            mediaId = item.id,
            videoId = videoId,
        )
        val cached = if (request.sourceProviderName == null) SourceDiscoveryCache.get(cacheKey) else null
        // Per-scan memoization avoids parsing the same source on every update.
        val episodeDecisions = ConcurrentHashMap<StreamSource, String>()
        fun rejectionReason(source: StreamSource): String {
            val episode = request.episode ?: return ""
            return episodeDecisions.computeIfAbsent(source) {
                SourceEpisodePolicy.mismatch(
                    name = source.name,
                    url = source.url,
                    season = episode.season,
                    episode = episode.episode,
                )?.let { found ->
                    "requested S${episode.season}E${episode.episode}, source states S${found.season}E${found.episode}"
                }.orEmpty()
            }
        }
        val cachedCandidates = cached?.sources.orEmpty().map { it.toStreamSource() }
        val cachedStreams = SourceCleaner.clean(
            sources = cachedCandidates.filter { rejectionReason(it).isEmpty() },
            preferredQuality = preferredQuality,
            originalLanguage = item.originalLanguage,
        )

        val startedAtNs = System.nanoTime()
        val activityLog = CopyOnWriteArrayList<SourceDiscoveryActivity>()
        var subtitles = emptyList<SubtitleTrack>()
        var subtitlesResolved = false
        var freshAddonStreams = emptyList<StreamSource>()
        var freshPluginStreams = emptyList<StreamSource>()
        var addonRawCount = 0
        var pluginRawCount = 0
        var addonCompleted = 0
        var addonTotal = 0
        var pluginCompleted = 0
        var pluginTotal = 0
        var notice = cached?.notice
        var firstResultMs: Long? = null
        var searching = true
        var latestProgress = if (cached != null) {
            "Recent sources loaded instantly • refreshing in background"
        } else {
            "Starting source discovery…"
        }
        var providerOrder = cachedStreams
            .asSequence()
            .filter { it.isDirectPlayable }
            .map(::providerKey)
            .distinct()
            .toList()
        val loadingProviders = linkedSetOf<String>()
        val completedSourceProviders = linkedSetOf<String>()
        val plannedSourceProviders = (
            mediaEngine.installed().filter {
                mediaEngine.isExtensionEnabled(it.descriptor.id) && "stream" in it.descriptor.resources
            }.map { it.descriptor.name }.filter { request.sourceProviderName == null || it.equals(request.sourceProviderName, true) } + configuredPluginProviderKeys(request)
        ).distinct()

        fun markProviderLoading(provider: String) {
            val key = provider.trim().ifBlank { "Other" }
            synchronized(loadingProviders) {
                loadingProviders += key
                completedSourceProviders -= key
            }
        }

        fun markProviderComplete(provider: String) {
            val key = provider.trim().ifBlank { "Other" }
            synchronized(loadingProviders) {
                loadingProviders -= key
                completedSourceProviders += key
            }
        }

        fun loadingProviderSnapshot(): List<String> =
            synchronized(loadingProviders) { loadingProviders.toList() }

        fun elapsedMs(): Long =
            (System.nanoTime() - startedAtNs) / 1_000_000L

        fun activity(
            category: String,
            level: String = "info",
            message: String,
        ) {
            activityLog += SourceDiscoveryActivity(
                elapsedMs = elapsedMs(),
                category = category,
                level = level,
                message = sanitizeActivityText(message),
            )
            if (activityLog.size > MAX_ACTIVITY_ENTRIES) {
                activityLog.removeAt(0)
            }
        }

        fun recordAddonActivity(event: AddonRequestActivity) {
            if (event.resource == "sources") {
                if (event.phase == "started") {
                    markProviderLoading(event.providerName)
                } else {
                    markProviderComplete(event.providerName)
                }
            }
            val category = if (event.resource == "subtitles") "subtitles" else "requests"
            val level = when (event.phase) {
                "timeout", "failed" -> "error"
                "retrying" -> "warning"
                else -> "info"
            }
            val message = when (event.phase) {
                "started" -> "${event.providerName} → Requesting ${event.resource}"
                "retrying" -> "${event.providerName} → Retrying subtitle request"
                "timeout" -> "${event.providerName} → ${event.resource.replaceFirstChar { it.uppercase() }} timed out after ${event.elapsedMs} ms"
                "failed" -> "${event.providerName} → ${event.resource.replaceFirstChar { it.uppercase() }} failed (${event.errorType ?: "unknown error"})"
                else -> buildString {
                    append("${event.providerName} ← ${event.resultCount} ${event.resource} received")
                    event.acceptedCount
                        ?.takeIf { it != event.resultCount }
                        ?.let { accepted ->
                            append(" • $accepted preferred accepted")
                        }
                    append(" in ${event.elapsedMs} ms")
                }
            }
            activity(category, level, message)
        }

        fun recordProviders(candidates: List<StreamSource>) {
            val next = providerOrder.toMutableList()
            candidates
                .asSequence()
                .filter { it.isDirectPlayable }
                .map(::providerKey)
                .distinct()
                .forEach { provider ->
                    if (provider !in next) next += provider
                }
            providerOrder = next
        }

        val loggedEpisodeRejections = ConcurrentHashMap.newKeySet<StreamSource>()
        fun episodeMatched(candidates: List<StreamSource>): List<StreamSource> =
            candidates.filter { source ->
                val reason = rejectionReason(source)
                if (reason.isNotEmpty() && loggedEpisodeRejections.add(source)) {
                    activity(
                        category = "sources",
                        level = "warning",
                        message = "${source.providerName} → Source rejected: $reason",
                    )
                }
                reason.isEmpty()
            }

        fun cleanFresh(): List<StreamSource> =
            SourceCleaner.clean(
                sources = episodeMatched(freshAddonStreams + freshPluginStreams),
                preferredQuality = preferredQuality,
                originalLanguage = item.originalLanguage,
            )

        fun publish(
            progress: String,
            streams: List<StreamSource>? = null,
        ) {
            val displayedProgress = if (control?.pluginsStopped == true && searching && progress.startsWith("Searching"))
                "$progress • Plugin scan stopped" else progress
            latestProgress = displayedProgress
            val fresh = cleanFresh()
            val display = streams ?: if (searching) {
                SourceCleaner.clean(
                    sources = cachedStreams + fresh,
                    preferredQuality = preferredQuality,
                    originalLanguage = item.originalLanguage,
                )
            } else {
                fresh.ifEmpty { cachedStreams }
            }

            recordProviders(display)
            if (
                firstResultMs == null &&
                cachedStreams.isEmpty() &&
                display.isNotEmpty()
            ) {
                firstResultMs = elapsedMs()
            }

            val rawCount = maxOf(
                cached?.rawCount ?: 0,
                addonRawCount + pluginRawCount,
            )
            onUpdate(
                SourceDiscoverySnapshot(
                    bundle = SourceDiscoveryBundle(
                        videoId = videoId,
                        sources = display,
                        subtitles = subtitles,
                    ),
                    rawCount = rawCount,
                    notice = notice,
                    searching = searching,
                    progress = displayedProgress,
                    pluginsStopped = control?.pluginsStopped == true,
                    sourcesStopped = control?.sourcesStopped == true,
                    firstResultMs = firstResultMs,
                    providerOrder = providerOrder,
                    fromCache = cachedStreams.isNotEmpty(),
                    subtitlesResolved = subtitlesResolved,
                    activityLog = activityLog.toList(),
                    loadingProviders = loadingProviderSnapshot(),
                    completedSourceProviders = synchronized(loadingProviders) { completedSourceProviders.toList() },
                    plannedSourceProviders = plannedSourceProviders,
                )
            )
        }

        episodeMatched(cachedCandidates)
        request.episode?.let { episode ->
            activity("requests", message = "Episode request → S${episode.season}E${episode.episode}")
        }
        activity(
            category = "system",
            message = if (request.forceRefresh) {
                "Source discovery started • manual refresh"
            } else {
                "Source discovery started • video ${maskedVideoId(videoId)}"
            },
        )
        if (cachedStreams.isNotEmpty()) {
            activity("sources", message = "Cache → ${cachedStreams.size} recent sources loaded")
        }
        publish(latestProgress, streams = cachedStreams)

        val subtitlesUpdateDeferred = async {
            if (!request.discoverSubtitles) {
                subtitlesResolved = true
                return@async
            }
            activity("subtitles", message = "Subtitle discovery started in parallel")
            request.subtitleLanguageCodes
                ?.takeIf { it.isNotEmpty() }
                ?.let { codes ->
                    activity(
                        "subtitles",
                        message = "Preferred-language filter active • ${codes.sorted().joinToString(", ")}",
                    )
                }
            publish(latestProgress)
            try {
                subtitles = mediaEngine.resolveSubtitles(
                    type = item.type,
                    videoId = videoId,
                    allowedLanguageCodes = request.subtitleLanguageCodes,
                    onProgress = { discovered ->
                        subtitles = discovered
                        activity(
                            "subtitles",
                            message = "Subtitle merge → ${discovered.size} unique tracks available",
                        )
                        publish(latestProgress)
                    },
                    onInitialPassComplete = {
                        subtitlesResolved = true
                        publish(latestProgress)
                    },
                    onActivity = ::recordAddonActivity,
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                // Retain any tracks already published before a later request failed.
                activity(
                    "subtitles",
                    level = "error",
                    message = "Subtitle discovery failed before completion • retaining ${subtitles.size} received tracks",
                )
            } finally {
                if (!subtitlesResolved) {
                    subtitlesResolved = true
                    publish(latestProgress)
                }
                activity(
                    "subtitles",
                    message = "Subtitle discovery completed • ${subtitles.size} tracks",
                )
                publish(latestProgress)
            }
        }

        val addonsDeferred = async(start = CoroutineStart.LAZY) {
            activity("requests", message = "Addon source requests started")
            publish(latestProgress)
            try {
                mediaEngine.resolveStreamsProgressive(
                    providerNameFilter = request.sourceProviderName,
                    type = item.type,
                    videoId = videoId,
                    onActivity = { event ->
                        recordAddonActivity(event)
                        publish(latestProgress)
                    },
                ) { progress ->
                    freshAddonStreams = progress.streams
                    addonRawCount = progress.rawCount
                    addonCompleted = progress.completedAddons
                    addonTotal = progress.totalAddons
                    publish(
                        progressLabel(
                            addonCompleted = addonCompleted,
                            addonTotal = addonTotal,
                            pluginCompleted = pluginCompleted,
                            pluginTotal = pluginTotal,
                            found = cleanFresh().size,
                        )
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                activity(
                    "errors",
                    level = "error",
                    message = "Addon source discovery failed before completion",
                )
                publish(latestProgress)
                emptyList()
            } finally {
                if (control?.sourcesStopped == true) publish("Source scan stopped")
            }
        }

        control?.attachAddons(addonsDeferred)
        addonsDeferred.invokeOnCompletion { control?.detachAddons(addonsDeferred) }
        addonsDeferred.start()

        val pluginsDeferred = async(start = CoroutineStart.LAZY) {
            val configuredPluginProviders = configuredPluginProviderKeys(request)
            try {
                configuredPluginProviders.forEach(::markProviderLoading)
                pluginTotal = configuredPluginProviders.size
                activity(
                    "requests",
                    message = buildString {
                        append("Plugin request → ")
                        append(item.type)
                        request.episode?.let { episode ->
                            append(" • S${episode.season} E${episode.episode}")
                        }
                        append(" • ")
                        append(item.name)
                    },
                )
                publish(latestProgress)
                var loggedPluginDiagnostics = 0
                val result = discoverPlugins(
                    request = request,
                    onSkipped = { skippedNotice ->
                        notice = skippedNotice
                        publish(
                            progressLabel(
                                addonCompleted = addonCompleted,
                                addonTotal = addonTotal,
                                pluginCompleted = pluginCompleted,
                                pluginTotal = pluginTotal,
                                found = cleanFresh().size,
                            )
                        )
                    },
                    onProgress = { progressResult, completed, total ->
                        freshPluginStreams = progressResult.streams.map { it.toStreamSource() }
                        pluginRawCount = progressResult.streams.size
                        pluginCompleted = completed
                        pluginTotal = total
                        progressResult.diagnostics
                            .forEach { diagnostic ->
                                markProviderComplete(
                                    "${diagnostic.repositoryName} / ${diagnostic.providerName}"
                                )
                            }
                        progressResult.diagnostics
                            .drop(loggedPluginDiagnostics)
                            .forEach { diagnostic ->
                                val failed = diagnostic.status.name in setOf(
                                    "TIMEOUT", "FAILED", "BLOCKED", "UNAVAILABLE"
                                )
                                activity(
                                    category = if (failed) "errors" else "requests",
                                    level = if (failed) "error" else "info",
                                    message = buildString {
                                        append(diagnostic.providerName)
                                        append(" ← ")
                                        append(diagnostic.status.name.lowercase().replace('_', ' '))
                                        append(" • ")
                                        append(diagnostic.streamCount)
                                        append(" sources • ")
                                        append(diagnostic.responseMs)
                                        append(" ms")
                                        diagnostic.errorType?.let { append(" • $it") }
                                    },
                                )
                            }
                        loggedPluginDiagnostics = progressResult.diagnostics.size
                        publish(
                            progressLabel(
                                addonCompleted = addonCompleted,
                                addonTotal = addonTotal,
                                pluginCompleted = pluginCompleted,
                                pluginTotal = pluginTotal,
                                found = cleanFresh().size,
                            )
                        )
                    },
                    forceRefresh = request.forceRefresh,
                )
                configuredPluginProviders.forEach(::markProviderComplete)
                publish(
                    progressLabel(
                        addonCompleted = addonCompleted,
                        addonTotal = addonTotal,
                        pluginCompleted = pluginCompleted,
                        pluginTotal = pluginTotal,
                        found = cleanFresh().size,
                    )
                )
                result
            } finally {
                configuredPluginProviders.forEach(::markProviderComplete)
                if (control?.pluginsStopped == true) {
                    activity("system", message = "Plugin discovery stopped for playback; addon/subtitle work continues")
                    publish(latestProgress)
                }
            }
        }
        control?.attachPlugins(pluginsDeferred)
        pluginsDeferred.invokeOnCompletion { control?.detachPlugins(pluginsDeferred) }
        pluginsDeferred.start()

        try {
            freshAddonStreams = addonsDeferred.await()
        } catch (cancelled: CancellationException) {
            currentCoroutineContext().ensureActive()
            if (control?.sourcesStopped != true) throw cancelled
            // Keep partial addon results; subtitles continue in their sibling job.
        }
        val pluginResult = try {
            pluginsDeferred.await()
        } catch (cancelled: CancellationException) {
            // Selective plugin cancellation must not cancel the parent scan.
            currentCoroutineContext().ensureActive()
            if (control?.pluginsStopped != true) throw cancelled
            null
        }

        if (pluginResult != null) {
            freshPluginStreams = pluginResult.streams.map { it.toStreamSource() }
            pluginRawCount = pluginResult.streams.size
            notice = pluginSummary(pluginResult)
        }

        val freshFinal = cleanFresh()
        val finalStreams = if (control?.pluginsStopped == true || control?.sourcesStopped == true) SourceCleaner.clean(
            sources = cachedStreams + freshFinal,
            preferredQuality = preferredQuality,
            originalLanguage = item.originalLanguage,
        ) else freshFinal.ifEmpty { cachedStreams }
        searching = false
        synchronized(loadingProviders) { loadingProviders.clear() }
        recordProviders(finalStreams)

        val rawCount = maxOf(
            cached?.rawCount ?: 0,
            addonRawCount + pluginRawCount,
        )
        val finalProgress = if (control?.sourcesStopped == true) {
            "Source scan stopped • ${finalStreams.size} unique sources"
        } else if (control?.pluginsStopped == true) {
            "Search finished • plugins stopped • ${finalStreams.size} unique sources"
        } else if (finalStreams.isEmpty()) {
            "Search complete • no sources found"
        } else {
            "Search complete • ${finalStreams.size} unique sources"
        }
        val removedCount = (rawCount - finalStreams.size).coerceAtLeast(0)
        activity(
            category = "sources",
            message = "Validation → $rawCount raw • ${finalStreams.size} unique • $removedCount removed",
        )
        finalStreams.firstOrNull()?.let { recommended ->
            activity(
                category = "sources",
                message = "Ranking → ${recommended.providerName} selected as current top source",
            )
        }
        activity(
            category = "system",
            level = if (finalStreams.isEmpty()) "warning" else "info",
            message = finalProgress,
        )
        latestProgress = finalProgress
        var finalBundle = SourceDiscoveryBundle(
            videoId = videoId,
            sources = finalStreams,
            subtitles = subtitles,
        )

        if (finalStreams.isNotEmpty() && request.sourceProviderName == null) {
            SourceDiscoveryCache.put(
                key = cacheKey,
                sources = finalStreams.map { it.toSourceCandidate() },
                rawCount = rawCount,
                notice = notice,
            )
        }

        onUpdate(
            SourceDiscoverySnapshot(
                bundle = finalBundle,
                rawCount = rawCount,
                notice = notice,
                searching = false,
                pluginsStopped = control?.pluginsStopped == true,
                sourcesStopped = control?.sourcesStopped == true,
                progress = finalProgress,
                firstResultMs = firstResultMs,
                providerOrder = providerOrder,
                fromCache = cachedStreams.isNotEmpty(),
                subtitlesResolved = subtitlesResolved,
                activityLog = activityLog.toList(),
                loadingProviders = emptyList(),
                completedSourceProviders = synchronized(loadingProviders) { completedSourceProviders.toList() },
                plannedSourceProviders = plannedSourceProviders,
            )
        )

        // Streams are complete independently from subtitle addons. Publish the
        // playable result now; slow subtitle retries may continue and merge into
        // the active player without holding source selection or next-episode play.
        subtitlesUpdateDeferred.await()
        finalBundle = finalBundle.copy(subtitles = subtitles)
        onUpdate(
            SourceDiscoverySnapshot(
                bundle = finalBundle,
                rawCount = rawCount,
                notice = notice,
                searching = false,
                pluginsStopped = control?.pluginsStopped == true,
                sourcesStopped = control?.sourcesStopped == true,
                progress = finalProgress,
                firstResultMs = firstResultMs,
                providerOrder = providerOrder,
                fromCache = cachedStreams.isNotEmpty(),
                subtitlesResolved = true,
                activityLog = activityLog.toList(),
                loadingProviders = emptyList(),
                completedSourceProviders = synchronized(loadingProviders) { completedSourceProviders.toList() },
                plannedSourceProviders = plannedSourceProviders,
            )
        )
        finalBundle
    }

    private suspend fun discoverPlugins(
        request: SourceDiscoveryRequest,
        onSkipped: (String) -> Unit,
        onProgress: suspend (PluginDiscoveryResult, Int, Int) -> Unit,
        forceRefresh: Boolean,
    ): PluginDiscoveryResult? {
        if (!pluginStore.pluginsEnabled() || pluginStore.repositories().isEmpty() ||
            (request.sourceProviderName != null && configuredPluginProviderKeys(request).isEmpty())) {
            return null
        }

        val item = request.item
        val tmdbId = try {
            TmdbResolver.resolve(
                rawId = item.id,
                mediaType = item.type,
                apiKey = pluginStore.tmdbApiKey(),
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            null
        }

        if (tmdbId == null) {
            onSkipped(
                "Plugin providers skipped: VUEO could not resolve a TMDB ID. " +
                    "Add your TMDB API key in Settings > Enhancements > TMDB."
            )
            return null
        }

        return try {
            pluginEngine.discoverProgressive(
                tmdbId = tmdbId,
                mediaType = MediaTypePolicy.pluginType(item.type),
                season = request.episode?.season,
                episode = request.episode?.episode,
                mediaTitle = item.name,
                mediaOriginalTitle = item.originalTitle,
                mediaAliases = item.aliases,
                mediaYear = item.releaseInfo,
                mediaExternalId = item.id,
                mediaOriginalLanguage = item.originalLanguage,
                providerNameFilter = request.sourceProviderName,
                forceRefresh = forceRefresh,
            ) { progress ->
                onProgress(
                    progress.result,
                    progress.completedProviders,
                    progress.totalProviders,
                )
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            null
        }
    }

    private fun pluginSummary(result: PluginDiscoveryResult): String =
        "Plugins: ${result.attemptedProviders} checked • " +
            "${result.successfulProviders} online • " +
            "${result.slowProviders} slow • " +
            "${result.noResultProviders} no results • " +
            "${result.needsSetupProviders} setup • " +
            "${result.unavailableProviders} unavailable • " +
            "${result.blockedProviders} blocked • " +
            "${result.timeoutProviders} timeout • " +
            "${result.failedProviders} failed."

    private fun configuredPluginProviderKeys(
        request: SourceDiscoveryRequest,
    ): List<String> {
        if (!pluginStore.pluginsEnabled()) return emptyList()
        val mediaType = MediaTypePolicy.pluginType(request.item.type).lowercase()
        return pluginStore.repositories()
            .asSequence()
            .filter(pluginStore::isRepositoryEnabled)
            .flatMap { repository ->
                repository.providers.asSequence()
                    .filter { provider ->
                        pluginStore.isProviderEnabled(repository, provider) &&
                            (provider.supportedTypes.isEmpty() || mediaType in provider.supportedTypes) &&
                            "android" !in provider.disabledPlatforms
                    }
                    .map { provider -> "${repository.name} / ${provider.name}" }
            }
            .filter { request.sourceProviderName == null || it.equals(request.sourceProviderName, true) }
            .distinct()
            .toList()
    }

    private fun progressLabel(
        addonCompleted: Int,
        addonTotal: Int,
        pluginCompleted: Int,
        pluginTotal: Int,
        found: Int,
    ): String = buildString {
        append("Searching")
        if (addonTotal > 0) append(" • Addons $addonCompleted/$addonTotal")
        if (pluginTotal > 0) append(" • Providers $pluginCompleted/$pluginTotal")
        if (found > 0) append(" • $found found")
    }

    private fun providerKey(source: StreamSource): String =
        source.providerName.trim().ifBlank { "Other" }
}

data class SourceDiscoveryRequest(
    val item: MediaItem,
    val episode: EpisodeItem?,
    val videoId: String,
    val preferredQuality: String? = null,
    val forceRefresh: Boolean = false,
    val subtitleLanguageCodes: Set<String>? = null,
    val sourceProviderName: String? = null,
    val discoverSubtitles: Boolean = true,
)

data class SourceDiscoverySnapshot(
    val bundle: SourceDiscoveryBundle,
    val rawCount: Int,
    val notice: String?,
    val searching: Boolean,
    val progress: String,
    val firstResultMs: Long?,
    val providerOrder: List<String>,
    val fromCache: Boolean,
    val subtitlesResolved: Boolean,
    val activityLog: List<SourceDiscoveryActivity> = emptyList(),
    val loadingProviders: List<String> = emptyList(),
    val pluginsStopped: Boolean = false,
    val sourcesStopped: Boolean = false,
    val completedSourceProviders: List<String> = emptyList(),
    val plannedSourceProviders: List<String> = emptyList(),
)

data class SourceDiscoveryActivity(
    val elapsedMs: Long,
    val category: String,
    val level: String,
    val message: String,
)

data class SourceDiscoveryBundle(
    val videoId: String,
    val sources: List<StreamSource>,
    val subtitles: List<SubtitleTrack>,
)

private const val MAX_ACTIVITY_ENTRIES = 180

private fun maskedVideoId(value: String): String =
    value.trim().let { clean ->
        when {
            clean.length <= 18 -> clean
            else -> clean.take(8) + "…" + clean.takeLast(6)
        }
    }

private fun sanitizeActivityText(value: String): String =
    value
        .replace(
            Regex("(?i)(token|api[_-]?key|authorization|cookie)=([^&\\s]+)")
        ) { match ->
            "${match.groupValues[1]}=•••"
        }
        .replace(Regex("https?://[^\\s]+"), "[request URL hidden]")
        .take(280)
