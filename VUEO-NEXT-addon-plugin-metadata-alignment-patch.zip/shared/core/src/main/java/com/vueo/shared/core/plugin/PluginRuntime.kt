package com.vueo.shared.core.plugin

import android.app.ActivityManager
import android.content.Context
import android.util.Base64
import com.dokar.quickjs.binding.asyncFunction
import com.dokar.quickjs.binding.define
import com.dokar.quickjs.binding.function
import com.dokar.quickjs.evaluate
import com.dokar.quickjs.quickJs
import com.vueo.shared.core.diagnostics.RuntimeDiagnostics
import com.vueo.shared.core.source.SourceCandidate
import com.vueo.shared.core.source.SourceRequest
import com.vueo.shared.core.source.SourceResolveResult
import com.vueo.shared.core.source.SourceResolver
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

data class ProviderDiagnostic(
    val repositoryManifestUrl: String,
    val repositoryName: String,
    val providerId: String,
    val providerName: String,
    val status: ProviderHealthStatus,
    val responseMs: Long,
    val streamCount: Int,
    val requestTmdbId: String? = null,
    val requestMediaType: String? = null,
    val requestSeason: Int? = null,
    val requestEpisode: Int? = null,
    val timeoutMs: Long? = null,
    val errorType: String? = null,
    val error: String? = null,
    val logs: List<String> = emptyList(),
)

data class PluginDiscoveryProgress(
    val result: PluginDiscoveryResult,
    val completedProviders: Int,
    val totalProviders: Int,
)

data class PluginDiscoveryResult(
    val streams: List<SourceCandidate>,
    val attemptedProviders: Int,
    val successfulProviders: Int,
    val slowProviders: Int,
    val noResultProviders: Int,
    val needsSetupProviders: Int,
    val unavailableProviders: Int,
    val blockedProviders: Int,
    val timeoutProviders: Int,
    val failedProviders: Int,
    val diagnostics: List<ProviderDiagnostic>,
    val fromCache: Boolean = false,
    val coalesced: Boolean = false,
    val readyProviders: Int = 0,
    val repairedProviders: Int = 0,
    val preflightErrors: List<String> = emptyList(),
)

class PluginSourceEngine(
    context: Context,
    private val store: PluginStore,
) {
    private val appContext =
        context.applicationContext

    private val activityManager =
        appContext.getSystemService(
            Context.ACTIVITY_SERVICE
        ) as? ActivityManager

    private val memoryClassMb =
        activityManager?.memoryClass
            ?: DEFAULT_MEMORY_CLASS_MB

    /*
     * Some devices report ActivityManager.memoryClass above the process'
     * actual Java heap growth limit. Runtime.maxMemory() is the limit that
     * matters to QuickJS/OkHttp allocations.
     */
    private val heapLimitMb =
        (
            Runtime.getRuntime().maxMemory() /
                (1024L * 1024L)
        ).toInt()

    private val lowMemoryDevice =
        activityManager?.isLowRamDevice == true ||
            memoryClassMb <= LOW_MEMORY_CLASS_MB ||
            heapLimitMb <= LOW_MEMORY_HEAP_LIMIT_MB

    /*
     * QuickJS instances are memory-heavy. Five simultaneous providers could
     * push a 256 MB heap close to OOM. Use a fast-lane queue on low-memory phones: up to three providers may
     * run, but only one long-running/heavy provider may occupy the queue.
     * That leaves two slots available for lighter/direct providers so first
     * results can arrive quickly without allowing several heavy QuickJS/WebView
     * jobs to spike the heap together.
     *
     * Higher-memory devices get four total slots, still below the old five.
     */
    private val providerConcurrencyLimit =
        if (lowMemoryDevice) 3 else 4

    private val webViewConcurrencyLimit =
        if (lowMemoryDevice) 1 else 2

    private val sourceScanBudgetMs =
        if (lowMemoryDevice) {
            LOW_MEMORY_SCAN_BUDGET_MS
        } else {
            DEFAULT_SCAN_BUDGET_MS
        }

    private val concurrency =
        Semaphore(providerConcurrencyLimit)

    private val webViewConcurrency =
        Semaphore(webViewConcurrencyLimit)

    private val webViewResolver =
        PluginWebViewResolver(
            appContext
        )

    private val healthStore =
        PluginHealthStore(
            appContext
        )

    private val codeStore =
        ProviderCodeStore(
            appContext
        )

    private val preflight =
        PluginRuntimePreflight(
            appContext
        )

    init {
        RuntimeDiagnostics.install(appContext)
    }

suspend fun discover(
    tmdbId: String,
    mediaType: String,
    season: Int?,
    episode: Int?,
    mediaTitle: String? = null,
    mediaOriginalTitle: String? = null,
    mediaAliases: List<String> = emptyList(),
    mediaYear: String? = null,
    mediaExternalId: String? = null,
    mediaOriginalLanguage: String? = null,
): PluginDiscoveryResult =
    discoverProgressive(
        tmdbId = tmdbId,
        mediaType = mediaType,
        season = season,
        episode = episode,
        mediaTitle = mediaTitle,
        mediaOriginalTitle = mediaOriginalTitle,
        mediaAliases = mediaAliases,
        mediaYear = mediaYear,
        mediaExternalId = mediaExternalId,
        mediaOriginalLanguage = mediaOriginalLanguage,
        onProgress = {},
    )

suspend fun discoverProgressive(
    tmdbId: String,
    mediaType: String,
    season: Int?,
    episode: Int?,
    mediaTitle: String? = null,
    mediaOriginalTitle: String? = null,
    mediaAliases: List<String> = emptyList(),
    mediaYear: String? = null,
    mediaExternalId: String? = null,
    mediaOriginalLanguage: String? = null,
    onProgress: suspend (PluginDiscoveryProgress) -> Unit,
): PluginDiscoveryResult =
    supervisorScope {

        if (!store.pluginsEnabled()) {
            return@supervisorScope emptyDiscoveryResult()
        }

        val knownHealth =
            healthStore.records()
                .associateBy {
                    it.repositoryManifestUrl to
                        it.providerId
                }

        val targets =
            store.repositories()
                .filter(store::isRepositoryEnabled)
                .flatMap { repository ->
                    repository.providers
                        .filter { provider ->
                            store.isProviderEnabled(
                                repository,
                                provider,
                            )
                        }
                        .filter { provider ->
                            provider.supportedTypes
                                .isEmpty() ||
                                mediaType.lowercase() in
                                provider.supportedTypes
                        }
                        .filter { provider ->
                            "android" !in
                                provider.disabledPlatforms
                        }
                        .map { provider ->
                            repository to provider
                        }
                }
                .sortedWith(
                    compareBy<
                        Pair<
                            PluginRepositoryDescriptor,
                            PluginProviderDescriptor
                        >
                    > {
                        val record =
                            knownHealth[
                                it.first.manifestUrl to
                                    it.second.id
                            ]

                        providerPriority(
                            record?.status
                        )
                    }.thenBy {
                        knownHealth[
                            it.first.manifestUrl to
                                it.second.id
                        ]?.responseMs
                            ?: Long.MAX_VALUE
                    }
                )

        if (targets.isEmpty()) {
            return@supervisorScope emptyDiscoveryResult()
        }

        val cacheKey =
            PluginRuntimeCache.key(
                store = store,
                tmdbId = tmdbId,
                mediaType = mediaType,
                season = season,
                episode = episode,
            )

        PluginRuntimeCache.get(cacheKey)
            ?.let { cached ->
                onProgress(
                    PluginDiscoveryProgress(
                        result = cached,
                        completedProviders = targets.size,
                        totalProviders = targets.size,
                    )
                )
                return@supervisorScope cached
            }

        val flight =
            PluginRuntimeCache.acquireFlight(
                cacheKey
            )

        if (!flight.owner) {
            val joined =
                flight.deferred
                    .await()
                    .copy(
                        coalesced = true
                    )

            onProgress(
                PluginDiscoveryProgress(
                    result = joined,
                    completedProviders = targets.size,
                    totalProviders = targets.size,
                )
            )

            return@supervisorScope joined
        }

        val runtimeDiagnosticScanId =
            RuntimeDiagnostics.beginSourceScan(
                requestLabel = buildString {
                    append(mediaType.lowercase())
                    append(" • TMDB ")
                    append(tmdbId)
                    if (season != null && episode != null) {
                        append(" • S")
                        append(season.toString().padStart(2, '0'))
                        append(" E")
                        append(episode.toString().padStart(2, '0'))
                    }
                },
                targetProviders = targets.size,
            )
        val runtimeDiagnosticCompletedProviders = java.util.concurrent.atomic.AtomicInteger(0)
        val discoveryContextBroker =
            PluginDiscoveryContextBroker(
                scanId = runtimeDiagnosticScanId,
                tmdbId = tmdbId,
                mediaType = mediaType,
                season = season,
                episode = episode,
                seedTitle = mediaTitle,
                seedOriginalTitle = mediaOriginalTitle,
                seedAliases = mediaAliases,
                seedYear = mediaYear,
                seedExternalId = mediaExternalId,
                seedOriginalLanguage = mediaOriginalLanguage,
            )

        RuntimeDiagnostics.recordDiscoveryTrace(
            scanId = runtimeDiagnosticScanId,
            stage = "CONTEXT_INIT",
            details = "tmdb=$tmdbId type=${mediaType.lowercase()} season=${season ?: 0} episode=${episode ?: 0}",
        )

        try {
            val preparation =
                preflight.prepare(targets)

            val runs =
                mutableListOf<ProviderRun>()

            val mutex = Mutex()

            val providerJobs =
                targets.map {
                    (repository, provider) ->

                    async {
                        val providerStartedNs =
                            System.nanoTime()

                        val run =
                            try {
                                val execute: suspend () -> ProviderRun = {
                                    concurrency.withPermit {
                                        withContext(Dispatchers.Default) {
                                            val providerDiagnosticToken =
                                                RuntimeDiagnostics.beginProvider(
                                                    scanId = runtimeDiagnosticScanId,
                                                    providerName = provider.name,
                                                )
                                            try {
                                                runProvider(
                                                    repository =
                                                        repository,
                                                    provider =
                                                        provider,
                                                    tmdbId =
                                                        tmdbId,
                                                    mediaType =
                                                        mediaType,
                                                    season =
                                                        season,
                                                    episode =
                                                        episode,
                                                    runtimeDiagnosticScanId =
                                                        runtimeDiagnosticScanId,
                                                    discoveryContextBroker =
                                                        discoveryContextBroker,
                                                ).also { providerRun ->
                                                    RuntimeDiagnostics.finishProvider(
                                                        token = providerDiagnosticToken,
                                                        status = providerRun.diagnostic.status.name,
                                                        streamCount = providerRun.diagnostic.streamCount,
                                                        errorType = providerRun.diagnostic.errorType,
                                                    )
                                                }
                                            } catch (error: CancellationException) {
                                                RuntimeDiagnostics.finishProvider(
                                                    token = providerDiagnosticToken,
                                                    status = "CANCELLED",
                                                    streamCount = 0,
                                                    errorType = error::class.java.simpleName,
                                                )
                                                throw error
                                            } catch (error: Throwable) {
                                                RuntimeDiagnostics.finishProvider(
                                                    token = providerDiagnosticToken,
                                                    status = "THREW",
                                                    streamCount = 0,
                                                    errorType = error::class.java.simpleName,
                                                )
                                                throw error
                                            }
                                        }
                                    }
                                }

                                /*
                                 * Keep direct/API phases concurrent. Only the
                                 * actual WebView resolver is serialized on
                                 * low-memory devices.
                                 */
                                execute()
                            } catch (error: CancellationException) {
                                // Caller cancellation or the overall source-scan budget.
                                throw error
                            } catch (error: Throwable) {
                                failedProviderRun(
                                    repository = repository,
                                    provider = provider,
                                    tmdbId = tmdbId,
                                    mediaType = mediaType,
                                    season = season,
                                    episode = episode,
                                    elapsedMs =
                                        (
                                            System.nanoTime() -
                                                providerStartedNs
                                        ) / 1_000_000L,
                                    error = error,
                                )
                            }

                        saveHealth(run)
                        runtimeDiagnosticCompletedProviders.incrementAndGet()

                        val snapshot =
                            mutex.withLock {
                                runs += run

                                PluginDiscoveryProgress(
                                    result =
                                        buildDiscoveryResult(
                                            runs
                                        ).copy(
                                            readyProviders =
                                                preparation.alreadyReadyProviders +
                                                    preparation.repairedProviders,
                                            repairedProviders =
                                                preparation.repairedProviders,
                                            preflightErrors =
                                                preparation.errors,
                                        ),
                                    completedProviders =
                                        runs.size,
                                    totalProviders =
                                        targets.size,
                                )
                            }

                        onProgress(snapshot)
                    }
                }

            val completedWithinBudget =
                withTimeoutOrNull(
                    sourceScanBudgetMs
                ) {
                    providerJobs.awaitAll()
                    true
                } ?: false

            if (!completedWithinBudget) {
                providerJobs
                    .filter { it.isActive }
                    .forEach { job ->
                        job.cancel(
                            CancellationException(
                                "Plugin source scan budget reached"
                            )
                        )
                    }

                /*
                 * supervisorScope waits for children before returning anyway;
                 * joining here makes the cancellation point explicit and keeps
                 * native fetch/WebView cleanup deterministic.
                 */
                providerJobs.forEach { job ->
                    job.join()
                }
            }

            val result =
                mutex.withLock {
                    buildDiscoveryResult(
                        runs
                    ).copy(
                        readyProviders =
                            preparation.alreadyReadyProviders +
                                preparation.repairedProviders,
                        repairedProviders =
                            preparation.repairedProviders,
                        preflightErrors =
                            preparation.errors,
                    )
                }

            if (completedWithinBudget) {
                PluginRuntimeCache.put(
                    key = cacheKey,
                    result = result,
                )
            }

            /*
             * Coalesced callers still receive useful partial results when the
             * scan budget is reached, but partial runs are not stored in the
             * normal runtime cache so a later refresh can try remaining
             * providers.
             */
            PluginRuntimeCache.completeFlight(
                key = cacheKey,
                result = result,
            )

            RuntimeDiagnostics.finishSourceScan(
                scanId = runtimeDiagnosticScanId,
                streams = result.streams.size,
                completedProviders = result.attemptedProviders,
                outcome =
                    if (completedWithinBudget) {
                        "complete"
                    } else {
                        "budget"
                    },
            )

            result
        } catch (error: Throwable) {
            RuntimeDiagnostics.failSourceScan(
                scanId = runtimeDiagnosticScanId,
                error = error,
                completedProviders = runtimeDiagnosticCompletedProviders.get(),
            )
            PluginRuntimeCache.failFlight(
                key = cacheKey,
                error = error,
            )
            throw error
        }

    }


private fun failedProviderRun(
    repository: PluginRepositoryDescriptor,
    provider: PluginProviderDescriptor,
    tmdbId: String,
    mediaType: String,
    season: Int?,
    episode: Int?,
    elapsedMs: Long,
    error: Throwable,
): ProviderRun =
    ProviderRun(
        streams = emptyList(),
        diagnostic =
            ProviderDiagnostic(
                repositoryManifestUrl =
                    repository.manifestUrl,
                repositoryName =
                    repository.name,
                providerId =
                    provider.id,
                providerName =
                    provider.name,
                status =
                    ProviderHealthStatus.FAILED,
                responseMs =
                    elapsedMs.coerceAtLeast(0L),
                streamCount = 0,
                requestTmdbId = tmdbId,
                requestMediaType = mediaType,
                requestSeason = season,
                requestEpisode = episode,
                timeoutMs =
                    providerRuntimeTimeoutMs(
                        provider
                    ),
                errorType =
                    error::class.java.simpleName,
                error =
                    error.message
                        ?: error::class.java.simpleName,
                logs = emptyList(),
            ),
    )


private fun saveHealth(
    run: ProviderRun,
) {
    healthStore.save(
        ProviderHealthRecord(
            repositoryManifestUrl =
                run.diagnostic
                    .repositoryManifestUrl,
            repositoryName =
                run.diagnostic
                    .repositoryName,
            providerId =
                run.diagnostic
                    .providerId,
            providerName =
                run.diagnostic
                    .providerName,
            status =
                run.diagnostic
                    .status,
            responseMs =
                run.diagnostic
                    .responseMs,
            streamCount =
                run.diagnostic
                    .streamCount,
            requestTmdbId = run.diagnostic.requestTmdbId,
            requestMediaType = run.diagnostic.requestMediaType,
            requestSeason = run.diagnostic.requestSeason,
            requestEpisode = run.diagnostic.requestEpisode,
            timeoutMs = run.diagnostic.timeoutMs,
            errorType = run.diagnostic.errorType,
            error =
                run.diagnostic
                    .error,
            logs =
                run.diagnostic
                    .logs
                    .takeLast(
                        MAX_STORED_LOGS
                    ),
            lastCheckedEpochMs =
                System.currentTimeMillis(),
        )
    )
}

private fun buildDiscoveryResult(
    runs: List<ProviderRun>,
): PluginDiscoveryResult {
    val diagnostics =
        runs.map {
            it.diagnostic
        }

    return PluginDiscoveryResult(
        streams =
            runs
                .flatMap {
                    it.streams
                }
                .distinctBy {
                    listOf(
                        it.url,
                        it.infoHash,
                        it.fileIndex,
                        it.providerId,
                    )
                },
        attemptedProviders =
            runs.size,
        successfulProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .ONLINE
            },
        slowProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .SLOW
            },
        noResultProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .NO_RESULTS
            },
        needsSetupProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .NEEDS_SETUP
            },
        unavailableProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .UNAVAILABLE
            },
        blockedProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .BLOCKED
            },
        timeoutProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .TIMEOUT
            },
        failedProviders =
            diagnostics.count {
                it.status ==
                    ProviderHealthStatus
                        .FAILED
            },
        diagnostics =
            diagnostics,
    )
}

private fun emptyDiscoveryResult():
    PluginDiscoveryResult =
    PluginDiscoveryResult(
        streams = emptyList(),
        attemptedProviders = 0,
        successfulProviders = 0,
        slowProviders = 0,
        noResultProviders = 0,
        needsSetupProviders = 0,
        unavailableProviders = 0,
        blockedProviders = 0,
        timeoutProviders = 0,
        failedProviders = 0,
        diagnostics = emptyList(),
    )

private fun providerPriority(
    status: ProviderHealthStatus?,
): Int =
    when (status) {
        ProviderHealthStatus.ONLINE -> 0
        ProviderHealthStatus.SLOW -> 1
        ProviderHealthStatus.UNKNOWN,
        null -> 2
        ProviderHealthStatus.NO_RESULTS -> 3
        ProviderHealthStatus.TIMEOUT,
        ProviderHealthStatus.BLOCKED,
        ProviderHealthStatus.FAILED -> 4
        ProviderHealthStatus.NEEDS_SETUP,
        ProviderHealthStatus.UNAVAILABLE -> 5
    }

    private suspend fun runProvider(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
        tmdbId: String,
        mediaType: String,
        season: Int?,
        episode: Int?,
        runtimeDiagnosticScanId: Long,
        discoveryContextBroker: PluginDiscoveryContextBroker,
    ): ProviderRun {
        val started =
            System.nanoTime()

        val providerTimeoutMs =
            providerRuntimeTimeoutMs(provider)

        val execution =
            withTimeoutOrNull(
                providerTimeoutMs
            ) {
                try {
                    executeProvider(
                        repository =
                            repository,
                        provider =
                            provider,
                        tmdbId =
                            tmdbId,
                        mediaType =
                            mediaType,
                        season =
                            season,
                        episode =
                            episode,
                        runtimeDiagnosticScanId =
                            runtimeDiagnosticScanId,
                        discoveryContextBroker =
                            discoveryContextBroker,
                    )
                } catch (error: CancellationException) {
                    // Preserve timeout/caller cancellation so WebView and provider work can stop.
                    throw error
                } catch (error: Throwable) {
                    ProviderExecution(
                        streams =
                            emptyList(),
                        error =
                            error.message
                                ?: error::class
                                    .java
                                    .simpleName,
                        errorType = error::class.java.simpleName,
                        logs =
                            emptyList(),
                    )
                }
            }
                ?: ProviderExecution(
                    streams =
                        emptyList(),
                    error =
                        "Timed out after " +
                        "${providerTimeoutMs / 1000}s",
                    errorType = "Timeout",
                    logs =
                        emptyList(),
                )

        val elapsedMs =
            (
                System.nanoTime() -
                started
            ) / 1_000_000L

        val consoleError =
            execution.logs
                .lastOrNull {
                    it.startsWith(
                        "ERROR: "
                    )
                }
                ?.removePrefix(
                    "ERROR: "
                )

        val error =
            execution.error
                ?: consoleError

        val status =
            when {
                execution.streams
                    .isNotEmpty() &&
                    elapsedMs >=
                    SLOW_THRESHOLD_MS ->
                    ProviderHealthStatus
                        .SLOW

                execution.streams
                    .isNotEmpty() ->
                    ProviderHealthStatus
                        .ONLINE

                error != null ->
                    classifyProviderFailure(
                        error
                    )

                else ->
                    ProviderHealthStatus
                        .NO_RESULTS
            }

        val rankBoost =
            when (status) {
                ProviderHealthStatus.ONLINE ->
                    if (elapsedMs < 1_000L) 30 else 22

                ProviderHealthStatus.SLOW ->
                    8

                else ->
                    0
            }

        return ProviderRun(
            streams =
                execution.streams.map {
                    it.copy(
                        rankBoost =
                            it.rankBoost +
                                rankBoost
                    )
                },
            diagnostic =
                ProviderDiagnostic(
                    repositoryManifestUrl =
                        repository.manifestUrl,
                    repositoryName =
                        repository.name,
                    providerId =
                        provider.id,
                    providerName =
                        provider.name,
                    status =
                        status,
                    responseMs =
                        elapsedMs,
                    streamCount =
                        execution.streams.size,
                    requestTmdbId = tmdbId,
                    requestMediaType = mediaType,
                    requestSeason = season,
                    requestEpisode = episode,
                    timeoutMs = providerTimeoutMs,
                    errorType = execution.errorType,
                    error =
                        error,
                    logs =
                        execution.logs
                            .takeLast(
                                MAX_STORED_LOGS
                            ),
                ),
        )
    }

    private suspend fun executeProvider(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
        tmdbId: String,
        mediaType: String,
        season: Int?,
        episode: Int?,
        runtimeDiagnosticScanId: Long,
        discoveryContextBroker: PluginDiscoveryContextBroker,
    ): ProviderExecution {
        val source =
            codeStore.read(
                repository,
                provider,
            )
                ?: return ProviderExecution(
                    streams =
                        emptyList(),
                    error =
                        "Provider code is not installed locally. " +
                        "Open Content Manager > Plugins and refresh this repository.",
                    errorType = "ProviderCodeMissing",
                    logs =
                        emptyList(),
                )

        val logs =
            CopyOnWriteArrayList<String>()

        val httpTraceCount =
            java.util.concurrent.atomic.AtomicInteger(0)
        val webViewTraceCount =
            java.util.concurrent.atomic.AtomicInteger(0)

        val providerTimeoutMs =
            providerRuntimeTimeoutMs(provider)

        return try {
            val resultJson =
                quickJs {
                    evaluationTimeoutMillis =
                        providerTimeoutMs

                    define("console") {
                        function("log") { args ->
                            logs +=
                                "LOG: " +
                                args
                                    .joinToString(" ")
                                    .take(
                                        MAX_LOG_LENGTH
                                    )
                        }

                        function("info") { args ->
                            logs +=
                                "LOG: " +
                                args
                                    .joinToString(" ")
                                    .take(
                                        MAX_LOG_LENGTH
                                    )
                        }

                        function("warn") { args ->
                            logs +=
                                "LOG: " +
                                args
                                    .joinToString(" ")
                                    .take(
                                        MAX_LOG_LENGTH
                                    )
                        }

                        function("error") { args ->
                            logs +=
                                "ERROR: " +
                                args
                                    .joinToString(" ")
                                    .take(
                                        MAX_LOG_LENGTH
                                    )
                        }
                    }

                    asyncFunction<String, String>(
                        "__vueoDiscoveryContext"
                    ) { requestJson ->
                        discoveryContextBroker
                            .resolveFromProviderRequest(
                                requestJson
                            )
                    }

                    function<String, String>(
                        "__vueoTrace"
                    ) { traceJson ->
                        val trace =
                            runCatching {
                                JSONObject(traceJson)
                            }.getOrNull()

                        RuntimeDiagnostics.recordDiscoveryTrace(
                            scanId = runtimeDiagnosticScanId,
                            providerName = provider.name,
                            stage =
                                trace
                                    ?.optString("stage")
                                    ?.takeIf { it.isNotBlank() }
                                    ?: "PROVIDER",
                            details =
                                trace
                                    ?.opt("details")
                                    ?.toString()
                                    ?: traceJson,
                        )
                        "ok"
                    }

                    asyncFunction<String, String>(
                        "__vueoNativeFetch"
                    ) { requestJson ->
                        val startedNs =
                            System.nanoTime()
                        val sharedTmdb =
                            discoveryContextBroker
                                .maybeExecuteTmdbFetch(
                                    requestJson
                                )
                        val responseJson =
                            sharedTmdb
                                ?: PluginHttp.executeJson(
                                    requestJson
                                )
                        val traceIndex =
                            httpTraceCount.incrementAndGet()

                        if (traceIndex <= MAX_HTTP_TRACE_ENTRIES) {
                            RuntimeDiagnostics.recordDiscoveryTrace(
                                scanId = runtimeDiagnosticScanId,
                                providerName = provider.name,
                                stage = "HTTP",
                                details =
                                    summarizeHttpTrace(
                                        requestJson = requestJson,
                                        responseJson = responseJson,
                                        elapsedMs =
                                            (
                                                System.nanoTime() -
                                                    startedNs
                                            ) / 1_000_000L,
                                        sharedTmdb =
                                            sharedTmdb != null,
                                    ),
                            )
                        }

                        responseJson
                    }

                    asyncFunction<String, String>(
                        "__vueoWebViewResolve"
                    ) { requestJson ->
                        val startedNs =
                            System.nanoTime()
                        val responseJson =
                            webViewConcurrency.withPermit {
                                webViewResolver.resolveJson(
                                    requestJson
                                )
                            }
                        val traceIndex =
                            webViewTraceCount.incrementAndGet()

                        if (traceIndex <= MAX_WEBVIEW_TRACE_ENTRIES) {
                            RuntimeDiagnostics.recordDiscoveryTrace(
                                scanId = runtimeDiagnosticScanId,
                                providerName = provider.name,
                                stage = "WEBVIEW",
                                details =
                                    summarizeWebViewTrace(
                                        requestJson = requestJson,
                                        responseJson = responseJson,
                                        elapsedMs =
                                            (
                                                System.nanoTime() -
                                                    startedNs
                                            ) / 1_000_000L,
                                    ),
                            )
                        }

                        responseJson
                    }

                    val htmlBridge =
                        HtmlCompatBridge()

                    function<String, String>(
                        "__vueoHtmlOp"
                    ) { requestJson ->
                        htmlBridge.execute(
                            requestJson
                        )
                    }

                    function<String, String>(
                        "__vueoCryptoOp"
                    ) { requestJson ->
                        CryptoCompatBridge.execute(
                            requestJson
                        )
                    }

                    function<String, String>(
                        "__vueoUrlOp"
                    ) { requestJson ->
                        UrlCompatBridge.execute(
                            requestJson
                        )
                    }

                    function<String, String>(
                        "__vueoBase64"
                    ) { value ->
                        Base64.encodeToString(
                            value.toByteArray(
                                Charsets.UTF_8
                            ),
                            Base64.NO_WRAP,
                        )
                    }

                    function<String, String>(
                        "__vueoBase64Decode"
                    ) { value ->
                        String(
                            Base64.decode(
                                value,
                                Base64.DEFAULT,
                            ),
                            Charsets.UTF_8,
                        )
                    }

                    function<String, String>(
                        "__vueoBinaryToBase64"
                    ) { value ->
                        val bytes =
                            ByteArray(value.length) { index ->
                                (
                                    value[index].code and 0xFF
                                ).toByte()
                            }

                        Base64.encodeToString(
                            bytes,
                            Base64.NO_WRAP,
                        )
                    }

                    function<String, String>(
                        "__vueoBase64ToBinary"
                    ) { value ->
                        val bytes =
                            Base64.decode(
                                value,
                                Base64.DEFAULT,
                            )

                        buildString(
                            bytes.size
                        ) {
                            bytes.forEach { byte ->
                                append(
                                    (
                                        byte.toInt() and 0xFF
                                    ).toChar()
                                )
                            }
                        }
                    }

                    asyncFunction<Double, Boolean>(
                        "__vueoDelay"
                    ) { millis ->
                        delay(
                            millis
                                .toLong()
                                .coerceIn(
                                    0L,
                                    30_000L,
                                )
                        )
                        true
                    }

                    evaluate<String>(
                        buildRuntimeScript(
                            providerScript =
                                source,
                            tmdbId =
                                tmdbId,
                            mediaType =
                                mediaType,
                            season =
                                season,
                            episode =
                                episode,
                        ),
                        filename =
                            "${provider.id}.js",
                    )
                }

            ProviderExecution(
                streams =
                    parseProviderStreams(
                        repository =
                            repository,
                        provider =
                            provider,
                        resultJson =
                            resultJson,
                    ),
                error =
                    null,
                logs =
                    logs.toList(),
            )
        } catch (error: CancellationException) {
            throw error
        } catch (error: Throwable) {
            ProviderExecution(
                streams =
                    emptyList(),
                error =
                    buildString {
                        append(
                            error.message
                                ?: error::class
                                    .java
                                    .simpleName
                        )
                    },
                errorType = error::class.java.simpleName,
                logs =
                    logs.toList(),
            )
        }
    }

    private fun buildRuntimeScript(
        providerScript: String,
        tmdbId: String,
        mediaType: String,
        season: Int?,
        episode: Int?,
    ): String {
        val safeTmdbId =
            JSONObject.quote(
                tmdbId
            )

        val safeMediaType =
            JSONObject.quote(
                mediaType
            )

        val seasonValue =
            season?.toString()
                ?: "null"

        val episodeValue =
            episode?.toString()
                ?: "null"

        return """
            globalThis.window = globalThis;
            globalThis.global = globalThis;
            globalThis.self = globalThis;
            globalThis.process = globalThis.process || { env: {} };
            globalThis.SCRAPER_SETTINGS =
              globalThis.SCRAPER_SETTINGS || {};
            globalThis.VUEO_DISCOVERY_CONTEXT = {
              version: 3,
              tmdbId: ${safeTmdbId},
              mediaType: ${safeMediaType},
              season: ${seasonValue},
              episode: ${episodeValue},
              title: "",
              originalTitle: "",
              year: "",
              imdbId: "",
              externalId: "",
              originalLanguage: "",
              aliases: []
            };

            globalThis.vueoDiscoveryContext =
              async function (tmdbUrl) {
                var raw = await __vueoDiscoveryContext(
                  JSON.stringify({
                    url: String(tmdbUrl || "")
                  })
                );
                var context = JSON.parse(raw);
                if (context && context.error) {
                  throw new Error(context.error);
                }
                if (context && typeof context === "object") {
                  globalThis.VUEO_DISCOVERY_CONTEXT = context;
                }
                return context;
              };

            globalThis.vueoTrace =
              function (stage, details) {
                try {
                  __vueoTrace(
                    JSON.stringify({
                      stage: String(stage || "PROVIDER"),
                      details:
                        details == null
                          ? ""
                          : details
                    })
                  );
                } catch (_) {}
              };

            function __vueoString(value) {
              try {
                if (typeof value === "string") return value;
                return JSON.stringify(value);
              } catch (_) {
                return String(value);
              }
            }

            function __vueoHeaders(raw) {
              var normalized = {};
              if (raw && typeof raw === "object") {
                Object.keys(raw).forEach(function (key) {
                  normalized[String(key)] = String(raw[key]);
                });
              }
              return normalized;
            }

            globalThis.webviewResolve = async function (input, options) {
              options = options || {};

              var request = {};
              if (input && typeof input === "object") {
                Object.keys(input).forEach(function (key) {
                  request[key] = input[key];
                });
              } else {
                request.url = String(input || "");
              }

              Object.keys(options).forEach(function (key) {
                request[key] = options[key];
              });

              var raw = await __vueoWebViewResolve(
                JSON.stringify(request)
              );
              var result = JSON.parse(raw);

              if (result.error) {
                throw new Error(result.error);
              }

              return result;
            };

            globalThis.webViewResolve =
              globalThis.webviewResolve;

            globalThis.fetch = async function (input, init) {
              init = init || {};

              var request = {
                url: String(input && input.url ? input.url : input),
                method: String(init.method || "GET").toUpperCase(),
                headers: __vueoHeaders(init.headers),
                body: init.body == null ? null : String(init.body),
                contentType:
                  init.headers &&
                  (init.headers["Content-Type"] || init.headers["content-type"])
                    ? String(
                        init.headers["Content-Type"] ||
                        init.headers["content-type"]
                      )
                    : null,
                redirect:
                  init.redirect == null
                    ? "follow"
                    : String(init.redirect)
              };

              var raw = await __vueoNativeFetch(
                JSON.stringify(request)
              );

              var response = JSON.parse(raw);

              if (response.error) {
                throw new Error(response.error);
              }

              var responseHeaders = response.headers || {};
              var bodyText = response.body || "";

              return {
                ok:
                  response.status >= 200 &&
                  response.status < 300,
                status: response.status || 0,
                statusText: response.statusText || "",
                url: response.url || request.url,
                headers: {
                  get: function (name) {
                    if (!name) return null;
                    var lower = String(name).toLowerCase();
                    var keys = Object.keys(responseHeaders);
                    for (var i = 0; i < keys.length; i++) {
                      if (keys[i].toLowerCase() === lower) {
                        return String(responseHeaders[keys[i]]);
                      }
                    }
                    return null;
                  },
                  has: function (name) {
                    return this.get(name) !== null;
                  }
                },
                text: async function () {
                  return bodyText;
                },
                json: async function () {
                  return JSON.parse(bodyText || "null");
                },
                clone: function () {
                  return this;
                }
              };
            };

            function __vueoAxiosRequest(config) {
              config = config || {};

              return fetch(config.url, {
                method: config.method || "GET",
                headers: config.headers || {},
                body:
                  config.data == null
                    ? null
                    : (
                        typeof config.data === "string"
                          ? config.data
                          : JSON.stringify(config.data)
                      )
              }).then(async function (response) {
                var text = await response.text();
                var data = text;

                try {
                  data = JSON.parse(text);
                } catch (_) {}

                if (!response.ok) {
                  var error =
                    new Error(
                      "Request failed with status " +
                      response.status
                    );

                  error.response = {
                    data: data,
                    status: response.status,
                    statusText: response.statusText,
                    headers: response.headers,
                    config: config
                  };

                  throw error;
                }

                return {
                  data: data,
                  status: response.status,
                  statusText: response.statusText,
                  headers: response.headers,
                  config: config
                };
              });
            }

            var __vueoAxiosModule = function (config) {
              return __vueoAxiosRequest(config);
            };

            __vueoAxiosModule.request = __vueoAxiosRequest;

            __vueoAxiosModule.get = function (url, config) {
              config = config || {};
              config.url = url;
              config.method = "GET";
              return __vueoAxiosRequest(config);
            };

            __vueoAxiosModule.post = function (url, data, config) {
              config = config || {};
              config.url = url;
              config.method = "POST";
              config.data = data;
              return __vueoAxiosRequest(config);
            };

            globalThis.axios = __vueoAxiosModule;

            globalThis.btoa = function (value) {
              return __vueoBinaryToBase64(
                String(value)
              );
            };

            globalThis.atob = function (value) {
              return __vueoBase64ToBinary(
                String(value)
              );
            };

            globalThis.Buffer = globalThis.Buffer || {
              from: function (value) {
                var text = String(value);

                return {
                  toString: function (encoding) {
                    if (encoding === "base64") {
                      return __vueoBase64(text);
                    }
                    return text;
                  }
                };
              }
            };

            globalThis.setTimeout = function (callback, millis) {
              return __vueoDelay(Number(millis || 0))
                .then(function () {
                  return callback();
                });
            };

            globalThis.clearTimeout = function () {};

            function __vueoNativeUrl(input, base) {
                          var raw = __vueoUrlOp(
                            JSON.stringify({
                              input: String(input),
                              base:
                                base == null
                                  ? ""
                                  : String(
                                      base.href ||
                                      base
                                    )
                            })
                          );

                          var parsed = JSON.parse(raw);

                          if (parsed.error) {
                            throw new TypeError(parsed.error);
                          }

                          return parsed;
                        }

                        globalThis.URLSearchParams =
                          function (initial) {
                            this._pairs = [];

                            if (
                              initial &&
                              initial._pairs &&
                              Array.isArray(initial._pairs)
                            ) {
                              this._pairs =
                                initial._pairs.map(
                                  function (pair) {
                                    return [
                                      String(pair[0]),
                                      String(pair[1])
                                    ];
                                  }
                                );
                              return;
                            }

                            if (Array.isArray(initial)) {
                              for (
                                var ai = 0;
                                ai < initial.length;
                                ai++
                              ) {
                                if (
                                  initial[ai] &&
                                  initial[ai].length >= 2
                                ) {
                                  this.append(
                                    initial[ai][0],
                                    initial[ai][1]
                                  );
                                }
                              }
                              return;
                            }

                            if (typeof initial === "string") {
                              var source =
                                initial.charAt(0) === "?"
                                  ? initial.slice(1)
                                  : initial;

                              if (source) {
                                var parts = source.split("&");

                                for (
                                  var i = 0;
                                  i < parts.length;
                                  i++
                                ) {
                                  if (!parts[i]) continue;

                                  var eq =
                                    parts[i].indexOf("=");

                                  var rawKey =
                                    eq >= 0
                                      ? parts[i].slice(0, eq)
                                      : parts[i];

                                  var rawValue =
                                    eq >= 0
                                      ? parts[i].slice(eq + 1)
                                      : "";

                                  this.append(
                                    decodeURIComponent(
                                      rawKey.replace(/\+/g, " ")
                                    ),
                                    decodeURIComponent(
                                      rawValue.replace(/\+/g, " ")
                                    )
                                  );
                                }
                              }
                              return;
                            }

                            if (
                              initial &&
                              typeof initial === "object"
                            ) {
                              var keys =
                                Object.keys(initial);

                              for (
                                var j = 0;
                                j < keys.length;
                                j++
                              ) {
                                this.append(
                                  keys[j],
                                  initial[keys[j]]
                                );
                              }
                            }
                          };

                        URLSearchParams.prototype.append =
                          function (key, value) {
                            this._pairs.push([
                              String(key),
                              String(value)
                            ]);
                          };

                        URLSearchParams.prototype.set =
                          function (key, value) {
                            this.delete(key);
                            this.append(key, value);
                          };

                        URLSearchParams.prototype.get =
                          function (key) {
                            key = String(key);

                            for (
                              var i = 0;
                              i < this._pairs.length;
                              i++
                            ) {
                              if (
                                this._pairs[i][0] === key
                              ) {
                                return this._pairs[i][1];
                              }
                            }

                            return null;
                          };

                        URLSearchParams.prototype.getAll =
                          function (key) {
                            key = String(key);

                            return this._pairs
                              .filter(function (pair) {
                                return pair[0] === key;
                              })
                              .map(function (pair) {
                                return pair[1];
                              });
                          };

                        URLSearchParams.prototype.has =
                          function (key) {
                            return this.get(key) !== null;
                          };

                        URLSearchParams.prototype.delete =
                          function (key) {
                            key = String(key);

                            this._pairs =
                              this._pairs.filter(
                                function (pair) {
                                  return pair[0] !== key;
                                }
                              );
                          };

                        URLSearchParams.prototype.keys =
                          function () {
                            return this._pairs
                              .map(function (pair) {
                                return pair[0];
                              })
                              [Symbol.iterator]();
                          };

                        URLSearchParams.prototype.values =
                          function () {
                            return this._pairs
                              .map(function (pair) {
                                return pair[1];
                              })
                              [Symbol.iterator]();
                          };

                        URLSearchParams.prototype.entries =
                          function () {
                            return this._pairs
                              .map(function (pair) {
                                return [
                                  pair[0],
                                  pair[1]
                                ];
                              })
                              [Symbol.iterator]();
                          };

                        URLSearchParams.prototype.forEach =
                          function (callback, thisArg) {
                            for (
                              var i = 0;
                              i < this._pairs.length;
                              i++
                            ) {
                              callback.call(
                                thisArg,
                                this._pairs[i][1],
                                this._pairs[i][0],
                                this
                              );
                            }
                          };

                        URLSearchParams.prototype.toString =
                          function () {
                            return this._pairs
                              .map(function (pair) {
                                return (
                                  encodeURIComponent(pair[0])
                                    .replace(/%20/g, "+") +
                                  "=" +
                                  encodeURIComponent(pair[1])
                                    .replace(/%20/g, "+")
                                );
                              })
                              .join("&");
                          };

                        if (
                          typeof Symbol !== "undefined" &&
                          Symbol.iterator
                        ) {
                          URLSearchParams.prototype[
                            Symbol.iterator
                          ] =
                            URLSearchParams.prototype.entries;
                        }

                        globalThis.URL =
                          function (input, base) {
                            var parsed =
                              __vueoNativeUrl(
                                input,
                                base
                              );

                            this.href = parsed.href;
                            this.origin = parsed.origin;
                            this.protocol = parsed.protocol;
                            this.hostname = parsed.hostname;
                            this.host = parsed.host;
                            this.port = parsed.port;
                            this.pathname = parsed.pathname;
                            this.search = parsed.search;
                            this.hash = parsed.hash;
                            this.searchParams =
                              new URLSearchParams(
                                parsed.queryPairs || []
                              );
                          };

                        URL.prototype.toString =
                          function () {
                            return this.href;
                          };

                        URL.prototype.toJSON =
                          function () {
                            return this.href;
                          };

                        globalThis.AbortSignal =
                          globalThis.AbortSignal ||
                          {
                            timeout: function (millis) {
                              return {
                                __vueoTimeoutMs:
                                  Number(millis || 0),
                                aborted: false
                              };
                            }
                          };

                        function __vueoUtf8Bytes(value) {
                          var text = String(value);
                          var encoded =
                            unescape(
                              encodeURIComponent(text)
                            );

                          var bytes = [];

                          for (
                            var i = 0;
                            i < encoded.length;
                            i++
                          ) {
                            bytes.push(
                              encoded.charCodeAt(i) & 255
                            );
                          }

                          return bytes;
                        }

                        function __vueoUtf8String(bytes) {
                          var binary = "";

                          for (
                            var i = 0;
                            i < bytes.length;
                            i++
                          ) {
                            binary +=
                              String.fromCharCode(
                                bytes[i] & 255
                              );
                          }

                          try {
                            return decodeURIComponent(
                              escape(binary)
                            );
                          } catch (_) {
                            return binary;
                          }
                        }

                        globalThis.TextEncoder =
                          globalThis.TextEncoder ||
                          function () {};

                        TextEncoder.prototype.encode =
                          function (value) {
                            return new Uint8Array(
                              __vueoUtf8Bytes(value)
                            );
                          };

                        globalThis.TextDecoder =
                          globalThis.TextDecoder ||
                          function () {};

                        TextDecoder.prototype.decode =
                          function (value) {
                            if (value == null) {
                              return "";
                            }

                            return __vueoUtf8String(
                              Array.prototype.slice.call(
                                value
                              )
                            );
                          };

                        function __vueoB64ToBytes(value) {
                          var binary =
                            atob(String(value));

                          var bytes = [];

                          for (
                            var i = 0;
                            i < binary.length;
                            i++
                          ) {
                            bytes.push(
                              binary.charCodeAt(i) & 255
                            );
                          }

                          return bytes;
                        }

                        function __vueoBytesToB64(bytes) {
                          var binary = "";

                          for (
                            var i = 0;
                            i < bytes.length;
                            i++
                          ) {
                            binary +=
                              String.fromCharCode(
                                bytes[i] & 255
                              );
                          }

                          return btoa(binary);
                        }

                        function __vueoWordsToBytes(
                          words,
                          sigBytes
                        ) {
                          words = words || [];

                          var count =
                            sigBytes == null
                              ? words.length * 4
                              : Number(sigBytes);

                          var bytes = [];

                          for (
                            var i = 0;
                            i < count;
                            i++
                          ) {
                            bytes.push(
                              (
                                words[i >>> 2] >>>
                                (
                                  24 -
                                  (i % 4) * 8
                                )
                              ) & 255
                            );
                          }

                          return bytes;
                        }

                        function __vueoBytesToWords(bytes) {
                          var words = [];

                          for (
                            var i = 0;
                            i < bytes.length;
                            i++
                          ) {
                            words[i >>> 2] =
                              (
                                words[i >>> 2] || 0
                              ) |
                              (
                                (bytes[i] & 255) <<
                                (
                                  24 -
                                  (i % 4) * 8
                                )
                              );
                          }

                          return words;
                        }

                        function VueoWordArray(
                          bytes
                        ) {
                          this._bytes =
                            (bytes || []).slice();

                          this.sigBytes =
                            this._bytes.length;

                          this.words =
                            __vueoBytesToWords(
                              this._bytes
                            );
                        }

                        VueoWordArray.prototype.concat =
                          function (other) {
                            var incoming =
                              __vueoAsWordArray(
                                other
                              );

                            this._bytes =
                              this._bytes.concat(
                                incoming._bytes
                              );

                            this.sigBytes =
                              this._bytes.length;

                            this.words =
                              __vueoBytesToWords(
                                this._bytes
                              );

                            return this;
                          };

                        VueoWordArray.prototype.clamp =
                          function () {
                            return this;
                          };

                        VueoWordArray.prototype.clone =
                          function () {
                            return new VueoWordArray(
                              this._bytes
                            );
                          };

                        VueoWordArray.prototype.toString =
                          function (encoder) {
                            return (
                              encoder ||
                              __vueoCryptoJsModule.enc.Hex
                            ).stringify(this);
                          };

                        function __vueoAsWordArray(
                          value
                        ) {
                          if (
                            value instanceof
                            VueoWordArray
                          ) {
                            return value;
                          }

                          if (
                            value &&
                            Array.isArray(value._bytes)
                          ) {
                            return new VueoWordArray(
                              value._bytes
                            );
                          }

                          if (
                            value &&
                            Array.isArray(value.words)
                          ) {
                            return new VueoWordArray(
                              __vueoWordsToBytes(
                                value.words,
                                value.sigBytes
                              )
                            );
                          }

                          if (
                            value instanceof Uint8Array
                          ) {
                            return new VueoWordArray(
                              Array.prototype.slice.call(
                                value
                              )
                            );
                          }

                          if (
                            value instanceof ArrayBuffer
                          ) {
                            return new VueoWordArray(
                              Array.prototype.slice.call(
                                new Uint8Array(value)
                              )
                            );
                          }

                          return new VueoWordArray(
                            __vueoUtf8Bytes(
                              String(value)
                            )
                          );
                        }

                        function __vueoCryptoNative(
                          request
                        ) {
                          var raw =
                            __vueoCryptoOp(
                              JSON.stringify(request)
                            );

                          var parsed =
                            JSON.parse(raw);

                          if (parsed.error) {
                            throw new Error(
                              parsed.error
                            );
                          }

                          return parsed;
                        }

                        globalThis.__crypto_aes_decrypt_raw =
                          function (
                            mode,
                            keyArg,
                            ivArg,
                            dataArg
                          ) {
                            function bytesOf(value) {
                              if (!value) {
                                return [];
                              }

                              return Array.prototype
                                .slice.call(value)
                                .map(
                                  function (byte) {
                                    return (
                                      Number(byte) & 255
                                    );
                                  }
                                );
                            }

                            var result =
                              __vueoCryptoNative({
                                op: "decrypt",
                                algorithm: "AES",
                                data:
                                  __vueoBytesToB64(
                                    bytesOf(dataArg)
                                  ),
                                key:
                                  __vueoBytesToB64(
                                    bytesOf(keyArg)
                                  ),
                                iv:
                                  __vueoBytesToB64(
                                    bytesOf(ivArg)
                                  )
                              });

                            return new Uint8Array(
                              __vueoB64ToBytes(
                                result.data
                              )
                            );
                          };

                        function __vueoCryptoHash(
                          algorithm,
                          input
                        ) {
                          var wordArray =
                            __vueoAsWordArray(
                              input
                            );

                          var result =
                            __vueoCryptoNative({
                              op: "hash",
                              algorithm: algorithm,
                              data:
                                __vueoBytesToB64(
                                  wordArray._bytes
                                )
                            });

                          return new VueoWordArray(
                            __vueoB64ToBytes(
                              result.data
                            )
                          );
                        }

                        function __vueoCryptoHmac(
                          algorithm,
                          data,
                          key
                        ) {
                          var dataWa =
                            __vueoAsWordArray(
                              data
                            );

                          var keyWa =
                            __vueoAsWordArray(
                              key
                            );

                          var result =
                            __vueoCryptoNative({
                              op: "hmac",
                              algorithm: algorithm,
                              data:
                                __vueoBytesToB64(
                                  dataWa._bytes
                                ),
                              key:
                                __vueoBytesToB64(
                                  keyWa._bytes
                                )
                            });

                          return new VueoWordArray(
                            __vueoB64ToBytes(
                              result.data
                            )
                          );
                        }

                        function __vueoCipherData(
                          cipher
                        ) {
                          if (
                            typeof cipher === "string"
                          ) {
                            return cipher;
                          }

                          if (
                            cipher &&
                            cipher.ciphertext
                          ) {
                            return __vueoBytesToB64(
                              __vueoAsWordArray(
                                cipher.ciphertext
                              )._bytes
                            );
                          }

                          return __vueoBytesToB64(
                            __vueoAsWordArray(
                              cipher
                            )._bytes
                          );
                        }

                        function __vueoDecrypt(
                          algorithm,
                          cipher,
                          key,
                          options
                        ) {
                          options =
                            options || {};

                          var keyWa =
                            __vueoAsWordArray(
                              key
                            );

                          var ivWa =
                            options.iv
                              ? __vueoAsWordArray(
                                  options.iv
                                )
                              : new VueoWordArray([]);

                          var result =
                            __vueoCryptoNative({
                              op: "decrypt",
                              algorithm: algorithm,
                              data:
                                __vueoCipherData(
                                  cipher
                                ),
                              key:
                                __vueoBytesToB64(
                                  keyWa._bytes
                                ),
                              iv:
                                __vueoBytesToB64(
                                  ivWa._bytes
                                )
                            });

                          return new VueoWordArray(
                            __vueoB64ToBytes(
                              result.data
                            )
                          );
                        }

                        function __vueoEncrypt(
                          algorithm,
                          plaintext,
                          key,
                          options
                        ) {
                          options =
                            options || {};

                          var dataWa =
                            __vueoAsWordArray(
                              plaintext
                            );

                          var keyWa =
                            __vueoAsWordArray(
                              key
                            );

                          var ivWa =
                            options.iv
                              ? __vueoAsWordArray(
                                  options.iv
                                )
                              : new VueoWordArray([]);

                          var result =
                            __vueoCryptoNative({
                              op: "encrypt",
                              algorithm: algorithm,
                              data:
                                __vueoBytesToB64(
                                  dataWa._bytes
                                ),
                              key:
                                __vueoBytesToB64(
                                  keyWa._bytes
                                ),
                              iv:
                                __vueoBytesToB64(
                                  ivWa._bytes
                                )
                            });

                          var ciphertext =
                            new VueoWordArray(
                              __vueoB64ToBytes(
                                result.data
                              )
                            );

                          return {
                            ciphertext: ciphertext,
                            toString: function () {
                              return __vueoCryptoJsModule.enc.Base64
                                .stringify(
                                  ciphertext
                                );
                            }
                          };
                        }

                        var __vueoCryptoJsModule = {
                          lib: {
                            WordArray: {
                              create:
                                function (
                                  words,
                                  sigBytes
                                ) {
                                  if (
                                    words instanceof
                                    VueoWordArray
                                  ) {
                                    return words.clone();
                                  }

                                  if (
                                    words instanceof
                                    Uint8Array
                                  ) {
                                    return new VueoWordArray(
                                      Array.prototype
                                        .slice.call(
                                          words
                                        )
                                    );
                                  }

                                  return new VueoWordArray(
                                    __vueoWordsToBytes(
                                      words || [],
                                      sigBytes
                                    )
                                  );
                                },

                              random:
                                function (count) {
                                  var result =
                                    __vueoCryptoNative({
                                      op: "random",
                                      count:
                                        Number(count || 0)
                                    });

                                  return new VueoWordArray(
                                    __vueoB64ToBytes(
                                      result.data
                                    )
                                  );
                                }
                            },

                            CipherParams: {
                              create:
                                function (value) {
                                  return value || {};
                                }
                            }
                          },

                          enc: {
                            Utf8: {
                              parse:
                                function (value) {
                                  return new VueoWordArray(
                                    __vueoUtf8Bytes(
                                      value
                                    )
                                  );
                                },

                              stringify:
                                function (wordArray) {
                                  return __vueoUtf8String(
                                    __vueoAsWordArray(
                                      wordArray
                                    )._bytes
                                  );
                                }
                            },

                            Base64: {
                              parse:
                                function (value) {
                                  return new VueoWordArray(
                                    __vueoB64ToBytes(
                                      value
                                    )
                                  );
                                },

                              stringify:
                                function (wordArray) {
                                  return __vueoBytesToB64(
                                    __vueoAsWordArray(
                                      wordArray
                                    )._bytes
                                  );
                                }
                            },

                            Hex: {
                              parse:
                                function (value) {
                                  value =
                                    String(value)
                                      .replace(
                                        /[^0-9a-f]/gi,
                                        ""
                                      );

                                  var bytes = [];

                                  for (
                                    var i = 0;
                                    i < value.length;
                                    i += 2
                                  ) {
                                    bytes.push(
                                      parseInt(
                                        value.slice(
                                          i,
                                          i + 2
                                        ),
                                        16
                                      )
                                    );
                                  }

                                  return new VueoWordArray(
                                    bytes
                                  );
                                },

                              stringify:
                                function (wordArray) {
                                  return __vueoAsWordArray(
                                    wordArray
                                  )._bytes
                                    .map(
                                      function (byte) {
                                        return (
                                          "0" +
                                          (
                                            byte & 255
                                          ).toString(16)
                                        ).slice(-2);
                                      }
                                    )
                                    .join("");
                                }
                            },

                            Latin1: {
                              parse:
                                function (value) {
                                  var bytes = [];

                                  value =
                                    String(value);

                                  for (
                                    var i = 0;
                                    i < value.length;
                                    i++
                                  ) {
                                    bytes.push(
                                      value.charCodeAt(i)
                                        & 255
                                    );
                                  }

                                  return new VueoWordArray(
                                    bytes
                                  );
                                },

                              stringify:
                                function (wordArray) {
                                  return __vueoAsWordArray(
                                    wordArray
                                  )._bytes
                                    .map(
                                      function (byte) {
                                        return String
                                          .fromCharCode(
                                            byte & 255
                                          );
                                      }
                                    )
                                    .join("");
                                }
                            }
                          },

                          mode: {
                            CBC: "CBC"
                          },

                          pad: {
                            Pkcs7: "Pkcs7"
                          },

                          MD5:
                            function (value) {
                              return __vueoCryptoHash(
                                "MD5",
                                value
                              );
                            },

                          SHA1:
                            function (value) {
                              return __vueoCryptoHash(
                                "SHA1",
                                value
                              );
                            },

                          SHA256:
                            function (value) {
                              return __vueoCryptoHash(
                                "SHA256",
                                value
                              );
                            },

                          SHA384:
                            function (value) {
                              return __vueoCryptoHash(
                                "SHA384",
                                value
                              );
                            },

                          SHA512:
                            function (value) {
                              return __vueoCryptoHash(
                                "SHA512",
                                value
                              );
                            },

                          HmacMD5:
                            function (data, key) {
                              return __vueoCryptoHmac(
                                "MD5",
                                data,
                                key
                              );
                            },

                          HmacSHA1:
                            function (data, key) {
                              return __vueoCryptoHmac(
                                "SHA1",
                                data,
                                key
                              );
                            },

                          HmacSHA256:
                            function (data, key) {
                              return __vueoCryptoHmac(
                                "SHA256",
                                data,
                                key
                              );
                            },

                          HmacSHA512:
                            function (data, key) {
                              return __vueoCryptoHmac(
                                "SHA512",
                                data,
                                key
                              );
                            },

                          AES: {
                            decrypt:
                              function (
                                cipher,
                                key,
                                options
                              ) {
                                return __vueoDecrypt(
                                  "AES",
                                  cipher,
                                  key,
                                  options
                                );
                              },

                            encrypt:
                              function (
                                plaintext,
                                key,
                                options
                              ) {
                                return __vueoEncrypt(
                                  "AES",
                                  plaintext,
                                  key,
                                  options
                                );
                              }
                          },

                          TripleDES: {
                            decrypt:
                              function (
                                cipher,
                                key,
                                options
                              ) {
                                return __vueoDecrypt(
                                  "TripleDES",
                                  cipher,
                                  key,
                                  options
                                );
                              },

                            encrypt:
                              function (
                                plaintext,
                                key,
                                options
                              ) {
                                return __vueoEncrypt(
                                  "TripleDES",
                                  plaintext,
                                  key,
                                  options
                                );
                              }
                          }
                        };

                        function __vueoHtmlNative(
                          request
                        ) {
                          var raw =
                            __vueoHtmlOp(
                              JSON.stringify(request)
                            );

                          var parsed =
                            JSON.parse(raw);

                          if (parsed.error) {
                            throw new Error(
                              parsed.error
                            );
                          }

                          return parsed;
                        }

                        function __vueoCheerioLoad(
                          html,
                          options,
                          isDocument
                        ) {
                          var parsed =
                            __vueoHtmlNative({
                              op: "parse",
                              html:
                                html == null
                                  ? ""
                                  : String(html),
                              baseUri:
                                options &&
                                options.baseURI
                                  ? String(
                                      options.baseURI
                                    )
                                  : ""
                            });

                          var documentId =
                            parsed.documentId;

                          function Selection(ids) {
                            this._ids =
                              (ids || []).slice();

                            this.length =
                              this._ids.length;

                            for (
                              var i = 0;
                              i < this._ids.length;
                              i++
                            ) {
                              this[i] = {
                                __vueoNodeId:
                                  this._ids[i],
                                __vueoDocumentId:
                                  documentId
                              };
                            }
                          }

                          function idsFromResponse(
                            response
                          ) {
                            return (
                              response.ids ||
                              []
                            );
                          }

                          function opIds(
                            op,
                            ids,
                            extra
                          ) {
                            var request = {
                              op: op,
                              documentId:
                                documentId,
                              ids:
                                ids || []
                            };

                            if (extra) {
                              Object.keys(extra)
                                .forEach(
                                  function (key) {
                                    request[key] =
                                      extra[key];
                                  }
                                );
                            }

                            return idsFromResponse(
                              __vueoHtmlNative(
                                request
                              )
                            );
                          }

                          Selection.prototype.eq =
                            function (index) {
                              index = Number(index);

                              if (index < 0) {
                                index =
                                  this._ids.length +
                                  index;
                              }

                              if (
                                index < 0 ||
                                index >=
                                this._ids.length
                              ) {
                                return new Selection([]);
                              }

                              return new Selection([
                                this._ids[index]
                              ]);
                            };

                          Selection.prototype.first =
                            function () {
                              return this.eq(0);
                            };

                          Selection.prototype.last =
                            function () {
                              return this.eq(-1);
                            };

                          Selection.prototype.get =
                            function (index) {
                              if (
                                index == null
                              ) {
                                return this.toArray();
                              }

                              var selected =
                                this.eq(index);

                              return selected.length
                                ? selected[0]
                                : undefined;
                            };

                          Selection.prototype.toArray =
                            function () {
                              var result = [];

                              for (
                                var i = 0;
                                i < this._ids.length;
                                i++
                              ) {
                                result.push({
                                  __vueoNodeId:
                                    this._ids[i],
                                  __vueoDocumentId:
                                    documentId
                                });
                              }

                              return result;
                            };

                          Selection.prototype.each =
                            function (callback) {
                              for (
                                var i = 0;
                                i < this._ids.length;
                                i++
                              ) {
                                callback.call(
                                  this[i],
                                  i,
                                  this[i]
                                );
                              }

                              return this;
                            };

                          Selection.prototype.map =
                            function (callback) {
                              var values = [];

                              for (
                                var i = 0;
                                i < this._ids.length;
                                i++
                              ) {
                                values.push(
                                  callback.call(
                                    this[i],
                                    i,
                                    this[i]
                                  )
                                );
                              }

                              return {
                                get:
                                  function (index) {
                                    if (
                                      index == null
                                    ) {
                                      return values;
                                    }
                                    return values[index];
                                  },

                                toArray:
                                  function () {
                                    return values.slice();
                                  }
                              };
                            };

                          Selection.prototype.filter =
                            function (selector) {
                              if (
                                typeof selector ===
                                "function"
                              ) {
                                var kept = [];

                                for (
                                  var i = 0;
                                  i < this._ids.length;
                                  i++
                                ) {
                                  if (
                                    selector.call(
                                      this[i],
                                      i,
                                      this[i]
                                    )
                                  ) {
                                    kept.push(
                                      this._ids[i]
                                    );
                                  }
                                }

                                return new Selection(
                                  kept
                                );
                              }

                              return new Selection(
                                opIds(
                                  "filter",
                                  this._ids,
                                  {
                                    selector:
                                      String(selector)
                                  }
                                )
                              );
                            };

                          Selection.prototype.find =
                            function (selector) {
                              return new Selection(
                                opIds(
                                  "find",
                                  this._ids,
                                  {
                                    selector:
                                      String(selector)
                                  }
                                )
                              );
                            };

                          Selection.prototype.parent =
                            function () {
                              return new Selection(
                                opIds(
                                  "parent",
                                  this._ids
                                )
                              );
                            };

                          Selection.prototype.parents =
                            function (selector) {
                              return new Selection(
                                opIds(
                                  "parents",
                                  this._ids,
                                  {
                                    selector:
                                      selector == null
                                        ? ""
                                        : String(
                                            selector
                                          )
                                  }
                                )
                              );
                            };

                          Selection.prototype.children =
                            function (selector) {
                              return new Selection(
                                opIds(
                                  "children",
                                  this._ids,
                                  {
                                    selector:
                                      selector == null
                                        ? ""
                                        : String(
                                            selector
                                          )
                                  }
                                )
                              );
                            };

                          Selection.prototype.closest =
                            function (selector) {
                              return new Selection(
                                opIds(
                                  "closest",
                                  this._ids,
                                  {
                                    selector:
                                      String(selector)
                                  }
                                )
                              );
                            };

                          Selection.prototype.next =
                            function () {
                              return new Selection(
                                opIds(
                                  "next",
                                  this._ids
                                )
                              );
                            };

                          Selection.prototype.prev =
                            function () {
                              return new Selection(
                                opIds(
                                  "prev",
                                  this._ids
                                )
                              );
                            };

                          Selection.prototype.siblings =
                            function (selector) {
                              return new Selection(
                                opIds(
                                  "siblings",
                                  this._ids,
                                  {
                                    selector:
                                      selector == null
                                        ? ""
                                        : String(
                                            selector
                                          )
                                  }
                                )
                              );
                            };

                          Selection.prototype.text =
                            function () {
                              return __vueoHtmlNative({
                                op: "text",
                                ids: this._ids
                              }).value || "";
                            };

                          Selection.prototype.ownText =
                            function () {
                              return __vueoHtmlNative({
                                op: "ownText",
                                ids: this._ids
                              }).value || "";
                            };

                          Selection.prototype.html =
                            function () {
                              return __vueoHtmlNative({
                                op: "html",
                                ids: this._ids
                              }).value || "";
                            };

                          Selection.prototype.attr =
                            function (name) {
                              if (name == null) {
                                return undefined;
                              }

                              return __vueoHtmlNative({
                                op: "attr",
                                ids: this._ids,
                                name: String(name)
                              }).value || undefined;
                            };

                          Selection.prototype.data =
                            function (name) {
                              return this.attr(
                                "data-" +
                                String(name)
                                  .replace(
                                    /[A-Z]/g,
                                    function (letter) {
                                      return (
                                        "-" +
                                        letter.toLowerCase()
                                      );
                                    }
                                  )
                              );
                            };

                          Selection.prototype.val =
                            function () {
                              return this.attr("value");
                            };

                          Selection.prototype.is =
                            function (selector) {
                              return !!__vueoHtmlNative({
                                op: "is",
                                ids: this._ids,
                                selector:
                                  String(selector)
                              }).bool;
                            };

                          Selection.prototype.hasClass =
                            function (name) {
                              return !!__vueoHtmlNative({
                                op: "hasClass",
                                ids: this._ids,
                                name: String(name)
                              }).bool;
                            };

                          Selection.prototype.remove =
                            function () {
                              __vueoHtmlNative({
                                op: "remove",
                                ids: this._ids
                              });
                              return this;
                            };

                          function $(input) {
                            if (
                              input &&
                              input.__vueoNodeId
                            ) {
                              return new Selection([
                                input.__vueoNodeId
                              ]);
                            }

                            if (
                              input instanceof
                              Selection
                            ) {
                              return input;
                            }

                            var selector =
                              String(input == null
                                ? ""
                                : input);

                            if (!selector) {
                              return new Selection([]);
                            }

                            return new Selection(
                              idsFromResponse(
                                __vueoHtmlNative({
                                  op: "select",
                                  documentId:
                                    documentId,
                                  selector:
                                    selector
                                })
                              )
                            );
                          }

                          $.html =
                            function (selection) {
                              if (
                                selection &&
                                selection._ids
                              ) {
                                return __vueoHtmlNative({
                                  op: "outerHtml",
                                  ids:
                                    selection._ids
                                }).value || "";
                              }

                              return __vueoHtmlNative({
                                op: "html",
                                ids: [
                                  parsed.rootId
                                ]
                              }).value || "";
                            };

                          $.root =
                            function () {
                              return new Selection([
                                parsed.rootId
                              ]);
                            };

                          return $;
                        }

                        var __vueoCheerioModule = {
                          load:
                            function (
                              html,
                              options,
                              isDocument
                            ) {
                              return __vueoCheerioLoad(
                                html,
                                options,
                                isDocument
                              );
                            }
                        };

                        globalThis.require =
                          function (name) {
                            if (
                              name === "axios"
                            ) {
                              return __vueoAxiosModule;
                            }

                            if (
                              name ===
                              "cheerio-without-node-native"
                            ) {
                              return __vueoCheerioModule;
                            }

                            if (
                              name === "cheerio"
                            ) {
                              return __vueoCheerioModule;
                            }

                            if (
                              name === "crypto-js"
                            ) {
                              return __vueoCryptoJsModule;
                            }

                            throw new Error(
                              "Unsupported runtime require(): " +
                              name
                            );
                          };

            var module = { exports: {} };
            var exports = module.exports;

            ${providerScript}

            var __vueoGetStreams =
              module &&
              module.exports &&
              typeof module.exports.getStreams === "function"
                ? module.exports.getStreams
                : (
                    typeof globalThis.getStreams === "function"
                      ? globalThis.getStreams
                      : null
                  );

            if (!__vueoGetStreams) {
              throw new Error(
                "Provider does not export getStreams"
              );
            }

            var __vueoStreams =
              await Promise.resolve(
                __vueoGetStreams(
                  ${safeTmdbId},
                  ${safeMediaType},
                  ${seasonValue},
                  ${episodeValue}
                )
              );

            JSON.stringify(
              Array.isArray(__vueoStreams)
                ? __vueoStreams
                : []
            );
        """.trimIndent()
    }

    private fun summarizeHttpTrace(
        requestJson: String,
        responseJson: String,
        elapsedMs: Long,
        sharedTmdb: Boolean,
    ): String {
        val request =
            runCatching { JSONObject(requestJson) }
                .getOrNull()
        val response =
            runCatching { JSONObject(responseJson) }
                .getOrNull()

        val method =
            request?.optString("method", "GET")
                ?.uppercase()
                ?: "GET"
        val url =
            compactTraceUrl(
                request?.optString("url").orEmpty()
            )
        val status =
            response?.optInt("status", 0)
                ?: 0
        val error =
            response
                ?.optString("error")
                ?.takeIf { it.isNotBlank() }
        val bodyChars =
            response?.optString("body")?.length
                ?: 0
        val truncated =
            response?.optBoolean(
                "bodyTruncated",
                false,
            ) == true

        return buildString {
            append("request=")
            append(method)
            append(' ')
            append(url)
            append(" status=")
            append(status)
            append(" elapsed=")
            append(elapsedMs)
            append("ms bodyChars=")
            append(bodyChars)
            append(" truncated=")
            append(truncated)
            if (sharedTmdb) {
                append(" sharedTmdb=true")
            }
            if (error != null) {
                append(" error=")
                append(error.take(120))
            }
        }
    }

    private fun summarizeWebViewTrace(
        requestJson: String,
        responseJson: String,
        elapsedMs: Long,
    ): String {
        val request =
            runCatching { JSONObject(requestJson) }
                .getOrNull()
        val response =
            runCatching { JSONObject(responseJson) }
                .getOrNull()
        val url =
            compactTraceUrl(
                request?.optString("url").orEmpty()
            )
        val error =
            response
                ?.optString("error")
                ?.takeIf { it.isNotBlank() }

        return buildString {
            append("url=")
            append(url)
            append(" elapsed=")
            append(elapsedMs)
            append("ms")
            if (error != null) {
                append(" error=")
                append(error.take(120))
            } else {
                append(" result=ok")
            }
        }
    }

    private fun compactTraceUrl(raw: String): String {
        if (raw.isBlank()) return "<empty>"

        return runCatching {
            val uri = java.net.URI(raw)
            buildString {
                append(uri.scheme ?: "https")
                append("://")
                append(uri.host ?: "unknown")
                val path = uri.rawPath.orEmpty()
                if (path.isNotBlank()) {
                    append(path.take(180))
                }
            }
        }.getOrElse {
            raw.substringBefore('?')
                .substringBefore('#')
                .take(220)
        }
    }

    private data class ProviderExecution(
        val streams: List<SourceCandidate>,
        val error: String?,
        val errorType: String? = null,
        val logs: List<String>,
    )

    private data class ProviderRun(
        val streams: List<SourceCandidate>,
        val diagnostic: ProviderDiagnostic,
    )

    private fun providerRuntimeTimeoutMs(
        provider: PluginProviderDescriptor,
    ): Long =
        provider.runtimeTimeoutMs.coerceIn(
            MIN_PROVIDER_TIMEOUT_MS,
            MAX_PROVIDER_TIMEOUT_MS,
        )

    companion object {
        private const val MIN_PROVIDER_TIMEOUT_MS =
            3_000L

        private const val MAX_PROVIDER_TIMEOUT_MS =
            20_000L

        private const val DEFAULT_MEMORY_CLASS_MB =
            256

        private const val LOW_MEMORY_CLASS_MB =
            256

        private const val LOW_MEMORY_HEAP_LIMIT_MB =
            320

        private const val LOW_MEMORY_SCAN_BUDGET_MS =
            135_000L

        private const val DEFAULT_SCAN_BUDGET_MS =
            120_000L

        private const val SLOW_THRESHOLD_MS =
            3_000L

        private const val MAX_STORED_LOGS =
            24

        private const val MAX_HTTP_TRACE_ENTRIES =
            14

        private const val MAX_WEBVIEW_TRACE_ENTRIES =
            4

        private const val MAX_LOG_LENGTH =
            1000
    }
}


private fun classifyProviderFailure(
    error: String,
): ProviderHealthStatus {
    val normalized =
        error.lowercase()

    return when {
        "timed out" in normalized ||
            "timeout" in normalized ->
            ProviderHealthStatus.TIMEOUT

        "nxdomain" in normalized ||
            "unable to resolve host" in normalized ||
            "unknownhost" in normalized ||
            "no address associated" in normalized ->
            ProviderHealthStatus.UNAVAILABLE

        "no token available" in normalized ||
            "token required" in normalized ||
            "requires token" in normalized ||
            "missing token" in normalized ||
            "ui token" in normalized &&
            (
                "expired" in normalized ||
                "required" in normalized ||
                "missing" in normalized
            ) ->
            ProviderHealthStatus.NEEDS_SETUP

        "http 403" in normalized ||
            "status 403" in normalized ||
            "forbidden" in normalized ||
            "cloudflare" in normalized ||
            "captcha" in normalized ->
            ProviderHealthStatus.BLOCKED

        else ->
            ProviderHealthStatus.FAILED
    }
}

private fun parseProviderStreams(
    repository: PluginRepositoryDescriptor,
    provider: PluginProviderDescriptor,
    resultJson: String,
): List<SourceCandidate> {
    val array =
        runCatching {
            JSONArray(resultJson)
        }.getOrNull()
            ?: return emptyList()

    return (0 until array.length())
        .mapNotNull { index ->
            val item =
                array.optJSONObject(index)
                    ?: return@mapNotNull null

            val url =
                item.optString("url")
                    .takeIf {
                        it.startsWith(
                            "https://"
                        ) ||
                        it.startsWith(
                            "http://"
                        )
                    }
                    ?: return@mapNotNull null

            val headers =
                item.optJSONObject("headers")
                    .toStringMap()

            val quality =
                item.optString("quality")
                    .takeIf {
                        it.isNotBlank()
                    }

            val displayName =
                item.optString("title")
                    .takeIf {
                        it.isNotBlank()
                    }
                    ?: item.optString("name")
                        .takeIf {
                            it.isNotBlank()
                        }
                    ?: provider.name

            SourceCandidate(
                id =
                    "plugin:" +
                    repository.manifestUrl.hashCode() +
                    ":" + provider.id +
                    ":" + index,
                name =
                    displayName,
                url =
                    url,
                quality =
                    quality,
                codec =
                    item.optString("codec")
                        .takeIf { it.isNotBlank() },
                hdr =
                    item.optString("hdr")
                        .takeIf { it.isNotBlank() },
                audio =
                    item.optString("audio")
                        .takeIf { it.isNotBlank() },
                language =
                    listOf(
                        "language",
                        "lang",
                        "audioLanguage",
                        "audio_language",
                    ).firstNotNullOfOrNull { field ->
                        item.optString(field)
                            .trim()
                            .takeIf { it.isNotBlank() }
                    },
                headers =
                    headers,
                providerId =
                    "plugin:" +
                    repository.manifestUrl
                        .hashCode() +
                    ":" +
                    provider.id,
                providerName =
                    "${repository.name} / " +
                    provider.name,
            )
        }
}

private fun JSONObject?.toStringMap():
    Map<String, String> {

    if (this == null) {
        return emptyMap()
    }

    val result =
        linkedMapOf<String, String>()

    val iterator =
        keys()

    while (
        iterator.hasNext()
    ) {
        val key =
            iterator.next()

        result[key] =
            optString(key)
    }

    return result
}

/** Exposes JavaScript providers through the common shared source contract. */
class PluginSourceResolver(
    context: Context,
    store: PluginStore,
) : SourceResolver {
    private val engine = PluginSourceEngine(
        context = context.applicationContext,
        store = store,
    )

    override val id: String = "js-providers"
    override val name: String = "JavaScript Providers"

    override suspend fun resolve(request: SourceRequest): SourceResolveResult {
        val result = engine.discover(
            tmdbId = request.videoId,
            mediaType = request.mediaType,
            season = request.season,
            episode = request.episode,
            mediaTitle = request.title,
            mediaOriginalTitle = request.originalTitle,
            mediaAliases = request.aliases,
            mediaYear = request.releaseInfo,
            mediaExternalId = request.externalId ?: request.videoId,
            mediaOriginalLanguage = request.originalLanguage,
        )
        return SourceResolveResult(
            sources = result.streams,
            warnings =
                (
                    result.preflightErrors +
                        result.diagnostics
                            .mapNotNull { diagnostic ->
                                diagnostic.error?.let { error ->
                                    "${diagnostic.providerName}: $error"
                                }
                            }
                )
                    .distinct()
                    .take(8),
        )
    }
}
