package com.vueo.tv.search

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.vueo.tv.TvTopNav
import com.vueo.tv.data.TvMediaItem
import com.vueo.tv.ui.components.TvNetworkImage
import com.vueo.tv.ui.focus.tvVerticalFocus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SearchBlack = Color(0xFF050706)
private val SearchPanel = Color(0xFF101412)
private val SearchGreen = Color(0xFF84E100)
private val SearchYellow = Color(0xFFD6FF00)
private val SearchMuted = Color(0xFFAAB2AD)

private object TvSearchFocusMemory {
    var query: String = ""
    var mode: TvSearchMode = TvSearchMode.TITLE
    var type: TvSearchType = TvSearchType.ALL
    var resultIndex: Int = 0
}

@Composable
fun TvSearchScreen(
    repository: TvSearchRepository,
    focusRestoreToken: Int = 0,
    onNavigate: (String) -> Unit,
    onOpenMedia: (TvMediaItem) -> Unit,
) {
    val navRequesters =
        remember {
            listOf("Home", "Search", "Library", "Content Manager", "Luckez")
                .associateWith { FocusRequester() }
        }
    val inputRequester = remember { FocusRequester() }
    val titleModeRequester = remember { FocusRequester() }
    val actorModeRequester = remember { FocusRequester() }
    val allTypeRequester = remember { FocusRequester() }
    val movieTypeRequester = remember { FocusRequester() }
    val seriesTypeRequester = remember { FocusRequester() }
    val resultEntryRequester = remember { FocusRequester() }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    var query by remember { mutableStateOf(TvSearchFocusMemory.query) }
    var mode by remember { mutableStateOf(TvSearchFocusMemory.mode) }
    var type by remember { mutableStateOf(TvSearchFocusMemory.type) }
    var results by remember { mutableStateOf<List<TvSearchResult>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    var requestGeneration by remember { mutableStateOf(0L) }
    var focusedIndex by remember { mutableStateOf(TvSearchFocusMemory.resultIndex) }

    BackHandler {
        onNavigate("Home")
    }

    LaunchedEffect(focusRestoreToken) {
        if (focusRestoreToken == 0) {
            delay(120)
            runCatching { inputRequester.requestFocus() }
        }
    }

    LaunchedEffect(focusRestoreToken, results.size) {
        if (focusRestoreToken > 0 && results.isNotEmpty()) {
            delay(100)
            focusedIndex = TvSearchFocusMemory.resultIndex.coerceIn(0, results.lastIndex)
            gridState.scrollToItem((focusedIndex - 6).coerceAtLeast(0))
            runCatching { resultEntryRequester.requestFocus() }
        }
    }

    LaunchedEffect(query, mode, type) {
        TvSearchFocusMemory.query = query
        TvSearchFocusMemory.mode = mode
        TvSearchFocusMemory.type = type
        requestGeneration += 1L
        val generation = requestGeneration
        searchError = null

        if (query.isBlank()) {
            results = emptyList()
            searching = false
            return@LaunchedEffect
        }

        if (mode == TvSearchMode.ACTOR) {
            results = emptyList()
            searching = false
            return@LaunchedEffect
        }

        delay(250)
        if (generation != requestGeneration) return@LaunchedEffect

        val local = repository.searchLocal(query, type)
        results = local
        searching = true

        runCatching {
            repository.searchRemote(query, type)
        }
            .onSuccess { remote ->
                if (generation == requestGeneration) {
                    results = repository.merge(query, type, local, remote)
                    searchError = null
                }
            }
            .onFailure { failure ->
                if (generation == requestGeneration) {
                    searchError =
                        if (local.isEmpty()) {
                            failure.message ?: "Unable to search VUEO catalogs"
                        } else {
                            "Showing cached results"
                        }
                }
            }

        if (generation == requestGeneration) {
            searching = false
        }
    }

    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF09100B),
                            SearchBlack,
                            SearchBlack,
                        )
                    )
                ),
    ) {
        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(start = 58.dp, end = 58.dp, top = 92.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom,
            ) {
                Column {
                    Text(
                        text = "Search",
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Find movies and series across VUEO metadata catalogs.",
                        color = SearchMuted,
                        fontSize = 14.sp,
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TvSearchChip(
                        label = "Title",
                        selected = mode == TvSearchMode.TITLE,
                        requester = titleModeRequester,
                        upRequester = inputRequester,
                        downRequester = allTypeRequester,
                        onClick = { mode = TvSearchMode.TITLE },
                    )
                    TvSearchChip(
                        label = "Actor",
                        selected = mode == TvSearchMode.ACTOR,
                        requester = actorModeRequester,
                        upRequester = inputRequester,
                        downRequester = allTypeRequester,
                        onClick = { mode = TvSearchMode.ACTOR },
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier =
                    Modifier
                        .width(760.dp)
                        .focusRequester(inputRequester)
                        .tvVerticalFocus(
                            up = navRequesters.getValue("Search"),
                            down = titleModeRequester,
                        ),
                singleLine = true,
                placeholder = {
                    Text(
                        if (mode == TvSearchMode.ACTOR) {
                            "Search actor name..."
                        } else {
                            "Search movies, shows..."
                        }
                    )
                },
                trailingIcon = {
                    if (searching) {
                        CircularProgressIndicator(
                            modifier = Modifier.width(22.dp).height(22.dp),
                            strokeWidth = 2.dp,
                            color = SearchYellow,
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                shape = RoundedCornerShape(12.dp),
                colors =
                    OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = SearchYellow,
                        focusedBorderColor = SearchYellow,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.26f),
                        focusedContainerColor = SearchPanel.copy(alpha = 0.96f),
                        unfocusedContainerColor = SearchPanel.copy(alpha = 0.86f),
                        focusedPlaceholderColor = SearchMuted,
                        unfocusedPlaceholderColor = SearchMuted.copy(alpha = 0.74f),
                    ),
            )

            Spacer(Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TvSearchChip(
                    label = "All",
                    selected = type == TvSearchType.ALL,
                    requester = allTypeRequester,
                    upRequester = titleModeRequester,
                    downRequester = if (results.isNotEmpty()) resultEntryRequester else null,
                    onClick = { type = TvSearchType.ALL },
                )
                TvSearchChip(
                    label = "Movies",
                    selected = type == TvSearchType.MOVIE,
                    requester = movieTypeRequester,
                    upRequester = titleModeRequester,
                    downRequester = if (results.isNotEmpty()) resultEntryRequester else null,
                    onClick = { type = TvSearchType.MOVIE },
                )
                TvSearchChip(
                    label = "Series",
                    selected = type == TvSearchType.SERIES,
                    requester = seriesTypeRequester,
                    upRequester = titleModeRequester,
                    downRequester = if (results.isNotEmpty()) resultEntryRequester else null,
                    onClick = { type = TvSearchType.SERIES },
                )

                if (searchError != null) {
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = searchError.orEmpty(),
                        color = SearchMuted,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        when {
            mode == TvSearchMode.ACTOR && query.isNotBlank() -> {
                SearchMessage(
                    title = "Actor search unavailable",
                    body =
                        "The enabled TV metadata source does not expose a cast/person search catalog yet. " +
                            "Title search remains available.",
                )
            }

            query.isBlank() -> {
                SearchMessage(
                    title = "Search VUEO",
                    body = "Type a movie or series title using your TV keyboard.",
                )
            }

            results.isEmpty() && searching -> {
                SearchMessage(
                    title = "Searching…",
                    body = "Checking VUEO metadata catalogs.",
                )
            }

            results.isEmpty() -> {
                SearchMessage(
                    title = "No results",
                    body = "Try another title or change the Movie / Series filter.",
                )
            }

            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(6),
                    state = gridState,
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .padding(top = 282.dp),
                    contentPadding = PaddingValues(
                        start = 58.dp,
                        end = 58.dp,
                        top = 12.dp,
                        bottom = 48.dp,
                    ),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                ) {
                    itemsIndexed(
                        items = results,
                        key = { _, result ->
                            "${result.media.type}:${result.media.id}:${result.providerName}"
                        },
                    ) { index, result ->
                        val entryModifier =
                            if (index == focusedIndex.coerceIn(0, results.lastIndex)) {
                                Modifier.focusRequester(resultEntryRequester)
                            } else {
                                Modifier
                            }

                        TvSearchPosterCard(
                            result = result,
                            modifier = entryModifier,
                            upRequester = if (index < 6) allTypeRequester else null,
                            onFocused = {
                                focusedIndex = index
                                TvSearchFocusMemory.resultIndex = index
                                scope.launch {
                                    gridState.animateScrollToItem(
                                        index = (index - 6).coerceAtLeast(0),
                                    )
                                }
                            },
                            onClick = { onOpenMedia(result.media) },
                        )
                    }
                }
            }
        }

        TvTopNav(
            navRequesters = navRequesters,
            contentDownRequester = inputRequester,
            selectedLabel = "Search",
            onSelected = onNavigate,
        )
    }
}

@Composable
private fun SearchMessage(
    title: String,
    body: String,
) {
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 58.dp, top = 330.dp),
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = body,
            color = SearchMuted,
            fontSize = 14.sp,
        )
    }
}

@Composable
private fun TvSearchChip(
    label: String,
    selected: Boolean,
    requester: FocusRequester,
    upRequester: FocusRequester?,
    downRequester: FocusRequester?,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.05f else 1f, label = "searchChipScale")
    val borderColor by animateColorAsState(
        if (focused) SearchYellow else Color.Transparent,
        label = "searchChipBorder",
    )

    Box(
        modifier =
            Modifier
                .focusRequester(requester)
                .tvVerticalFocus(up = upRequester, down = downRequester)
                .onFocusChanged { focused = it.isFocused }
                .scale(scale)
                .background(
                    color =
                        when {
                            selected -> Color.White
                            focused -> Color.White.copy(alpha = 0.16f)
                            else -> Color.White.copy(alpha = 0.08f)
                        },
                    shape = RoundedCornerShape(10.dp),
                )
                .border(
                    width = 1.dp,
                    color = borderColor,
                    shape = RoundedCornerShape(10.dp),
                )
                .clickable(onClick = onClick)
                .focusable()
                .padding(horizontal = 16.dp, vertical = 9.dp),
    ) {
        Text(
            text = label,
            color = if (selected) Color.Black else Color.White,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

@Composable
private fun TvSearchPosterCard(
    result: TvSearchResult,
    modifier: Modifier,
    upRequester: FocusRequester?,
    onFocused: () -> Unit,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "searchPosterScale")
    val borderColor by animateColorAsState(
        if (focused) SearchYellow else Color.Transparent,
        label = "searchPosterBorder",
    )
    val glowColor by animateColorAsState(
        if (focused) SearchGreen.copy(alpha = 0.18f) else Color.Transparent,
        label = "searchPosterGlow",
    )

    Column(
        modifier =
            modifier
                .width(154.dp)
                .scale(scale)
                .tvVerticalFocus(up = upRequester)
                .onFocusChanged { state ->
                    focused = state.isFocused
                    if (state.isFocused) onFocused()
                }
                .clickable(onClick = onClick)
                .focusable(),
    ) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(222.dp)
                    .background(glowColor, RoundedCornerShape(12.dp))
                    .border(
                        width = if (focused) 2.dp else 1.dp,
                        color = borderColor,
                        shape = RoundedCornerShape(12.dp),
                    )
                    .padding(3.dp),
        ) {
            TvNetworkImage(
                url = result.media.poster,
                contentDescription = result.media.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = result.media.name,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = if (focused) FontWeight.Bold else FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = "${result.media.displayType} • ${result.providerName}",
            color = if (focused) Color.White.copy(alpha = 0.76f) else SearchMuted,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
